# CS 177 – project01.py

# Kyochul Jang

import math

print('This program calculates the estimated time to reach a certain glide velocity.')

m_pd = float(input('Link’s weight in lbs: '))
u = float(input('Drag coefficient: '))
v = float(input('Glide velocity: '))
g = 9.8

m_kg = m_pd*0.45
exp1 = v*math.sqrt(u/(m_kg*g))
print('Here is the result')
t = 'N/A'
if exp1 < 1:
    t = math.sqrt(m_kg / (u * g)) * math.atanh(exp1)

print('Link’s weight in kg:', m_kg)
print('Estimated time:', t)
print('Press Enter to exit')


