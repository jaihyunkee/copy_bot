def load_data(filename):
    ret = []
    with open(filename, 'r') as f:
        for line in f:
            line = line.strip().split(',')
            line[1:] = map(int, line[1:])
            ret.append(tuple(line))


    return ret

def compute_evs(matches):
    ret = [0] * 6
    for match in matches:
        for mdx in range(0, len(match)-1):
            ret[mdx] += match[mdx+1]
            if ret[mdx] > 252:
                ret[mdx] = 252
            if sum(ret) > 510:
                ret[mdx] = ret[mdx] - (sum(ret) - 510)
                break
    return tuple(ret)


def isBalanced(stat):
    stat_p = [s/sum(stat) for s in stat]
    if max(stat_p) - min(stat_p) > 0.2:
        return False

    return True



def main():
    data = load_data('battles.txt')
    evs = compute_evs(data)

    print(evs)
    print(isBalanced(evs))

if __name__ == "__main__":
    main()
