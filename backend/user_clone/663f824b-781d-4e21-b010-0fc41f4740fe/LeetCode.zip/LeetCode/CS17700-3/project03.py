# CS 177 – project03.py
# Kyochul Jang

def readData(filename):
    res = tuple()
    with open(filename) as f:
        for line in f:
            if line == 'END':
                break
            temp = line.strip().split(', ')
            temp[1] = int(temp[1])
            res += tuple(temp),

    return res


def calcCollectiblePoints(GoldenRing, PurpleCoin):
    g_point = GoldenRing * 0.1
    p_point = None
    if 0 <= PurpleCoin <= 2:
        p_point = 1
    elif 3 <= PurpleCoin <= 5:
        p_point = 1.3
    elif 6 <= PurpleCoin <= 8:
        p_point = 1.35
    elif 9 <= PurpleCoin:
        p_point = 1.4
    res = g_point * p_point
    if res > 100:
        res = 100
    return res


def calcStylePoints(Stunt, Emerald):
    e_point = Emerald * 5
    s_point = None
    if 0 <= Stunt <= 10:
        s_point = 25
    elif 11 <= Stunt <= 30:
        s_point = 50
    elif 31 <= Stunt <= 50:
        s_point = 75
    elif 51 <= Stunt:
        s_point = 100

    res = e_point + s_point
    if res > 100:
        res = 100

    return res


def makeDecision(t):
    global points_dict
    print(f't: {t}')
    # step 1
    points_dict = {'G': 0, 'P': 0, 'E': 0, 'S': 0, 'R': 0}
    for p in t:
        points_dict[p[0]] += p[1]
    print(f'points_dict: {points_dict}')

    # step 2
    collectible_points = calcCollectiblePoints(points_dict['G'], points_dict['P'])
    style_points = calcStylePoints(points_dict['S'], points_dict['E'])

    # step 3
    total_points = collectible_points * 0.6 + style_points * 0.4

    # step 4
    retry = points_dict['R']
    if 1 <= retry <= 3:
        total_points *= 0.9
    elif 4 <= retry:
        total_points *= 0.8

    # step 5
    rank = None
    if 90 <= total_points <= 100:
        rank = 'S'
    elif 80 <= total_points < 90:
        rank = 'A'
    elif 60 <= total_points < 80:
        rank = 'B'
    elif total_points < 60:
        rank = 'C'
    print(f'total_points, rank: {total_points, rank}')

    return (total_points, rank)


def main():
    filename = input()
    points_tuple = readData(filename)
    total_points, rank = makeDecision(points_tuple)
    # output textfile
    output_string = f"Golden Rings: {points_dict['G']}\nPurple Coin: {points_dict['P']}\nStunt: {points_dict['S']}\n" \
                    f"Emerald: {points_dict['E']}\nRetry: {points_dict['R']}\nDecision: {total_points, rank}"

    with open('Performance.txt', 'w') as f:
        f.write(output_string)

    return


if __name__ == "__main__":
    main()
