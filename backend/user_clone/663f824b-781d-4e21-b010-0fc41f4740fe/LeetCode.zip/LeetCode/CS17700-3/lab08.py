def load_inventory(filename):
    ret = {}
    with open(filename) as f:
        for line in f:
            line = line.split(',')
            temp = [line[1]] + list(map(int, line[2:]))
            ret[line[0]] = tuple(temp)
    return ret

def optimize_equipment(data, stat):
    ret, stat_idx = {}, {'Damage': 1, 'Defense': 2, 'Speed': 3, 'Magic': 4}
    stat_idx = stat_idx[stat]

    for item_name in data:
        slot = data[item_name][0]
        
        if data[item_name][stat_idx] >= 0:
            if slot not in ret:
                ret[slot] = item_name
            else:
                max_item_name = ret[slot]
                if data[max_item_name][stat_idx] < data[item_name][stat_idx]:
                    ret[slot] = item_name

    return ret

def final_stats(data, opt):
    ret = [0] * 4
    for slot in opt:
        item_name = opt[slot]
        for i in range(1, 5):
            ret[i-1] += data[item_name][i]
    return tuple(ret)

data = load_inventory('sample_data.txt')
opt = optimize_equipment(data, 'Damage')
print(opt)
print(final_stats(data, opt))