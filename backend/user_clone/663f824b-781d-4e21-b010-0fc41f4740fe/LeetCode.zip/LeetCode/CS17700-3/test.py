def load_inventory(filename):
  x = dict()

  with open(filename, 'r') as file:
    for line in file:
      linevals = line.split(',')
      key = linevals[0]
      val = [linevals[1]] + [int(i) for i in linevals[2:]]
      x[key] = tuple(val)
  return x

def optimize_equipment(data, stat):
  optimal = {}
  stat_ind = {'Damage':1, 'Defense':2, 'Speed':3, 'Magic':4}
  index = stat_ind[stat]
  for k in data:
    slot = data[k][0]
    new_bonus = data[k][index]
    if slot in optimal:
      curr_bonus = data[optimal[slot]][index]
      if new_bonus > curr_bonus:
        optimal[slot] = k
    elif new_bonus >= 0:
      optimal[slot] = k
  return optimal

def final_stats(data, optimal):
  final = [0,0,0,0]
  for k in optimal:
    if optimal[k]:
      item_stats = data[optimal[k]][1:]
      for i in range(4):
        final[i] += item_stats[i]
  return tuple(final)

data = load_inventory('sample_data.txt')
opt = optimize_equipment(data, 'Speed')
print(final_stats(data, opt))