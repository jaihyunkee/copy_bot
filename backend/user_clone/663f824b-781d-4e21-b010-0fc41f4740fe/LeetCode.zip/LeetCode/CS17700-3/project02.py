# CS 177 – project02.py

# Kyochul Jang


def is_leap_year(year):
    return not year % 4


def date_to_string(m, d, y):
    return f'{m}/{d}/{y}'


def get_last_day(m, y):
    if m == 2:
        if is_leap_year(y):
            return 29
        else:
            return 28
    elif (m <= 7 and m % 2 == 1) or (m >= 8 and m % 2 == 0):
        return 31
    else:
        return 30


def successor(date):
    m, d, y = map(int, date.split('/'))
    d += 1
    last_day = get_last_day(m, y)
    if d > last_day:
        d = 1
        m += 1
    if m > 12:
        m = 1
        y += 1

    return date_to_string(m, d, y)


def predecessor(date):
    m, d, y = map(int, date.split('/'))
    d -= 1

    if d < 1:
        m -= 1
        if m < 1:
            m = 12
            y -= 1

        d = get_last_day(m, y)

    return date_to_string(m, d, y)


def date_calculator(date, difference):
    is_positive = True
    if difference < 0:
        is_positive = False
        difference *= -1

    for _ in range(difference):
        if is_positive:
            date = successor(date)
        else:
            date = predecessor(date)

    return date

def schedule_dates(start_day, end_day, interval):
    sm, sd, sy = map(int, start_day.split('/'))
    em, ed, ey = map(int, end_day.split('/'))

    s_num = sy * 10000 + sm * 100 + sd
    e_num = ey * 10000 + em * 100 + ed
    date = start_day

    num = 0
    while s_num < e_num:
        if num:
            print(date)
        date = date_calculator(date, interval)
        sm, sd, sy = map(int, date.split('/'))
        s_num = sy * 10000 + sm * 100 + sd
        num += 1

    return


def main():
    print(successor("2/28/2013"))
    print(successor("12/31/2077"))
    print(predecessor("3/1/1860"))
    print(predecessor("12/31/2000"))
    print(date_calculator("1/1/2023", 5000))
    print(date_calculator("1/1/2023", -3))
    print("Dates:")
    schedule_dates("1/1/2024", "1/1/2025", 14)

if __name__ == "__main__":

    main()
