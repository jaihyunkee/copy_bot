# https://chat.openai.com/share/b7fa2440-24c3-4e3a-b01b-92278565850d

# CS 177 – project05.py
# {Chase Miller}

import matplotlib.pyplot as plt
import random

class ConnectFour:
    def __init__(self):
        self.rows = 6
        self.columns = 7
        self.board = [[' ' for _ in range(self.columns)] for _ in range(self.rows)]
        self.current_player = 1

    def display_board(self):
        # Display the game board as a plot
        plt.clf()  # Clear the previous plot

        # Set the background color to white outside the black line border
        fig, ax = plt.subplots(facecolor='white')

        # Draw the walls (blue shading) between columns and rows
        for col in range(self.columns + 1):
            ax.fill_between([col - 0.5, col + 0.5], -0.5, self.rows + 0.5, color='blue')

        for row in range(self.rows + 1):
            ax.fill_between([-0.5, self.columns + 0.5], row - 0.5, row + 0.5, color='blue')

        # Draw the top border (black line) right above the first row of circles
        ax.plot([-0.5, self.columns + 0.5], [self.rows + 0.5, self.rows + 0.5], color='black', linewidth=1)

        # Draw the game board
        for row in range(self.rows):
            for col in range(self.columns):
                color = 'yellow' if self.board[row][col] == '1' else 'red' if self.board[row][col] == '2' else 'white'
                ax.scatter(col + 0.5, self.rows - row - 0.5, s=800, color=color, marker='o', edgecolor='white', linewidth=1)

        # Draw the column numbers above the game board in black
        for col in range(self.columns):
            ax.text(col + 0.5, self.rows + 0.2, str(col), ha='center', va='center', fontsize=10, color='black')

        plt.xlim(0, self.columns)
        plt.ylim(0, self.rows)
        ax.set_aspect('equal', adjustable='box')
        plt.xticks([])
        plt.yticks([])
        plt.grid(False)

        plt.show()

    def drop_disc(self, column, player):
        for i in range(self.rows - 1, -1, -1):
            if self.board[i][column] == ' ':
                self.board[i][column] = str(player)
                break
        else:
            print(f"Column {column} is full. Please try a different column.")
            return False  # Indicates that the move was invalid

        return True  # Indicates that the move was valid

    def is_board_full(self):
        for row in self.board:
            if ' ' in row:
                return False
        return True

    def switch_player(self):
        self.current_player = 3 - self.current_player  # Switches between 1 and 2

    def check_winner(self):
        # Check for a win horizontally
        for row in self.board:
            if '1111' in ''.join(row) or '2222' in ''.join(row):
                return True

        # Check for a win vertically
        for col in range(self.columns):
            if '1111' in ''.join(self.board[row][col] for row in range(self.rows)) or \
               '2222' in ''.join(self.board[row][col] for row in range(self.rows)):
                return True

        # Check for a win diagonally (top-left to bottom-right)
        for row in range(self.rows - 3):
            for col in range(self.columns - 3):
                if self.board[row][col] == self.board[row + 1][col + 1] == self.board[row + 2][col + 2] == self.board[row + 3][col + 3] != ' ':
                    return True

        # Check for a win diagonally (bottom-left to top-right)
        for row in range(3, self.rows):
            for col in range(self.columns - 3):
                if self.board[row][col] == self.board[row - 1][col + 1] == self.board[row - 2][col + 2] == self.board[row - 3][col + 3] != ' ':
                    return True

        return False

    def make_ai_move(self):
        # Simple AI: Make a random valid move
        valid_columns = [col for col in range(self.columns) if ' ' in self.board[0][col]]
        if valid_columns:
            return random.choice(valid_columns)
        return None  # Indicates that there are no valid moves

# Main game loop
def play_connect_four_vs_ai():
    game = ConnectFour()

    while True:
        game.display_board()

        try:
            if game.current_player == 1:
                column = int(input(f"Player 1, choose a column (0-{game.columns - 1}): "))
            else:
                column = game.make_ai_move()
                print(f"AI chose column {column}")

            if 0 <= column < game.columns:
                if game.drop_disc(column, game.current_player):
                    if game.check_winner():
                        game.display_board()
                        if game.current_player == 1:
                            print("Player 1 wins!")
                        else:
                            print("AI wins!")
                        break

                    if game.is_board_full():
                        game.display_board()
                        print("The game is a draw! The board is full.")
                        break

                    game.switch_player()

            else:
                print("Please enter a number within the valid range (0 to 6).")

        except ValueError:
            print("Invalid input. Please enter a valid number.")

        except IndexError:
            print("Invalid column. Please enter a number within the valid range (0 to 6).")


if __name__ == "__main__":
    play_connect_four_vs_ai()


