# CS 177 – project03.py
# Kyochul Jang

def readStudentInfo(fileName):
    res = []
    with open(fileName) as f:
        for line in f:
            student_info = line.strip().split(', ')
            temp_dict = dict()
            temp_dict['ID'], temp_dict['Name'], temp_dict['Age'] = student_info[0], student_info[1], student_info[2]
            res.append(temp_dict)

    return res


def readSubmissionRecord(fileName):
    res = []
    with open(fileName) as f:
        for line in f:
            record = line.strip().split(', ')
            record[2] = int(record[2])
            temp_dict = dict()
            temp_dict['ID'], temp_dict['Name'], temp_dict['Score'], temp_dict['Date'] = record[0], record[1], \
                record[2], record[3]
            res.append(temp_dict)

    return res


def readAssignmentInfo(fileName):
    res = []
    with open(fileName) as f:
        for line in f:
            info = line.strip().split(', ')
            temp_dict = dict()
            temp_dict['Name'], temp_dict['Weight'], temp_dict['Deadline'] = info[0], float(info[1]), info[2]
            res.append(temp_dict)

    return res


def date_to_value(date_str):
    mm, dd, yyyy = list(map(int, date_str.split('/')))
    if mm < 10:
        mm = '0' + str(mm)
    if dd < 10:
        dd = '0' + str(dd)
    date_value = str(yyyy) + str(mm) + str(dd)

    return int(date_value)

"""
1. limit != 0 => limit > 0
2. date를 이하로 비교하기
3. limit -= 1 if 안으로 옮기기
4. date day 10보다 작은거 1 -> 01
"""
def getScore(studentInfo, submissionRecord, assignmentInfo):
    res = []

    for student_dict in studentInfo:
        final_record = dict()
        student_id, student_name, student_age = student_dict['ID'], student_dict['Name'], student_dict['Age']
        final_record['ID'], final_record['Name'], final_record['Age'] = student_id, student_name, student_age
        for info in assignmentInfo:
            deadline_value = date_to_value(info['Deadline'])
            assignment = info['Name']
            max_score = 0
            final_record[assignment] = max_score
            limit = 10
            for record in submissionRecord:

                date_value = date_to_value(record['Date'])
                if date_value <= deadline_value and assignment == record['Name'] and student_id == record['ID'] and \
                        limit > 0:
                    if record['Score'] > max_score:
                        max_score = record['Score']
                        final_record[assignment] = max_score
                    limit -= 1

        res.append(final_record)

    return res


def computeFinalGrades(studentScoreInfo, assignmentInfo):
    for student_info in studentScoreInfo:
        final_score = 0
        for assignment_info in assignmentInfo:
            assignment = assignment_info['Name']
            final_score += student_info[assignment] * assignment_info['Weight']
        student_info['Final Grade'] = final_score

    return studentScoreInfo

"""
평균 낼때 점수들을 과제 수로 나누는게 아니라 학생수로 나눠서 각 랩의 평균을 내야함
"""
def computeAverage(studentFullInfo, assignmentInfo):
    ret_dict = dict()
    for info in assignmentInfo:
        assignment = info['Name']
        ret_dict[assignment] = 0
        for student in studentFullInfo:
            ret_dict[assignment] += student[assignment]
        ret_dict[assignment] /= len(studentFullInfo)
    res_score = 0
    for s in studentFullInfo:
        res_score += s['Final Grade']
    res_score /= len(studentFullInfo)
    ret_dict['Final Grade'] = res_score
    return ret_dict


def main():
    studentInfo = readStudentInfo('StudentInfo.txt')
    submissionRecord = readSubmissionRecord('SubmissionRecord.txt')
    assignmentInfo = readAssignmentInfo('AssignmentInfo.txt')
    studentScoreInfo = getScore(studentInfo, submissionRecord, assignmentInfo)
    # print(f'studentScoreInfo: {studentScoreInfo}')
    studentFullInfo = computeFinalGrades(studentScoreInfo, assignmentInfo)
    # print(f'studentFullInfo: {studentFullInfo}')
    averagePerAssignment = computeAverage(studentFullInfo, assignmentInfo)
    # print(f'averagePerAssignment: {averagePerAssignment}')


if __name__ == '__main__':
    main()