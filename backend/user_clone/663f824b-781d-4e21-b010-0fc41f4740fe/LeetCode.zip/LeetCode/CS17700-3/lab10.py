class GroceryStore:
    def __init__(self, item_price, customer_purchase):
        self.item_price = item_price
        self.customer_purchase = customer_purchase

    def calc_grocery_dict(self, grocery_dict):
        sum_price = 0
        for item, quantity in grocery_dict.items():
            sum_price += self.item_price[item] * quantity
        return sum_price

    def calc_customer_purchase(self):
        new_dict = {}
        for customer, grocery_dict in self.customer_purchase.items():
            new_dict[customer] = self.calc_grocery_dict(grocery_dict)
        return new_dict

    def total_profit(self):
        return sum(self.calc_customer_purchase().values())


class Costco(GroceryStore):
    def __init__(self, item_price, customer_purchase, price_fluctuation, loss) -> None:
        super().__init__(item_price, customer_purchase)
        self.price_fluctuation = price_fluctuation
        self.loss = loss

    def calc_grocery_dict(self, grocery_dict):
        sum_price = 0
        for item, quantity in grocery_dict.items():
            sum_price += quantity * self.item_price[item] * self.price_fluctuation
        return sum_price
        # p = super().calc_grocery_dict(grocery_dict) * self.price_fluctuation

    def total_profit(self):
        return sum(self.calc_customer_purchase().values()) - self.loss


def main():
    print("Test")


if __name__ == "__main__":
    main()