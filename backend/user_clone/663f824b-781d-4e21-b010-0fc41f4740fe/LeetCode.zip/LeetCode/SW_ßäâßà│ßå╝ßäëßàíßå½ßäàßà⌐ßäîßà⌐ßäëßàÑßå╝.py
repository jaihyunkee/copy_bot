def dfs(i, j, cnt):
    global isDigged
    for m in [(0, 1), (0, -1), (1, 0), (-1, 0)]:
        ni, nj = i + m[0], j + m[1]
        if inRange(ni, nj) and grid[ni][nj] < grid[i][j]:
            isVisited[ni][nj] = True
            dfs(ni, nj, cnt+1)
            isVisited[ni][nj] = False

        elif inRange(ni, nj) and not isDigged:
            for k in range(1, K+1):
                if grid[ni][nj] - k < grid[i][j] and not isVisited[ni][nj]:
                    isDigged, isVisited[ni][nj] = True, True
                    grid[ni][nj] -= k
                    dfs(ni, nj, cnt + 1)
                    isDigged, isVisited[ni][nj] = False, False
                    grid[ni][nj] += k
    res_arr.append(cnt)

def inRange(i, j):
    return 0 <= i < N and 0 <= j < N

T = int(input())
for t in range(1, T+1):
    N, K = map(int, input().split())
    grid = []
    max_height = float('-inf')
    for _ in range(N):
        arr = list(map(int, input().split()))
        if max_height < max(arr):
            max_height = max(arr)
        grid.append(arr)
    isVisited = [[0] * N for _ in range(N)]

    res_arr = []
    for i in range(N):
        for j in range(N):
            if grid[i][j] == max_height:
                cnt, isDigged, isVisited[i][j] = 1, False, True
                dfs(i, j, cnt)
                isVisited[i][j] = False

    print(f'#{t} {max(res_arr)}')


