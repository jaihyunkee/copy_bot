# import sys

# N, M = map(int, sys.stdin.readline().split(' '))
# out_arr = [0] * M


# def dfs(arr_idx):
#     if arr_idx == M:
#         print(*out_arr)
#         return None
#     else:
#         for i in range(1, N + 1):
#             if 0 < arr_idx:
#                 if i > out_arr[arr_idx - 1]: # 여기에 arr_idx 대신에 i를 넣어서 out of index가 떴는데, i는 어레이에 넣을 variable이다.
#                     out_arr[arr_idx] = i
#                     dfs(arr_idx + 1)
#             else:
#                 out_arr[arr_idx] = i
#                 dfs(arr_idx + 1)


# if __name__ == "__main__":
#     dfs(0)

# import sys

# N, M = map(int, sys.stdin.readline().split())
# isExist = set()

# isUsed = [False] * (N+1)

# def dfs(arr_idx, ret):
#     if arr_idx == M:
#         print(*ret)
#         return
#     last_num = 0 if not len(ret) else ret[-1]
#     for i in range(1, N+1):
#         if not isUsed[arr_idx] and last_num < i:
#             last_num = i
#             isUsed[arr_idx] = True
#             dfs(arr_idx+1, ret+[i])
#             isUsed[arr_idx] = False

# dfs(0, [])

# from itertools import combinations

# N, M = map(int, input().split())
# for comb in combinations(range(1, N+1), M):
#     print(*comb)


