# """
# 20
# 7
# 23
# 19
# 10
# 15
# 25
# 8
# 13
# """

# import sys

# def Solution():
#     cin_list = []
#     sum = 0
#     for i in range(9):
#         cin = int(sys.stdin.readline())
#         cin_list.append(cin)
#         sum += cin

#     diff = sum - 100

#     l, r = 0, len(cin_list) - 1
#     cin_list.sort()
#     ret = []
#     while l < r:
#         if cin_list[l] + cin_list[r] == diff:
#             # cin_list.remove(cin_list[r])
#             # cin_list.remove(cin_list[l])
#             for k in cin_list:
#                 if k != cin_list[l] and k != cin_list[r]:
#                     ret.append(k)
#             break
#         elif cin_list[l] + cin_list[r] > diff:
#             r -= 1
#         else:
#             l += 1

#     return '\n'.join(map(str, ret))


# if __name__ == "__main__":
#     print(Solution())


