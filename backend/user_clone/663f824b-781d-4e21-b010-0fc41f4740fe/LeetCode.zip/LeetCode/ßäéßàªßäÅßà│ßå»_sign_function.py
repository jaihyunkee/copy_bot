# you can write to stdout for debugging purposes, e.g.
# print("this is a debug message")

def solution(A):
    # Implement your solution here
    mul, neg_cnt = 1, 0
    for num in A:
        if num == 0:
            return 0
        elif num < 0:
            neg_cnt += 1

    if neg_cnt % 2 == 0:
        return 1
    else:
        return -1