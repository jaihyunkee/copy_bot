from gensim.corpora import Dictionary
from gensim.models import TfidfModel
from gensim.models import Word2Vec
import numpy as np

# You can access all models by uncommenting the following command
models = {
           "w2v": Word2Vec.load("models/w2v"),
           "tfidf": TfidfModel.load("models/tfidf"),
           "dct": Dictionary.load("models/dct"),
       }

# You can use this helper function to get tfidf weights for given
# sentence and for accessed models
def get_tfidf_weights(models, sentence):
    transformed = models["dct"].doc2bow(sentence.split())
    tfidf_dct = {
        models["dct"][key]: value for (key, value) in models["tfidf"][transformed]
    }
    return tfidf_dct


def embed_sentence(models, sentence):
    tfidf_weights = get_tfidf_weights(models, sentence)
    words = sentence.split()

    avg_wv = np.zeros(100)
    avg_tfidf = np.zeros(100)
    total_tfidf_weight = 0
    
    for word in words:
        if word in models['w2v'].wv:
            # w2v
            wv = models['w2v'].wv[word]
            avg_wv += wv

            # tfidf
            total_tfidf_weight += tfidf_weights[word]
            avg_tfidf += wv * tfidf_weights[word]

    w2v_embedding = (avg_wv / len(words)).tolist()
    tfidf_embedding = (avg_tfidf / total_tfidf_weight).tolist()

    return {"w2v_embedding": w2v_embedding, "tfidf_embedding": tfidf_embedding}
