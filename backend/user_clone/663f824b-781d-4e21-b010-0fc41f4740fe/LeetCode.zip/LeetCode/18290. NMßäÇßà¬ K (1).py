# import sys

# N, M, K = map(int, sys.stdin.readline().split())
# grid = [list(map(int, sys.stdin.readline().split())) for _ in range(N)]
# moves = [(-1, 0), (1, 0), (0, -1), (0, 1)]
# isUsed = [[0] * M for _ in range(N)]
# max_val = float('-inf')


# def dfs(cnt: int, ans: int):
#     global max_val
#     if cnt == K:

#         if ans > max_val:
#             max_val = ans
#         return

#     for i in range(N):
#         for j in range(M):
#             if not isUsed[i][j]:

#                 isUsed[i][j] += 1
#                 for x, y in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
#                     if 0 <= i + x < N and 0 <= j + y < M:
#                         isUsed[i + x][j + y] += 1

#                 dfs(cnt + 1, ans + grid[i][j])

#                 for x, y in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
#                     if 0 <= i + x < N and 0 <= j + y < M:
#                         isUsed[i + x][j + y] -= 1
#                 isUsed[i][j] -= 1


# dfs(0, 0)

# print(max_val)

import sys

def inRange(i, j):
    return 0 <= i < N and 0 <= j < M

N, M, K = map(int, sys.stdin.readline().split())
grid = [list(map(int, sys.stdin.readline().split())) for _ in range(N)]
isVisited = [[False] * M for _ in range(N)]

moves, max_val = [(0, 1), (0, -1), (1, 0), (-1, 0)], float('-inf')

def dfs(cnt, score):
    global max_val
    if cnt == K:
        max_val = max(max_val, score)
        return
    for i in range(N):
        for j in range(M):
            if not isVisited[i][j]:
                
                flag = False
                for m in moves:
                    ni, nj = i + m[0], j + m[1]
                    if inRange(ni, nj) and isVisited[ni][nj]:
                        flag = True
                        break

                if not flag:
                    isVisited[i][j] = True
                    dfs(cnt+1, score+grid[i][j])
                    isVisited[i][j] = False

dfs(0, 0)
print(max_val)
