N, M = map(int, input().split())
n_set, m_set = set(), set()
for _ in range(N):
    n_set.add(input())
for _ in range(M):
    m_set.add(input())

res = sorted(list(n_set.intersection(m_set)))
print(len(res))
for _ in res:
    print(_)
