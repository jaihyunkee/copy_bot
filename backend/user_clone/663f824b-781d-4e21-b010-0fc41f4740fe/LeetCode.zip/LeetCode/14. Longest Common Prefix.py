class Solution(object):
    def longestCommonPrefix(self, strs):
        """
        :type strs: List[str]
        :rtype: str
        """
        shortest, res = min(map(len, strs)), ""
        print(shortest)
        i = 0
        while True:
            if i >= shortest:
                return res

            to_compare = strs[0][i]

            for str in strs:
                if str[i] != to_compare:
                    return res
            res += to_compare
            i += 1
        return res