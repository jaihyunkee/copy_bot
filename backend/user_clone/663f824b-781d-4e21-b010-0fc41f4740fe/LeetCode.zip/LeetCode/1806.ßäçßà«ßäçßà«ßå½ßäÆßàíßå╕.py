from sys import stdin

N, S = map(int, stdin.readline().split())
nums = list(map(int, stdin.readline().split()))

start, end = 0, 0
min_len = float('inf')
sum = 0
while True:
    if sum >= S:
        min_len = min(min_len, end - start)

        sum -= nums[start]
        start += 1
    elif end == N:
        if min_len == float('inf'):
            print(0)
        else:
            print(min_len)
        break
    elif sum < S:
        sum += nums[end]
        end += 1



