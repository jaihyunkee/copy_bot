import pandas as pd
import numpy as np


class KNNClassifier:

    def min_max_scale(self, value, min_val, max_val):
        if max_val == min_val:
            return 0
        return (value - min_val) / (max_val - min_val)

    def classify(self, path, x, y, z):
        # dataset can be loaded by uncommenting the following line
        df = pd.read_csv(path)
        
        k_values = [1, 3, 10, 20, 50, 75]
        results = {}
        
        # rescaling
        x_min, x_max = df['x'].min(), df['x'].max()
        y_min, y_max = df['y'].min(), df['y'].max()
        z_min, z_max = df['z'].min(), df['z'].max()

        df['x_norm'] = df['x'].apply(lambda val: self.min_max_scale(val, x_min, x_max))
        df['y_norm'] = df['y'].apply(lambda val: self.min_max_scale(val, y_min, y_max))
        df['z_norm'] = df['z'].apply(lambda val: self.min_max_scale(val, z_min, z_max))

        x_norm = self.min_max_scale(x, x_min, x_max)
        y_norm = self.min_max_scale(y, y_min, y_max)
        z_norm = self.min_max_scale(z, z_min, z_max)
        
        for k in k_values:
            distances = []
            for i, row in df.iterrows():
                dist = np.sqrt(
                    (x_norm - row['x_norm']) ** 2 +
                    (y_norm - row['y_norm']) ** 2 +
                    (z_norm - row['z_norm']) ** 2
                )
                distances.append((dist, row['decision']))
                
            distances.sort(key=lambda x: x[0])
            
            if len(distances) < k:
                cutoff = distances[-1][0]
            else:
                cutoff = distances[k - 1][0]
                
            neighbors = [d for d in distances if d[0] <= cutoff]
            
            yes_count = sum([1 for n in neighbors if n[1] == 'YES'])
            no_count = sum([1 for n in neighbors if n[1] == 'NO'])
            
            results[k] = 'YES' if yes_count >= no_count else 'NO'
            
        return results
        
        
