for t in range(1, 11):
    N = input()
    arr = input()

    stack = []
    opening = ['(', '{', '[', '<']
    closing = [')', '}', ']', '>']
    flag = 1
    for i in range(len(arr)):
        if arr[i] in opening:
            stack.append(arr[i])
        elif arr[i] in closing:
            if arr[i] == ')':
                if stack[-1] != '(':
                    flag = 0
                    break
                else:
                    stack.pop()
            elif arr[i] == '}':
                if stack[-1] != '{':
                    flag = 0
                    break
                else:
                    stack.pop()
            elif arr[i] == ']':
                if stack[-1] != '[':
                    flag = 0
                    break
                else:
                    stack.pop()
            elif arr[i] == '>':
                if stack[-1] != '<':
                    flag = 0
                    break
                else:
                    stack.pop()
    print(f'#{t} {flag}')

