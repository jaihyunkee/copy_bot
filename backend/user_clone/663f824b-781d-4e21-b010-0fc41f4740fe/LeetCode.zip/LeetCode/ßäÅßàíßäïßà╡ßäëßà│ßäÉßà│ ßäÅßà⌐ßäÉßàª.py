"""
민수가 본인 생일파티에 친구들을 초대했다.
친구들은 여러 그룹으로 나누어져있고, 그 그룹끼리 택시를 타고 민수 집으로 와야한다.
서로 다른 그룹끼리는 같이 택시를 탈 수 있지만, 그룹이 쪼개져서 택시를 타면 안된다. 
그룹은 한 그룹당 1~4명으로 이루어져있고, 한 택시에 최대 4명이 탑승 가능하다.

필요한 최소의 택시 수는 몇대인지 구하라

예시)
다음 array의 element는 각 그룹의 인원을 포함하고 있다.
1. [1,1,1,2,3,3,4] -> 4대
1, 3 -> 1대
1, 3 -> 1대
4 -> 1대
2 -> 1대

2. [1,1,1,1] -> 1대
1,1,1,1 -> 1대
"""

def min_taxis(groups):
    count_1, count_2, count_3, count_4 = 0, 0, 0, 0

    # 각 그룹의 수 세기
    for people in groups:
        if people == 1:
            count_1 += 1
        elif people == 2:
            count_2 += 1
        elif people == 3:
            count_3 += 1
        elif people == 4:
            count_4 += 1

    # 최소 택시 수 계산
    taxis = count_4  # 4인 그룹은 무조건 한 대씩

    # 3인 그룹과 1인 그룹을 매칭
    group_3_1 = min(count_3, count_1)
    taxis += group_3_1
    count_3 -= group_3_1
    count_1 -= group_3_1

    # 2인 그룹들 매칭
    taxis += count_2 // 2
    count_2 = count_2 % 2

    # 남은 2인 그룹과 1인 그룹 매칭
    if count_2 == 1:
        if count_1 >= 2:
            taxis += 1
            count_1 -= 2
        else:
            taxis += 1
            count_1 = 0

    # 남은 1인 그룹 처리
    taxis += (count_1 + 3) // 4

    # 남은 3인 그룹 처리
    taxis += count_3

    return taxis

# 테스트 케이스
print(min_taxis([1,1,1,2,3,3,4]))  # 예시 1
print(min_taxis([1,1,1,1]))        # 예시 2
