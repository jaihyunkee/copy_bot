class Solution(object):
    def isValid(self, s):
        """
        :type s: str
        :rtype: bool
        """
        stack = []
        openToClose = {')': '(', ']': '[', '}': '{'}
        for c in s:
            if c not in openToClose:
                stack.append(c)
                continue
            elif stack and stack[-1] == openToClose[c]:
                stack.pop()
            else:
                return False

        return True if not stack else False



sol = Solution()
print(sol.isValid("()[]{}"))
