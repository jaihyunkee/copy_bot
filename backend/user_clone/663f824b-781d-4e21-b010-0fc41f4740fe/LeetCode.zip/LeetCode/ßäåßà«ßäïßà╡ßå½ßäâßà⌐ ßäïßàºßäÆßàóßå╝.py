from collections import deque

def inRange(i, j):
    return 0 <= i < N and 0 <= j < M

def solution(maps):
    global N, M
    maps = [list(m) for m in maps]
    N, M = len(maps), len(maps[0])
    moves = [(0, 1), (0, -1), (1, 0), (-1, 0)]
    answer = []
    for n in range(N):
        for m in range(M):
            if maps[n][m] == 'X':
                continue
            else:
                res = int(maps[n][m])
                queue = deque([(n, m)])
                maps[n][m] = 'X'
                while queue:
                    i, j = queue.popleft()
                    for di, dj in moves:
                        ti, tj = i+di, j+dj
                        if inRange(ti, tj) and maps[ti][tj] != 'X':
                            queue.append((ti, tj))
                            res += int(maps[ti][tj])
                            maps[ti][tj] = 'X'
                answer.append(res)
    
    return sorted(answer) if answer else [-1]