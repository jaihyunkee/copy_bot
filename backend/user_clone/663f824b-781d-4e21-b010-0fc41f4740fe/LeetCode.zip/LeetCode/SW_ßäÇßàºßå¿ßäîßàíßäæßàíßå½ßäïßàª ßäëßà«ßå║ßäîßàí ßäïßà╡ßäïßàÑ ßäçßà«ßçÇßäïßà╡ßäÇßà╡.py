T = int(input())
moves = [(0, 1), (0, -1), (1, 0), (-1, 0)]


def inRange(new_x, new_y):
    return 0 <= new_x < 4 and 0 <= new_y < 4


def dfs(x, y, cnt: int, string: str):
    if cnt == 7:
        if string not in nums:
            nums.append(string)
        return

    for move in moves:
        new_x, new_y = x + move[0], y + move[1]
        if inRange(new_x, new_y):
            dfs(new_x, new_y, cnt + 1, string + grid[new_x][new_y])


for t in range(1, T + 1):
    grid, nums = [], []
    for _ in range(4):
        grid.append(list(map(str, input().split())))
    for i in range(4):
        for j in range(4):
            dfs(i, j, 1, grid[i][j])
    print(f'#{t} {len(nums)}')
