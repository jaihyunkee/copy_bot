import sys

"""
유클리드 호제법
"""

def GCD(M, N):
    if N == 0:
        return M
    return GCD(N, M%N)

def Solution():
    M, N = map(int, sys.stdin.readline().split(" "))
    # min_num = min(num1, num2)
    res = []
    # for i in range(min_num, 0, -1):
    #     if num1 % i == 0 and num2 % i == 0:
    #         res.append(i)
    #         break
    # t1 , t2 = num1, num2
    # while t1 != t2:
    #     if t1 == min(t1, t2):
    #         t1 += num1
    #
    #     else:
    #         t2 += num2
    #
    # res.append(t1)
    res.append(GCD(M, N))
    res.append(int(M*N/GCD(M,N)))
    return "\n".join(map(str, res))


if __name__ == "__main__":
    print(Solution())
