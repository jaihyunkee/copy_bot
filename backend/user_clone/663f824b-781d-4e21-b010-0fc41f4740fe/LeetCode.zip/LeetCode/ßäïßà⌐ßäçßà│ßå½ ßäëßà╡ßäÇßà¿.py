hh, mm = map(int, input().split())
add_mm = int(input())

if mm + add_mm < 60:
    mm += add_mm
else:
    temp = mm + add_mm
    mm, to_add_hh = temp % 60, temp // 60
    if hh + to_add_hh >= 24:
        hh = (hh + to_add_hh) % 24
    else:
        hh += to_add_hh
        

print(hh, mm)

