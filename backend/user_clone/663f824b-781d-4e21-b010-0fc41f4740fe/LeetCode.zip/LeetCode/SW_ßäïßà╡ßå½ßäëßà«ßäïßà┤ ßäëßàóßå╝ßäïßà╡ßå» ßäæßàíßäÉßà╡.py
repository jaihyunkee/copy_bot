# def dfs(origin, dest, prev_node, cur_dist):
#     global min_dist
#     if prev_node == dest:
#         if cur_dist < min_dist:
#             min_dist = cur_dist
#
#             res[origin] = min_dist
#
#         return
#
#     for j in range(1, N + 1):
#         if not isUsed[prev_node][j] and edge[prev_node][j] != -1:
#             if cur_dist > min_dist:
#                 return
#             isUsed[prev_node][j] = True
#             dfs(origin, dest, j, cur_dist + edge[prev_node][j])
#             isUsed[prev_node][j] = False
#
#
# def dfs2(dest, prev_node, cur_dist):
#     global min_dist
#     if prev_node == dest:
#         if cur_dist < min_dist:
#             min_dist = cur_dist
#             res2[dest] = min_dist
#
#     for j in range(1, N + 1):
#         if not isUsed[prev_node][j] and edge[prev_node][j] != -1:
#             if cur_dist > min_dist:
#                 return
#             isUsed[prev_node][j] = True
#             dfs2(dest, j, cur_dist + edge[prev_node][j])
#             isUsed[prev_node][j] = False
#
#
# TC = int(input())
# # i -> departure, j -> destination
# for tc in range(1, TC + 1):
#     N, M, X = map(int, input().split())
#     party_place = X
#     res, res2 = [0] * (N + 1), [0] * (N + 1)
#     edge = [[-1] * (N + 1) for _ in range(N + 1)]
#     for _ in range(M):
#         i, j, dist = map(int, input().split())
#         edge[i][j] = dist
#
#     isUsed = [[False] * (N + 1) for _ in range(N + 1)]
#     for i in range(1, N + 1):
#         min_dist = float('inf')
#         dfs(i, party_place, i, 0)
#
#     for i in range(1, N + 1):
#         min_dist = float('inf')
#         dfs2(i, party_place, 0)
#
#     for i in range(len(res)):
#         res[i] = res[i] + res2[i]
#     print(f'#{tc} {max(res)}')
import heapq


def dijkstra(cur_node, edge, distance):
    pq = []
    heapq.heappush(pq, cur_node)
    while pq:
        cur_node = heapq.heappop(pq)
        for n in range(1, N + 1):
            new_dist = distance[cur_node] + edge[cur_node][n]
            if edge[cur_node][n] != 101 and new_dist < distance[n]:
                heapq.heappush(pq, n)
                distance[n] = new_dist

    return distance


TC = int(input())
# i -> departure, j -> destination
for tc in range(1, TC + 1):
    N, M, X = map(int, input().split())
    go_edge = [[101] * (N + 1) for _ in range(N + 1)]
    come_edge = [[101] * (N + 1) for _ in range(N + 1)]
    temp = [[float('inf')] * (N + 1) for _ in range(N + 1)]
    for _ in range(M):
        i, j, dist = map(int, input().split())
        go_edge[j][i] = dist
        come_edge[i][j] = dist
    go_distance = [float('inf')] * (N+1)
    come_distance = [float('inf')] * (N+1)
    go_distance[X] = 0
    come_distance[X] = 0
    go_distance = dijkstra(X, go_edge, go_distance)
    come_distance = dijkstra(X, come_edge, come_distance)

    res = [go_distance[i] + come_distance[i] for i in range(len(go_distance))]
    print(f'#{tc} {max(res[1:])}')

