from collections import deque

def inRange(i, j):
    return 0 <= i < N and 0 <= j < M

def solution(board):
    global N, M
    board = [list(board[i]) for i in range(len(board))]
    N, M = len(board), len(board[0])
    moves = [(0, 1), (0, -1), (1, 0), (-1, 0)]
    
    start = None
    for n in range(N):
        for m in range(M):
            if board[n][m] == 'R':        
                board[n][m] = 0
                start = (n, m)
                break
                
    queue = deque([(start[0], start[1], 0)]) # row, col, step
    
    while queue:
        i, j, step = queue.popleft()
        
        for di, dj in moves:
            ti, tj = i, j
            
            while True:
                ni, nj = ti+di, tj+dj
                if (inRange(ni, nj) and board[ni][nj] == 'D') or not inRange(ni, nj):
                    break
                ti, tj = ni, nj
            
            if board[ti][tj] == 'G':
                return step+1
            
            if board[ti][tj] == '.' or step+1 < board[ti][tj]:
                board[ti][tj] = step+1
                queue.append((ti, tj, step+1))
                
    return -1