N = int(input())
grid = [list(map(int, input().split())) for _ in range(N)]
