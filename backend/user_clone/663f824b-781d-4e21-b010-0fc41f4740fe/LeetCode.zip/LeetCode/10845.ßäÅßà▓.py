from collections import deque
from os import sys

N = int(sys.stdin.readline())
ret = deque()
cin_list = []
for _ in range(N):
    cin = sys.stdin.readline().split()
    if len(cin) == 2:
        command, X = cin[0], cin[1]
        X = int(X)
    else:
        command = cin[0]

    if command == 'push':
        ret.append(X)
    elif command == 'front':
        if not ret:
            print(-1)
        else:
            print(ret[0])
    elif command == 'back':
        if not ret:
            print(-1)
        else:
            print(ret[-1])
    elif command == 'pop':
        if not ret:
            print(-1)
            continue
        else:
            print(ret.popleft())
    elif command == 'size':
        print(len(ret))
    else:
        if not ret:
            print(1)
        else:
            print(0)


