class Solution(object):
    def topKFrequent(self, nums, k):
        """
        :type nums: List[int]
        :type k: int
        :rtype: List[int]
        """
        count = {}
        freq = [[] for _ in range(len(nums) + 1)]
        for i in nums:
            if i not in count:
                count[i] = 1
            else:
                count[i] += 1

        for c in count:
            freq[count[c]].append(c)

        res = []
        flag = 0
        for fdx in range(len(freq)-1, 0, -1):
            for i in freq[fdx]:
                res.append(i)
                if len(res) == k:
                    return res
                

sol = Solution()
print(sol.topKFrequent(nums = [1], k = 1))