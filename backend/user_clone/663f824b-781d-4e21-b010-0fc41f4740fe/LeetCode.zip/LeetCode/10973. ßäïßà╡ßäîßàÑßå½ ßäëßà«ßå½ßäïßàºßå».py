import sys
sys.setrecursionlimit(10**6)

N = int(sys.stdin.readline())
M = list(map(int, sys.stdin.readline().split()))

for i in range(N-1, 0, -1):
    if M[i-1] > M[i]:
        for j in range(N-1, 0, -1):
            if M[i-1] > M[j]:
                temp = M[i-1]
                M[i-1] = M[j]
                M[j] = temp

                temp_li = M[i:]
                temp_li.reverse()
                M = M[:i] + temp_li

                print(*M)
                sys.exit(0)

else:
    print(-1)

"""
```
[1, 4, 5, 2, 3] doesn't work with the following code:
there should be j that comes from the last index again
```
for i in range(N-1, 0, -1):
    if M[i-1] > M[i]:
        temp = M[i]
        M[i] = M[i-1]
        M[i-1] = temp

        temp_li = M[i:].copy()
        temp_li.reverse()
        M = M[:i] + temp_li

        print(*M)
        exit(0)

else:
    print(-1)
"""




"""
permu_list = list(map(int, sys.stdin.readline().split()))
isUsed = [False] * (N + 1)
ans, prev_permu = [], []
Time Exceed
def permutation(cnt):
    global prev_permu
    if cnt == N:
        prev_permu = ans.copy()
        return

    for i in range(1, N + 1):
        if not isUsed[i]:
            isUsed[i] = True
            ans.append(i)
            if ans == permu_list:
                if not len(prev_permu):
                    print(-1)
                    sys.exit(0)
                print(*prev_permu)
                sys.exit(0)
            permutation(cnt + 1)
            isUsed[i] = False
            ans.pop()


if __name__ == "__main__":
    permutation(0)
"""
