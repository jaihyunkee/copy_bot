a = "1:2"
hello = a.split(":")
print(hello)
print(type(hello))