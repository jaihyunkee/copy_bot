# CS 177 – project03.py
# Alex Alonzo
# Given detailed data about football players and their games, my program will output a variety of different analyses. It produces a rating score for players, graphs the results and a pie chart of when fouls occur during the game.
import matplotlib.pyplot as pyplot


# TASK 1 - reads the incident data and produces a list of incidents
def readIncidentData(fileName):
    finalList = []
    with open(f"{fileName}", "r") as incidentData:
        for line in incidentData:
            # splits words
            data = line.split(", ")
            # dealing with the time
            time = data[0].split(":")
            data[0] = round(float(time[0]) + float(time[1]) / 60, 2)
            # gets rid of \n
            data[3] = data[3].replace("\n", "")
            finalList.append(data)
    return finalList


# reads player information and compiles into one big list
def readPlayerInfo(fileName):
    finalList = []
    with open(f"{fileName}", "r") as playerInfo:
        for line in playerInfo:
            # splits words
            data = line.split(", ")
            # gets rid of \n
            data[1] = data[1].replace("\n", "")
            finalList.append(data)
        return finalList


# reads rating information and compiles into one big list
def readRatingInfo(fileName):
    finalList = []
    with open(f"{fileName}", "r") as ratingInfo:
        for line in ratingInfo:
            # splits words
            data = line.split(", ")
            # gets rid of \n
            data[2] = float(data[2].replace("\n", ""))
            finalList.append(data)
    return finalList


# Task 2 - takes incident, player, and rating data and makes a list of average incidents per player
def computeAvgIncidentOccPerPlayer(incidentData, playerInfo, ratingInfo):
    playersData = []
    for player in playerInfo:
        playerData = []
        playerName = player[0]
        playerData.append(playerName)
        for rating in ratingInfo:
            incident = rating[0]
            incidentOcc = 0
            for game in incidentData:
                if playerName in game and incident in game:
                    incidentOcc += 1
            avgIncidentOcc = round(incidentOcc / 3, 2)
            playerData.append(avgIncidentOcc)
        playersData.append(playerData)
    return (playersData)


# Task 3 - I had to do this little function to sort the finalList of ratings per player
def secondQuantity(list):
    return (list[1])


# for each player, depending on position and corresponding coefficients for score
def computeRatingPerPlayer(AverageOccIncidents, playerInfo, ratingInfo):
    finalList = []
    for player in AverageOccIncidents:
        playerData = []
        playerName = player[0]
        playerData.append(playerName)
        pos = ''
        goal, ints, fouls, kp, tackle, offs = player[1], player[2], player[3], player[4], player[5], player[6]
        for record in playerInfo:
            if record[0] == playerName:
                pos = record[1]

        if pos == "Forward":
            score = 6 + goal * 0.8 + ints * 0.6 * 0.5 + fouls * (
                -0.2) * 0.75 + kp * 0.5 * 0.75 + tackle * 0.5 * 0.5 + offs * (-0.3)
        elif pos == "Midfielder":
            score = 6 + 0.75 * (goal * 0.8 + ints * 0.6 + fouls * (-0.2) + kp * 0.5 + tackle * 0.5 + offs * (-0.3))
        else:
            score = 6 + goal * 0.8 * 0.5 + ints * 0.6 + fouls * (
                -0.2) * 0.75 + kp * 0.5 * 0.75 + tackle * 0.5 + offs * (-0.3) * 0.5
        if score < 0:
            score = 0
        elif score > 10:
            score = 10
        else:
            score = round(score, 2)
        playerData.append(score)
        finalList.append(playerData)
    finalList.sort(key=secondQuantity)
    return (finalList)


# Task 4 - this was most likely done very inefficiently but my brain was fried at this point ngl

def foulDistribution(incidentData):
    fouls = 0
    fouls15 = 0
    fouls30 = 0
    fouls45 = 0
    fouls60 = 0
    fouls75 = 0
    fouls90 = 0
    for incident in incidentData:
        if incident[1] == "Foul":
            fouls += 1
            if incident[0] < 15:
                fouls15 += 1
            elif incident[0] < 30:
                fouls30 += 1
            elif incident[0] < 45:
                fouls45 += 1
            elif incident[0] < 60:
                fouls60 += 1
            elif incident[0] < 75:
                fouls75 += 1
            else:
                fouls90 += 1
    fouls15 = round(fouls15 / fouls, 2)
    fouls30 = round(fouls30 / fouls, 2)
    fouls45 = round(fouls45 / fouls, 2)
    fouls60 = round(fouls60 / fouls, 2)
    fouls75 = round(fouls75 / fouls, 2)
    fouls90 = round(fouls90 / fouls, 2)
    finalList = [['0:00 to 15:00', fouls15], ['15:00 to 30:00', fouls30], ["30:00 to 45:00", fouls45],
                 ["45:00 to 60:00", fouls60], ["60:00 to 75:00", fouls75], ["75:00 to 90:00", fouls90]]
    return (finalList)


# Task 5 - making charts! Thanks google for the help on these.

def plotPieChart(foulDistribution):
    myLabels = []
    num = []
    # extracting the data
    for data in foulDistribution:
        myLabels.append(data[0])
        num.append(data[1])
    pyplot.pie(x=num, labels=myLabels, autopct='%1.1f%%', startangle=90,
               colors=['tomato', 'lightgreen', 'gold', 'blue', 'orange', 'pink'])


def plotBarChart(ratingPerPlayer):
    myLabels = []
    num = []
    # extracting the data
    for data in ratingPerPlayer:
        myLabels.append(data[0])
        num.append(data[1])
    pyplot.bar(height=num, x=myLabels, width=0.5, align='center', color='lightcoral')


def main():
    incidentData = readIncidentData("IncidentData.txt")
    playerInfo = readPlayerInfo("PlayerInfo.txt")
    ratingInfo = readRatingInfo("RatingInfo.txt")
    print(f'incidentData: {incidentData}')
    print(f'playerInfo: {playerInfo}')
    print(f'ratingInfo: {ratingInfo}')
    AverageOccIncidents = computeAvgIncidentOccPerPlayer(incidentData, playerInfo, ratingInfo)
    ratingPerPlayer = computeRatingPerPlayer(AverageOccIncidents, playerInfo, ratingInfo)
    plotPieChart(foulDistribution(incidentData))
    plotBarChart(ratingPerPlayer)


if __name__ == "__main__":
    main()