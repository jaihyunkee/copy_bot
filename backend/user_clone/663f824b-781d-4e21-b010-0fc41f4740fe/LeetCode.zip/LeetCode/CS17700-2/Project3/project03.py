# CS 177 - project03.py
# This program will preprocess a player's stats in a soccer league and create plots that show statistics about the data.

from matplotlib import pyplot as plt


def readIncidentData(incident_fileName):
    res = []
    with open(incident_fileName) as f:
        while True:
            line = f.readline()
            if not line:
                break
            post_line = line.strip().split(", ")
            colon_loc = post_line[0].find(":")
            first_num = int(post_line[0][0:colon_loc])
            second_num = int(post_line[0][colon_loc + 1:len(post_line[0])])/60
            post_line[0] = first_num + second_num
            res.append(post_line)

    return res


def readPlayerInfo(player_fileName):
    res = []
    with open(player_fileName) as f:
        while True:
            line = f.readline()
            if not line:
                break
            res.append(line.strip().split(", "))

    return res


def readRatingInfo(rating_fileName):
    res = []
    with open(rating_fileName) as f:
        while True:
            line = f.readline()
            if not line:
                break

            post_line = line.strip().split(", ")
            post_line[-1] = float(post_line[-1])
            res.append(post_line)

    return res


def countPlayerIncident(IncidentData, PlayerInfo, RatingInfo):
    playerStats = []
    teams = set()
    for i in range(len(PlayerInfo)):
        playerStats.append([PlayerInfo[i][0]])
        for j in range(len(RatingInfo)):
            playerStats[i].append(0)

    for i in range(len(IncidentData)):
        teams.add(IncidentData[i][3])
        for j in range(len(playerStats)):

            if playerStats[j][0] == IncidentData[i][2]:
                for k in range(len(RatingInfo)):
                    if IncidentData[i][1] == RatingInfo[k][0]:
                        playerStats[j][k + 1] += 1
    teams_num = len(teams)
    print(f'PlayerStats: {playerStats}')
    for playerStat in playerStats:
        for i in range(1, len(playerStat)):
            playerStat[i] = playerStat[i] / teams_num

    return playerStats


def countScore(PlayerIncident, PlayerInfo, RatingInfo):
    ret = []
    for i in range(len(PlayerIncident)):
        print(f'PlayerIncident: {PlayerIncident}')
        # print(f'PlayerInfo: {PlayerInfo}')
        player_score = [PlayerInfo[i][0]]
        score = 6.0
        for j in range(len(RatingInfo)):
            # print(f'RatingInfo: {RatingInfo}')
            # print(PlayerIncident[i][j + 1])
            score += PlayerIncident[i][j + 1] * RatingInfo[j][2] * coef(PlayerInfo[i][1], RatingInfo[j][1])

        if score > 10.0:
            score = 10.0
        elif score < 0.0:
            score = 0.0
        player_score.append(score)
        ret.append(player_score)

    return sorted(ret, key= lambda x: x[1])


def coef(position, incident):
    if position == "Forward":
        if incident == "O":
            return 1.0
        elif incident == "D":
            return 0.5
        else:
            return 0.75
    elif position == "Midfielder":
        return 0.75
    elif position == "Back":
        if incident == "O":
            return 0.5
        elif incident == "D":
            return 1.0
        else:
            return 0.75


def foulDistribution(IncidentData):
    foulDist = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    ret = [['0:00 to 15:00'], ['15:00 to 30:00'], ['30:00 to 45:00'], ['45:00 to 60:00'],
           ['60:00 to 75:00'], ['75:00 to 90:00']]
    for i in range(len(IncidentData)):
        if IncidentData[i][1] == 'Foul':
            if IncidentData[i][0] < 15.00:
                foulDist[0] += 1
            elif IncidentData[i][0] < 30.00:
                foulDist[1] += 1
            elif IncidentData[i][0] < 45.00:
                foulDist[2] += 1
            elif IncidentData[i][0] < 60.00:
                foulDist[3] += 1
            elif IncidentData[i][0] < 75.00:
                foulDist[4] += 1
            else:
                foulDist[5] += 1

    for j in range(len(foulDist)):
        ret[j].append(foulDist[j] / sum(foulDist))

    return ret


def plotPieChart(foulDist):
    plt.clf()
    percent = [i[1] for i in foulDist]
    timeFrame = [i[0] for i in foulDist]
    plt.pie(percent, autopct='%1.1f%%', startangle=90,
            colors=['tomato', 'lightgreen', 'gold', 'blue', 'orange', 'pink'])
    plt.axis('equal')
    plt.legend(timeFrame, loc='lower left')
    plt.savefig('plotPieChart.pdf')


def plotBarChart(countScore):
    plt.clf()
    players = [i[0] for i in countScore]
    scores = [i[1] for i in countScore]
    plt.bar(x=players, height=scores, width=0.5, align='center', color='lightcoral')
    plt.title("Score Statistics")
    plt.xticks(rotation=-15)
    plt.ylabel("Average Score")
    plt.savefig('plotBarChart.pdf')


def main():
    incidentList = readIncidentData("IncidentData.txt")
    playerList = readPlayerInfo('PlayerInfo.txt')
    ratingList = readRatingInfo('RatingInfo.txt')

    PlayerIncident = countPlayerIncident(incidentList, playerList, ratingList)

    scores = countScore(PlayerIncident, playerList, ratingList)
    foulList = foulDistribution(incidentList)
    print(f'incidentList: {incidentList}')
    print(f'playerList: {playerList}')
    print(f'ratingList: {ratingList}')
    print(f'scores: {scores}')
    print(f'foulList: {foulList}')
    plotPieChart(foulList)
    plotBarChart(scores)


if __name__ == "__main__":
    main()
