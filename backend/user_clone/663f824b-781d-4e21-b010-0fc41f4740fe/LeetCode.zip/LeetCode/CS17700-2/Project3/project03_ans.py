#
#
#
import matplotlib.pyplot as pyplot
import random


def readIncidentData(filename):
    f = open(filename, 'r')
    content = f.read()
    lines = content.split("\n")
    id = []
    for i in lines:
        l = i.split(", ")
        times = l[0].split(":")
        minute = int(times[0])
        second = float(times[1]) / 60
        time = minute + second
        id.append([time, l[1], l[2], l[3]])
    f.close()
    return id


def readPlayerInfo(filename):
    f = open(filename, "r")
    content = f.read()
    lines = content.split("\n")
    pi = []

    for i in lines:
        l = i.split(", ")
        pi.append([l[0], l[1]])

    f.close()
    return pi


def readRatingInfo(filename):
    f = open(filename, "r")
    content = f.read()
    lines = content.split("\n")
    ri = []
    for i in lines:
        l = i.split(", ")
        ri.append([l[0], l[1], float(l[2])])
    f.close()
    return ri


def computeAvgIncidentOccPerPlayer(IncidentData, PlayerInfo, RatingInfo):
    pi = []
    team = set()
    for i in range(len(PlayerInfo)):
        pi.append([PlayerInfo[i][0]])
        for j in range(len(RatingInfo)):
            pi[i].append(0)
    for i in range(len(IncidentData)):
        team.add(IncidentData[i][3])
        for j in range(len(pi)):
            if pi[j][0] == IncidentData[i][2]:
                for k in range(len(RatingInfo)):
                    if IncidentData[i][1] == RatingInfo[k][0]:
                        pi[j][k + 1] += 1
    matches = len(team)
    for i in range(len(pi)):
        for k in range(len(RatingInfo)):
            pi[i][k + 1] /= matches
    return pi


def coef(Position, Incident):
    if Position == 'Forward':
        if Incident == 'O':
            return 1.0
        elif Incident == 'G':
            return 0.75
        elif Incident == 'D':
            return 0.5
    if Position == 'Midfielder':
        return 0.75
    if Position == 'Back':
        if Incident == 'O':
            return 0.5
        elif Incident == 'G':
            return 0.75
        elif Incident == 'D':
            return 1.0


def computeRatingPerPlayer(AverageOccIncidents, playerInfo, RatingInfo):
    st = []
    # print(PlayerIncident)
    for i in range(len(AverageOccIncidents)):
        score = 6.0
        for j in range(len(RatingInfo)):
            score = score + AverageOccIncidents[i][j + 1] * RatingInfo[j][2] * coef(playerInfo[i][1], RatingInfo[j][1])
        if score > 10.0:
            score = 10.0
        if score < 0.0:
            score = 0.0
        st.append([playerInfo[i][0]])
        st[i].append(score)
    return sorted(st, key=lambda x: x[1])


def foulDistribution(IncidentData):
    fd = [['0:00 to 15:00', 0], ['15:00 to 30:00', 0], ['30:00 to 45:00', 0], ['45:00 to 60:00', 0],
          ['60:00 to 75:00', 0], ['75:00 to 90:00', 0]]
    totalfouls = 0
    for i in range(len(IncidentData)):
        if IncidentData[i][1] == 'Foul':
            totalfouls += 1
            row = int(IncidentData[i][0] / 15.0)
            fd[row][1] += 1
    for i in range(len(fd)):
        fd[i][1] /= totalfouls
    return fd


def plotPieChart(foulDistribution):
    pyplot.clf()
    times = ['0:00 to 15:00', '15:00 to 30:00', '30:00 to 45:00', '45:00 to 60:00', '60:00 to 75:00', '75:00 to 90:00']
    amounts = []
    for i in range(6):
        amounts.append(foulDistribution[i][1])
    colors = ['tomato', 'lightgreen', 'gold', 'blue', 'orange', 'pink']

    patches, texts, autopct = pyplot.pie(amounts, colors=colors, autopct='%1.1f%%', shadow=False, startangle=90)
    pyplot.legend(patches, times, loc="lower left")
    pyplot.axis('equal')
    pyplot.savefig('plotPieChart.pdf')


def plotBarChart(score):
    pyplot.clf()
    names = []
    data = []
    pos = []
    # print(score)

    for i in range(len(score)):
        m = score[i]
        names.append(m[0])
        data.append(m[1])
        pos.append(i + 1)
    bar = pyplot.bar(pos, data, width=0.5, color='lightcoral', align='center')
    pyplot.xticks(pos, names)
    pyplot.axis([0, len(names) + 1, 0, max(data) + 1])
    pyplot.setp(pyplot.xticks()[1], rotation=-15)
    pyplot.ylabel("Average Score")
    pyplot.title("Score Statistics")
    pyplot.savefig('plotBarChart.pdf')


def main():
    incidentList = readIncidentData("IncidentData.txt")

    playerList = readPlayerInfo("PlayerInfo.txt")

    ratingList = readRatingInfo("RatingInfo.txt")

    temp = computeAvgIncidentOccPerPlayer(incidentList, playerList, ratingList)
    # print(temp)
    scores = computeRatingPerPlayer(computeAvgIncidentOccPerPlayer(incidentList, playerList, ratingList), playerList,
                                    ratingList)
    print(scores)
    foulList = foulDistribution(incidentList)

    plotBarChart(scores)
    plotPieChart(foulList)


if __name__ == "__main__":
    # createList(40)
    main()




