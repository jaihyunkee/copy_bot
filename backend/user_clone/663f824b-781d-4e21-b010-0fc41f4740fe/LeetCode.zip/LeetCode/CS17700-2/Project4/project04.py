"""
TODO Required/Helper variables and/or constants:
Used throughout the project
"""
# constants and variables
PLAYER_ID = 1  # keeps track of the player
BG = color(180, 135, 60)  # bg color
BG_dark = color(150, 100, 30)  # darker shade of bg color
LAST = []  # keeps a memory of the last input made
GAMEOVER = False  # decides whether game has ended

# 2D array to store the circles on the grid
rows, cols = (10, 10)
grid = [[0 for i in range(cols)] for j in range(rows)]  # TODO: LEARN ABOUT THIS MORE

"""
TODO Required method:
Setup for all the constant settings within the window
"""


def setup():
    size(800, 600)  # size of the window
    textSize(35)  # sets the size of the text
    textAlign(LEFT, CENTER)  # aligns the text to be center aligned and center positioned
    strokeWeight(1)  # weight of the strokes


"""
TODO Required method:
Drawing function that will be called every time a frame refreshes
"""


def draw():
    background(BG)

    # Gameover Conditional Statement:
    # Checks whether or not the game has ended using GAMEOVER,
    # which is a global variable that is modified when a winner is found
    if GAMEOVER is True:
        winner = "PLAYER " + str(PLAYER_ID) + "\nWINS!"
        text(winner, 655, 300);

    # Creating the 10 by 10 Grid:
    # Uses a for loop to create a horizontal line and a vertical line
    # on each iteration using line(x1, y1, x2, y2)
    for i in range(0, 11):
        shift = 60 * i
        line(0, shift, 600, shift)
        line(shift, 0, shift, 600)

    # Creating the Player Number Text and the Undo Button:
    # Uses a rectangle that is situated within the grid adjustment
    # to make it easier to retrieve its location
    fill(BG_dark)
    turn = "PLAYER " + str(PLAYER_ID)
    text(turn, 655, 80)  # Player turn text is positioned here
    rect(660, 120, 120, 60, 5)  # Creates the rectangle using the same fill from line 40
    fill(BG)  # Fills the text inside the rectangle with a different color
    text("UNDO", 675, 143)

    # Drawing the circles in each update
    # Offset by [60 * (index + 1)] - 30 to make sure the circle is
    #   at the center of the grid cells
    for x in range(0, 10):
        for y in range(0, 10):
            if grid[x][y] == 0:
                pass
            elif grid[x][y] == 1:
                fill(BG_dark)
                ellipse(60 * (x + 1) - 30, 60 * (y + 1) - 30, 50, 50)
            else:
                fill(255)  # White color
                ellipse(60 * (x + 1) - 30, 60 * (y + 1) - 30, 50, 50)

    setup()  # RESETS all the setup parameters


"""
TODO Required method:
Gets the location of where the mouse is
    when it is pressed normalized to the grid
"""


def getClickedSquare():
    return (int(mouseX / 60), int(mouseY / 60))


"""
Helper method:
Swaps the player between first and second for turns
"""


def swap(player):
    global PLAYER_ID
    if PLAYER_ID == 1:
        PLAYER_ID = 2  # set to next player
    else:
        PLAYER_ID = 1


"""
TODO Required method:
Determine if there is a winner given the current state of the game
    There might be more ways to do this...
"""


def checkWin():
    global GAMEOVER
    for x in range(0, 10):
        for y in range(0, 10):
            play_id = grid[x][y]
            if (
                    h_win(x, y, play_id) != -1 or  # horizontal win starting at x, y
                    v_win(x, y, play_id) != -1 or  # vertical win starting at x, y
                    d_win(x, y, play_id) != -1  # diagonal win starting at x, y
            ):
                GAMEOVER = True


# Checks whether or not there is a possible horizontal 5-match
def h_win(x, y, play_id):
    if (x > 5 or play_id == 0): return -1
    for i in range(x + 1, x + 5):
        if grid[i][y] != play_id: return -1
    return play_id


# Checks whether or not there is a possible vertical 5-match
def v_win(x, y, play_id):
    if (y > 5 or play_id == 0): return -1
    for i in range(y + 1, y + 5):
        if grid[x][i] != play_id: return -1
    return play_id


# Checks whether or not there is a possible diagonal 5 - match
def d_win(x, y, play_id):
    if (
            x <= 5 and y <= 5 and play_id != 0 and
            grid[x + 1][y + 1] == play_id and
            grid[x + 2][y + 2] == play_id and
            grid[x + 3][y + 3] == play_id and
            grid[x + 4][y + 4] == play_id
    ):
        return play_id
    else:
        if (
                x <= 5 and y >= 4 and play_id != 0 and
                grid[x + 1][y - 1] == play_id and
                grid[x + 2][y - 2] == play_id and
                grid[x + 3][y - 3] == play_id and
                grid[x + 4][y - 4] == play_id
        ):
            return play_id
        else:
            return -1


"""
TODO Required method:
Handles any event when the mouse is pressed, this is where
    the circle positions and undo buttons are handled
"""


def mousePressed():
    global LAST
    if mouseButton == LEFT and GAMEOVER == False:
        pos = getClickedSquare()  # Gets the mouse location based on the 60 by 60 grid
        x, y = pos  # Converts it to a tuple
        if pos == (11, 2) or pos == (12, 2):
            if not LAST:  # If the list of moves is empty, do nothing
                pass
            else:
                x, y = LAST.pop()  # Get the last move by removing it
                grid[x][y] = 0  # Undo the last move
                swap(PLAYER_ID)  # Return to the previous turn
        else:
            if pos <= (9, 9):
                if grid[x][y] == 0:
                    LAST.append(pos)  # Set the current move to the last move made
                    grid[x][y] = PLAYER_ID  # Update the grid to mark ownership
                    checkWin()  # Check if anyone has WON at this stage
                    if GAMEOVER is False:  # Move to next player if game still goes on
                        swap(PLAYER_ID)
                else:  # YOU CAN'T OVERWRITE SOMEONE ELSE'S MOVE...
                    pass
            else:
                pass
