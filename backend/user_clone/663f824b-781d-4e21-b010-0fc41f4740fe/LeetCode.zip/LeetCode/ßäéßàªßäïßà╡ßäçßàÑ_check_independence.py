import numpy as np
import pandas as pd


# you can use this table as an example
distr_table = pd.DataFrame({
    'X': [0, 0, 1, 1],
    'Y': [1, 2, 1, 2],
    'pr': [0.3, 0.25, 0.15, 0.3]
})

class CheckIndependence:

    def __init__(self):
        self.version = 1

    def check_independence(self, distr_table: pd.DataFrame):
        # write your solution here
        
        # check independence
        unique_x = distr_table['X'].unique()
        unique_y = distr_table['Y'].unique()
        
        marginal_Y_prob = {i: sum(distr_table[distr_table['Y'] == i]['pr']) for i in unique_y}
        marginal_X_prob = {i: sum(distr_table[distr_table['X'] == i]['pr']) for i in unique_x}

        inde_count = 0
        for idx, row in distr_table.iterrows():
            inde_count += np.isclose(row['pr'], marginal_X_prob[row['X']] * marginal_Y_prob[row['Y']], atol=1e-12)
            
        is_independence = True if inde_count == len(distr_table) else False
        
        # cov
        mu_x = 0
        mu_y = 0
        
        for idx, row in distr_table.iterrows():
            mu_x += row['X'] * row['pr']
            mu_y += row['Y'] * row['pr']

        cov = 0
        for idx, row in distr_table.iterrows():
            cov += row['pr'] * (row['X'] - mu_x) * (row['Y'] - mu_y)
        
        # correlation coefficient
        ## SD
        sd_x, sd_y = 0, 0
        for idx, row in distr_table.iterrows():
            sd_x += row['pr'] * (row['X'] - mu_x)**2
            sd_y += row['pr'] * (row['Y'] - mu_y)**2
            
        sd_x, sd_y = sd_x**(1/2), sd_y**(1/2)

        ## CC
        if sd_x > 0 and sd_y > 0:
            corr = cov / (sd_x * sd_y)
        else:
            corr = 0
        
        return {'are_independent': is_independence, 'cov': cov, 'corr': corr}
    
# sol = CheckIndependence()
# print(sol.check_independence(distr_table))
