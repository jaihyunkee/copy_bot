import sys

# def Solution():
#     dat = [1] * 1000001
#     for i in range(2, len(dat)):
#         for j in range(i, len(dat), i):
#             dat[j] += i
#
#     res = []
#     for d in range(len(dat)):
#         if d + 1 == dat[d]:
#             res.append(d)
#
#     print(res[:20])
#
#     cin = int(sys.stdin.readline()[:-1])
#     p_num = list(filter(lambda k: k < cin, res))
#     # [0, 2, 3, 5, 7]
#     l, r = 1, len(p_num) - 1
#
#     result = []
#
#     while cin != 0:
#
#         while not l > r:
#             if res[r] + res[l] > cin:
#                 r -= 1
#             elif res[r] + res[l] < cin:
#                 l += 1
#             else:
#                 result.append(f'{cin} = {res[l]} + {res[r]}')
#                 break
#
#         cin = int(sys.stdin.readline()[:-1])
#
#         p_num = list(filter(lambda k: k < cin, res))
#         l, r = 1, len(p_num) - 1
#
#     return '\n'.join(result)

def Solution():
    dat = [True] * 1000001

    for i in range(2, 1001):
        if dat[i]:
            for j in range(i + i, 1000001, i):
                dat[j] = False

    result = []
    while True:
        cin = int(sys.stdin.readline())
        if not cin:
            break
        for i in range(3, len(dat)):
            if dat[i] and dat[cin - i]:
                result.append(f'{cin} = {i} + {cin - i}')
                break

    return '\n'.join(result)


if __name__ == "__main__":
    sys.stdout.write(Solution())
