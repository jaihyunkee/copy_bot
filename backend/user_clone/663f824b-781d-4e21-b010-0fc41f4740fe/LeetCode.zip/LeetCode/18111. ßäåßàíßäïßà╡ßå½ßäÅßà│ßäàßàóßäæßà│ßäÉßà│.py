"""
이 문제 진짜 끔찍하다
여러가지 문제가 있다.
1. 내가 풀이를 잘못 생각했다. 모든 블럭을 돌아서 그때 그때 인벤토리와 시간을 수정해주는 것 보다는,
모든 블럭을 다 돌아서 다 돌때까지 가져갈 수 있는 블럭이 몇개인지, 추가적으로 쌓아야 하는 블럭이 몇개인지 파악을 다 해놓은 다음에,
그 값들로 걸리는 시간을 계산하는것이다.

실생활로 비교해본다면, 군대에서 생활관 애들과 같이 장비검사를 할때에, 어떤 병사의 장비가 더 있거나 덜 있을때,
그 병사의 장비 수를 바로바로 맞추는것이 아니라, 모든 병사의 장비 상황을 먼저 확인하면서 부족한수와 초과된 장비수를 모두 파악한 후에,
그 숫자로 재배치 하는 상황이겠다.

2. 파이썬 참 느리다. 무슨 방법이든, 내가 처음에 생각한 문제도 답이 맞다. 하지만 시간 초과가 너무 많이 뜬다. CPP로 빨리 갈아 타야겠다.
"""
import sys

N, M, B = map(int, sys.stdin.readline().split())
grid = [list(map(int, sys.stdin.readline().split())) for _ in range(N)]
min_range = min(min([i for i in grid]))
max_range = max(max([i for i in grid]))

min_time = float('inf')
min_lvl = 0


for target_height in range(min_range, max_range + 1):
    use_block = 0
    take_block = 0
    for i in range(N):
        for j in range(M):
            diff = grid[i][j] - target_height
            if diff > 0:
                take_block += diff
            else:
                use_block -= diff

    if use_block > B + take_block:
        continue
    time = (take_block * 2) + use_block

    if time <= min_time:
        min_time = time
        min_lvl = target_height

print(min_time, min_lvl)
