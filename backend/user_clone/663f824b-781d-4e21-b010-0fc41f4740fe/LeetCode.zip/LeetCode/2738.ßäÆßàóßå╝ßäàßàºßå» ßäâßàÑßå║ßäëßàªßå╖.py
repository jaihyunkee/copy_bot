import sys
def Solution():
    N, M = map(int, sys.stdin.readline().split(" "))
    max_cin = max(N, M)
    board1, board2 = [], []
    res_board = []
    for n in range(N):
        board1.append(list(map(int, sys.stdin.readline().split(" "))))

    for n in range(N):
        board2.append(list(map(int, sys.stdin.readline().split(" "))))

    for i in range(N):
        res_board.append([])
        for j in range(M):
            res_board[i].append(board1[i][j] + board2[i][j])

    for i in res_board:
        print(" ".join(map(str, i)))
    return None


if __name__ == "__main__":
    Solution()