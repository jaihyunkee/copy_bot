"""
https://swexpertacademy.com/main/talk/solvingClub/problemView.do?solveclubId=AYFCb80K3PsDFAR7&contestProbId=AV5LnipaDvwDFAXc&probBoxId=AYFGEj8qkn4DFAR7&type=PROBLEM&problemBoxTitle=D6&problemBoxCnt=8
"""

from collections import defaultdict, deque


def lca(a, b):
    while depth[a] != depth[b]:
        if depth[a] > depth[b]:
            a = parent[a]
        else:
            b = parent[b]

    while a != b:
        a = parent[a]
        b = parent[b]
    return a


TC = int(input())
for tc in range(1, TC + 1):
    N = int(input())
    in_arr = list(map(int, input().split()))
    graph = defaultdict(list)
    depth = defaultdict(int)
    parent = [0, 0] + in_arr
    depth[1] = 0

    for i, x in enumerate(in_arr):
        depth[i + 2] = depth[x] + 1
        graph[x].append(i + 2)

    answer, preNode = 0, 1
    queue = deque([1])
    visit = [False] * (N + 2)
    visit[1] = True
    temp = 0

    while queue:
        node = queue.popleft()
        if node != 1:
            temp = (depth[node] + depth[preNode] - 2 * depth[lca(node, preNode)])
            answer += temp

        for next_node in graph[node]:
            if not visit[next_node]:
                visit[next_node] = True
                queue.append(next_node)

        preNode = node

    print(f'#{tc} {answer}')
