"""
https://pangsblog.tistory.com/8
"""

import sys


def Solution():
    T = int(sys.stdin.readline())
    res = []
    dp = [0] * 11
    dp[1], dp[2], dp[3] = 1, 2, 4

    for t in range(T):
        n = int(sys.stdin.readline())
        if n <= 3:
            res.append(dp[n])
            continue
        for i in range(4, n+1):
            if dp[i] == 0:
                dp[i] = dp[i-1] + dp[i-2] + dp[i-3]

        res.append(dp[n])

    return '\n'.join(map(str, res))

if __name__ == "__main__":
    print(Solution())
