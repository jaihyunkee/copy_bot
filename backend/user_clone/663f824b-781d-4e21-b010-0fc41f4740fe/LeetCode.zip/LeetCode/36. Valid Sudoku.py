def isValid3Grid(row, col, board):
    dat = [0] * 9
    for i in range(3):
        for j in range(3):
            if board[i + row][j + col] == '.':
                continue
            dat[int(board[i + row][j + col]) - 1] += 1

    if any(item > 1 for item in dat):
        return False
    return True


class Solution(object):

    def isValidSudoku(self, board):
        """
        :type board: List[List[str]]
        :rtype: bool
        """

        # row validation checking
        for i in range(len(board)):
            for j in board[i]:
                if j == ".":
                    continue
                elif board[i].count(j) > 1:
                    return False

        # column validation checking
        for i in range(len(board)):
            dat = [0] * 10
            for j in range(len(board[i])):
                if board[j][i] == ".":
                    continue
                else:
                    dat[int(board[j][i])] += 1

            if any(item > 1 for item in dat):
                return False

        # 3 * 3 grid validation checking
        row = 0
        while row < 9:
            col = 0
            while col < 9:
                if not isValid3Grid(row, col, board):
                    return False
                col += 3
            row += 3

        return True


sol = Solution()
board = [["5", "3", ".", ".", "7", ".", ".", ".", "."]
    , ["6", ".", ".", "1", "9", "5", ".", ".", "."]
    , [".", "9", "8", ".", ".", ".", ".", "6", "."]
    , ["8", ".", ".", ".", "6", ".", ".", ".", "3"]
    , ["4", ".", ".", "8", ".", "3", ".", ".", "1"]
    , ["7", ".", ".", ".", "2", ".", ".", ".", "6"]
    , [".", "6", ".", ".", ".", ".", "2", "8", "."]
    , [".", ".", ".", "4", "1", "9", ".", ".", "5"]
    , [".", ".", ".", ".", "8", ".", ".", "7", "9"]]
for i in range(len(board)):
    print(board[i])

print(sol.isValidSudoku(board))
