import sys

def Solution():
    n = sys.stdin.readline()
    A = list(map(int, sys.stdin.readline()[:-1].split(' ')))
    A.sort()

    if n == 1:
        res = A[0] ** 2
    else:
        res = A[0] * A[int(n)-1]
    return res

if __name__ == "__main__":
    print(Solution())
    
"""
If the list length is 1, then -1'th index return the only element in the list

N=int(input())
data=list(map(int,input().split()))

data.sort()
print(data[0]*data[-1])
"""
