def validPaths(arr_copy, point, visited):
    i = point[0]
    j = point[1]
    new = []
    if 0 <= i - 1 and arr_copy[i - 1][j] >= 0 and (i - 1, j) not in visited:
        new.append([i - 1, j])
    if i + 1 < len(arr_copy) and arr_copy[i + 1][j] >= 0 and (i + 1, j) not in visited:
        new.append([i + 1, j])
    if 0 <= j - 1 and arr_copy[i][j - 1] >= 0 and (i, j - 1) not in visited:
        new.append([i, j - 1])
    if j + 1 < len(arr_copy) and arr_copy[i][j + 1] >= 0 and (i, j + 1) not in visited:
        new.append([i, j + 1])
    return new


def BFS(arrC, start, dest):
    queue = []
    arr_copy = [row[:] for row in arrC]
    visited = set()
    visited.add((start[0], start[1]))
    paths = validPaths(arr_copy, start, visited)
    for i in paths:
        arr_copy[i[0]][i[1]] += arr_copy[start[0]][start[1]]
        queue.append(i)
    while len(queue) != 0:
        i, j = queue.pop(0)
        if (i, j) not in visited:
            visited.add((i, j))
            if i == dest[0] and j == dest[1]:
                return arr_copy[i][j]
            paths = validPaths(arr_copy, [i, j], visited)
            for a in paths:
                print(queue)
                queue.append(a)
                arr_copy[a[0]][a[1]] += arr_copy[i][j]
    return -1


T = int(input())
# 여러개의 테스트 케이스가 주어지므로, 각각을 처리합니다.
for test_case in range(1, T + 1):
    N, M = map(int, input().split())
    arr = []
    index = []
    obstacles = []
    empty = [[0] * N for i in range(N)]
    for i in range(N):
        arr.append(list(map(int, input().split())))
    for i in range(N):
        for j in range(N):
            cur = arr[i][j]
            for k in range(1, M + 1):
                if k == cur:
                    index.append([k, (i, j)])
            if cur == 9:
                obstacles.append((i, j))
                empty[i][j] = -float('inf')
    index = sorted(index, key=lambda x: x[0])
    perm = 1
    for i in range(len(index)):
        if i < len(index) - 1:
            empty[index[i][1][0]][index[i][1][1]] = 1
            curPerm = BFS(empty, index[i][1], index[i + 1][1])
            empty[index[i][1][0]][index[i][1][1]] = 0
            if curPerm < 0:
                curPerm = 0
            perm *= curPerm
    print(f"#{test_case} {perm}")
