class Solution(object):
    def addBinary(self, a, b):
        """
        :type a: str
        :type b: str
        :rtype: str
        """
        a = a[::-1]
        b = b[::-1]

        result = 0
        power = 0
        for c in a:
            if c == "1":
                result += 2 ** power
            power += 1
        power = 0
        for c in b:
            if c == "1":
                result += 2 ** power
            power += 1

        bin = ""

        if result == 0:
            return "0"

        while result > 0:
            if result % 2 == 0:
                bin = "0" + bin
            else:
                bin = "1" + bin

            result = result // 2

        return bin


sol = Solution()
print(sol.addBinary("0", "0"))
