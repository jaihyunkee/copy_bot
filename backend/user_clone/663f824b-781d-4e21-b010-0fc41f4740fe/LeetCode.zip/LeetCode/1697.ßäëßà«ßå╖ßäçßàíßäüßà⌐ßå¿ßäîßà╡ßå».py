# import sys
# from collections import deque

# visited = set()

# loc, K = map(int, sys.stdin.readline().split())

# queue = deque()
# queue.append((loc, 0))
# visited.add(loc)

# while queue:
#     loc, time = queue.popleft()
#     if loc == K:
#         print(time)
#         break

#     for nloc in [loc + 1, loc - 1, loc * 2]:
#         if nloc not in visited and 0 <= nloc <= 100000:
#             queue.append((nloc, time + 1))
#             visited.add(nloc)


import sys
from collections import deque

N, K = map(int, sys.stdin.readline().split())
queue = deque([])

loc, cnt = N, 0

queue.append((loc, cnt))
isVisited = set()
isVisited.add(loc)

while queue:
    loc, cnt = queue.popleft()

    if loc == K:
        print(cnt)
        break
    
    for nloc in [loc-1, loc+1, loc*2]:
        if nloc not in isVisited and 0 <= nloc <= 100000:
            queue.append((nloc, cnt+1))
            isVisited.add(nloc)


