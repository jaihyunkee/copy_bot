from collections import deque
from copy import deepcopy

moves = [(0, 1), (0, -1), (1, 0), (-1, 0)]
def inRange(i, j):
    return 0 <= i < N and 0 <= j < N and not visited[i][j]

def bfs(grid):
    res_cnt = 0
    for y in range(N):
        for x in range(N):
            if not visited[y][x]:
                queue = deque()
                queue.append((y, x))
                visited[y][x] = 1
                token = grid[y][x]

                while queue:
                    i, j = queue.popleft()
                    for mi, mj in moves:
                        ni, nj = i + mi, j + mj
                        if inRange(ni, nj) and grid[ni][nj] == token:
                            queue.append((ni, nj))
                            visited[ni][nj] = 1
                res_cnt += 1
    return res_cnt

N = int(input())
grid = [list(input()) for _ in range(N)]
second_grid = deepcopy(grid)
for i in range(N):
    for j in range(N):
        if second_grid[i][j] == 'G':
            second_grid[i][j] = 'R'
visited = [[0] * N for _ in range(N)]
a = bfs(grid)
visited = [[0] * N for _ in range(N)]
b = bfs(second_grid)
print(a, b)
