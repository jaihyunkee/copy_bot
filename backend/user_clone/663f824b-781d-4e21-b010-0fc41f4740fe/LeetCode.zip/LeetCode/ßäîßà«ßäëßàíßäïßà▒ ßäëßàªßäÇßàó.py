from collections import Counter

dice = list(map(int, input().split()))

ret = 0

d = Counter(dice)
if max(d.values()) == 3:
    ret += dice[0] * 1000 + 10000
elif max(d.values()) == 1:
    ret += max(dice) * 100
else:
    for d_key in d:
        if d[d_key] == 2:
            ret += d_key * 100 + 1000

print(ret)