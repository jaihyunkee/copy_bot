import heapq

T = int(input())

""" Time exceed
def inRange(i: int, j: int, size: int):
    return 0 <= i < size and 0 <= j < size


def dfs(i: int, j: int, cur_time: int):
    global min_time

    if i == N - 1 and j == N - 1:
        if cur_time < min_time:
            min_time = cur_time
        return

    for mi, mj in [(0, 1), (0, -1), (1, 0), (-1, 0)]:
        new_i, new_j = i + mi, j + mj
        if inRange(new_i, new_j, N):
            if not isUsed[new_i][new_j]:
                isUsed[new_i][new_j] = True
                dfs(new_i, new_j, cur_time + grid[new_i][new_j])
                isUsed[new_i][new_j] = False


for t in range(T):
    N = int(input())
    isUsed = [[False] * N for _ in range(N)]
    grid = []
    for n in range(N):
        grid.append(list(map(int, list(input()))))
    isUsed[0][0] = True

    min_time = float('inf')
    dfs(0, 0, grid[0][0])
    print(min_time)
"""


def dijkstra(i, j):
    pq = []
    heapq.heappush(pq, (grid[i][j], i, j))
    while pq:
        dist, i, j = heapq.heappop(pq)
        for di, dj in [(0, 1), (0, -1), (1, 0), (-1, 0)]:
            ni, nj = i + di, j + dj
            if 0 <= ni < N and 0 <= nj < N:
                new_dist = grid[ni][nj] + distance[i][j]
                if new_dist < distance[ni][nj]:
                    distance[ni][nj] = grid[ni][nj] + distance[i][j]
                    heapq.heappush(pq, (distance[ni][nj], ni, nj))


for t in range(1, T + 1):
    N = int(input()),
    grid, distance = [], []
    for _ in range(N):
        grid.append(list(map(int, list(input()))))
        distance.append([float('inf')] * N)
    distance[0][0] = grid[0][0]
    dijkstra(0, 0)

    print(f'#{t} {distance[N - 1][N - 1]}')
