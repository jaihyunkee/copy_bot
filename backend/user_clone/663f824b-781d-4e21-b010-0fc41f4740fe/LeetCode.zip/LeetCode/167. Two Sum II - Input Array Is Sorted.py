"""
To use Two Pointer
1) the given array should be sorted in non-decreasing order ex) 1,2,2,4
because two pointers are moving by comparing the sum to the target.
1.1) if the sum is greater than the target, move the right pointer to the left
1.2) if the sum is less than the target, add 1 to the elft pointer
"""

class Solution(object):
    def twoSum(self, numbers, target):
        """
        :type numbers: List[int]
        :type target: int
        :rtype: List[int]
        """

        l = 0
        r = len(numbers) - 1
        while l < r:
            if numbers[l] + numbers[r] == target:
                return [l + 1, r + 1]
            elif numbers[l] + numbers[r] > target:
                r -= 1
            else:
                l += 1




sol = Solution()
print(sol.twoSum([2, 7, 11, 15], 9))
2,3,6,7,11,15
10
