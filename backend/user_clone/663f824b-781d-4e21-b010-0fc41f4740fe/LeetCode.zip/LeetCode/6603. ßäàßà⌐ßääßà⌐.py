import sys


def solve(cnt: int, S, isUsed, permu_list):
    if cnt == 6:
        print(*permu_list)
        return

    for i in range(len(S)):
        if not isUsed[i + 1]:
            if len(permu_list) == 0 or permu_list[-1] < S[i]:
                isUsed[i + 1] = True
                permu_list.append(S[i])
                solve(cnt + 1, S, isUsed, permu_list)
                permu_list.pop()
                isUsed[i + 1] = False


if __name__ == '__main__':
    line = sys.stdin.readline()
    while line != '0':

        k, S = int(line.split()[0]), list(map(int, line.split()[1:]))
        isUsed, permu_list = [False] * (k + 1), []

        solve(0, S, isUsed, permu_list)
        print()

        line = sys.stdin.readline().rstrip()


