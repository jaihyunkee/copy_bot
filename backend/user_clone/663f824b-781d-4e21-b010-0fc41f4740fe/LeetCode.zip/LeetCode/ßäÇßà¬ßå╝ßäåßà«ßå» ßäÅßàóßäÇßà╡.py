def solution(picks, minerals):
    total_pick = sum(picks)
    table = [[1,1,1],
             [5,1,1],
             [25,5,1]]
    mineral_dict = {'diamond': 0, 'iron': 1, 'stone': 2}
    min_fatigue = float('inf')
    
    def dfs(fatigue, picks_left, mdx):
        nonlocal min_fatigue

        if sum(picks_left) == 0:
            min_fatigue = min(fatigue, min_fatigue)
            return
        if fatigue > min_fatigue:
            return
        
        for pdx, pick in enumerate(picks_left):

            if picks_left[pdx] > 0:
                picks_left[pdx] -= 1
                temp = 0

                for idx in range(mdx, mdx+5):
                    if idx >= len(minerals):
                        break
                    temp += table[pdx][mineral_dict[minerals[idx]]]

                dfs(fatigue+temp, picks_left, mdx+5)

                picks_left[pdx] += 1
                
    
    dfs(0, picks, 0)
    
    return min_fatigue

picks = [1, 3, 2]	
minerals_input = ["diamond", "diamond", "diamond", "iron", "iron", "diamond", "iron", "stone"]	
answer = solution(picks, minerals_input)
print(answer)  # 최소 피로도 출력