"""
-0.6은 반올림 하면 0 + 1
"""
import sys

N = int(sys.stdin.readline())
nums = []
for _ in range(N):
    nums.append(int(sys.stdin.readline()))

avg = 0
integer = (sum(nums) // len(nums))
decimal = (sum(nums) / len(nums))
if decimal - integer >= 0.5:  # 올림
    avg = integer + 1
else:
    avg = integer


median = sorted(nums)[(len(nums)//2)]
lst = [0] * 8001
for num in nums:
    if num < 0:
        lst[abs(num) + 4000] += 1
    else:
        lst[num] += 1

mode_list = []
max_val = max(lst)
for idx, i in enumerate(lst):
    if i == max_val:
        if idx > 4000:
            mode_list.append((idx - 4000) * -1)
        else:
            mode_list.append(idx)

if len(mode_list) > 1:
    mode = sorted(mode_list)[1]
else:
    mode = mode_list[0]

scope = abs(max(nums) - min(nums))

print(avg)
print(median)
print(mode)
print(scope)
