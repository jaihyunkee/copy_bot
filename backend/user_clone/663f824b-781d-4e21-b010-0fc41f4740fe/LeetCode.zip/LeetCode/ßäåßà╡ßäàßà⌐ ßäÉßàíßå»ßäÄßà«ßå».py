from collections import deque
moves = [(0, 1), (0, -1), (1, 0), (-1, 0)]

def inRange(i, j):
    return 0 <= i < N and 0 <= j < M

def bfs(maps, start, goal, step):
    visited = set()
    queue = deque([(start[0], start[1], step)])
    visited.add((start[0], start[1]))
    while queue:
        i, j, step = queue.popleft()
        for di, dj in moves:
            ti, tj = i+di, j+dj
            if inRange(ti, tj) and maps[ti][tj] != 'X' and (ti, tj) not in visited:
                queue.append((ti, tj, step+1))
                visited.add((ti, tj))
                if (ti, tj) == goal:
                    return step+1
    return 0

def solution(maps):
    global N, M
    N, M = len(maps), len(maps[0])
    maps = [list(m) for m in maps]

    for n in range(N):
        for m in range(M):
            if maps[n][m] == 'S':
                start = (n, m)
            if maps[n][m] == 'L':
                lever = (n, m)
            if maps[n][m] == 'E':
                exit = (n, m)
    
    lever_step = bfs(maps, start, lever, 0)
    if lever_step:
        exit_step = bfs(maps, lever, exit, lever_step)
        if exit_step:
            ret = exit_step
        else:
            ret = -1
    else:
        ret = -1
                
            
    
    
    return ret