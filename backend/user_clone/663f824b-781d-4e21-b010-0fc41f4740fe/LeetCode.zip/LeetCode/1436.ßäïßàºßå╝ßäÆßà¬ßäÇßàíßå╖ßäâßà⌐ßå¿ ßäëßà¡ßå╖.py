import sys
def Solution():
    N = int(sys.stdin.readline())
    num = 1
    cnt = 0

    while True:
        if "666" in str(num):
            cnt += 1

        if cnt == N:
            break

        num += 1

    return num



if __name__ == "__main__":
    print(Solution())