"""
약수의 성질
n = 10
f(1) = sum(1)
f(2) = sum(1, 2)
f(3) = sum(1, 3)
f(4) = sum(1, 2, 4)
f(5) = sum(1, 5)
f(6) = sum(1, 2, 3, 6)
f(7) = sum(1, 7)
f(8) = sum(1, 2, 4, 8)
f(9) = sum(1, 3, 9)
f(10) = sum(1, 2, 5, 10)

10 // 3 = 3 => 3, 6, 9 => 이 숫자들은 3을 모두 약수로 가지고 있음
10 // 4 = 2 => 4, 8 => *
"""


# def Solution():
#     n = int(input())
#     res = 0
#     for i in range(1, n+1):
#         quotient = n // i
#         res += i * quotient
#     return res

def Solution():
    n = int(input())
    res = 0
    for i in range(1, n + 1):
        for j in range(i, n + 1, i):
            res += i
    return res


if __name__ == "__main__":
    print(Solution())
