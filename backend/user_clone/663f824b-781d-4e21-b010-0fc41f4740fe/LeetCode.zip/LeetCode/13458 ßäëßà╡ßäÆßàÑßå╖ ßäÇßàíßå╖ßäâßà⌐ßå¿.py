"""
3
3 4 5
2 2

Edge Case: when a[i] < b
1
2
3 1
"""

import sys


def Solution(a, candidateArr, b, c):
    result = 0
    for i in candidateArr:
        if i < b:
            i = 0
            result += 1
            continue
        i -= b
        result += i // c
        if i % c != 0:
            result += 1
        result += 1

    return result


a = int(sys.stdin.readline())
candidateArr = list(map(int, sys.stdin.readline().split(" ")))
b, c = map(int, sys.stdin.readline().split(" "))

print(Solution(a, candidateArr, b, c))
