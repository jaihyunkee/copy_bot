'''
Given an array of strings strs, group the anagrams together. You can return the answer in any order.

An Anagram is a word or phrase formed by rearranging the letters of a different word or phrase, typically using all the original letters exactly once.
'''


class Solution:
    def groupAnagrams(self, strs: list[str]) -> list[list[str]]:
        result = {}
        for i in strs:
            temp = ''.join(sorted(i))
            if temp in result:
                result[temp].append(i)
            else:
                result[temp] = [i]
        last = []
        for r in result:
            last.append(result[r])
        return last

'''
We take advantage of the property of dictionary which only includes one element if they have the same thing in the list
line12: if we use sorted() in string type, then it returns list.
    so we use join function to collect all the elements in the list and make it one.
line15: if the element is not in the dictionary, we make a new key and add a list with the element
    so that we can add from that moment on.
    *** on line16, `i` should be wrapped with [], list, since only `i` means string.
line18-19: this is to append only the values with pairs.
'''

sol = Solution()
print(sol.groupAnagrams(["eat", "tea", "tan", "ate", "nat", "bat"]))
#