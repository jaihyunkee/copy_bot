def LCS(X, y):
    C = [[0] * (len(Y) + 1) for _ in range(len(X) + 1)]
    for i in range(1, len(X) + 1):
        for j in range(1, len(Y) + 1):
            if X[i-1] == Y[j-1]:
                C[i][j] = C[i - 1][j - 1] + 1
            elif X[i-1] != Y[j-1]:
                C[i][j] = max(C[i - 1][j], C[i][j - 1])
    return C[len(X)][len(Y)]

TC = int(input())
for tc in range(1, TC+1):
    string_num = int(input())
    X = input()
    Y = input()
    res = LCS(X, Y)
    formatted_num = f"{res / string_num * 100:.2f}"
    print(f'#{tc} {formatted_num}')

