import sys


def Solution():
    MAX = 1000001
    dp = [1] * MAX
    for i in range(2, MAX):
        j = 1
        while i * j < MAX:
            dp[i * j] += i
            j += 1

    for d in range(1, len(dp)):
        if d + 1 == len(dp):
            break
        dp[d + 1] += dp[d]

    T = int(sys.stdin.readline().strip())
    res = []
    for t in range(T):
        n = int(sys.stdin.readline().strip())
        res.append(dp[n])

    sys.stdout.write('\n'.join(map(str, res)) + '\n')


if __name__ == "__main__":
    Solution()
