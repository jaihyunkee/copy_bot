class Solution(object):
    def isPalindrome(self, s):
        """
        :type s: str
        :rtype: bool
        """
        s = s.strip()
        s = s.lower()
        import re
        s = re.sub(r'[^a-zA-Z0-9]', '', s)
        if s == s[::-1]:
            return True
        return False

sol = Solution()
s = "A man, a plan, a canal: Panama"
print(sol.isPalindrome(s))

