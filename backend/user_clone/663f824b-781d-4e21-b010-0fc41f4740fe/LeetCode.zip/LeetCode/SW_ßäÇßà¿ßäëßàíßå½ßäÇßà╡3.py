def calcPost(pn: str):
    postfix = []
    for p in pn:
        if p == '+':
            fst = int(postfix.pop())
            snd = int(postfix.pop())
            postfix.append(fst + snd)
        elif p == '*':
            fst = int(postfix.pop())
            snd = int(postfix.pop())
            postfix.append(fst * snd)
        else:
            postfix.append(int(p))
    return postfix[0]


postfix_notations = []
for t in range(1, 11):
    N = int(input())
    exp = input()

    stack = []
    res = ""

    for e in exp:
        if e == '(':
            stack.append(e)
            continue
        elif e == ')':
            while True:
                popped = stack.pop()
                if popped == '(':
                    break
                res += popped

            continue
        elif e == '*':
            if stack[-1] == '*':
                res += stack.pop()
            stack.append(e)
            continue
        elif e == '+':
            if stack[-1] == '*':
                res += stack.pop()

            if stack[-1] == '+':
                res += stack.pop()
            stack.append(e)
            continue
        else:
            res += e
    while stack:
        res += stack.pop()

    postfix_notations.append(res)


for t in range(1, 11):
    print(f'#{t} {calcPost(postfix_notations[t - 1])}')
