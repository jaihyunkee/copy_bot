import sys


def Solution():
    n = int(sys.stdin.readline())
    board = [[0 for i in range(100)] for j in range(100)]
    temp1 = [0] * 100
    temp1[0] = 1

    for i in range(n):
        x, y = map(int, sys.stdin.readline().split(" "))
        x -= 1
        y -= 1

        for yi in range(y, y + 10):
            for xi in range(x, x + 10):
                board[yi][xi] = 1

    temp = [row.count(1) for row in board]
    result = sum(temp)

    return result


if __name__ == "__main__":
    print(Solution())
