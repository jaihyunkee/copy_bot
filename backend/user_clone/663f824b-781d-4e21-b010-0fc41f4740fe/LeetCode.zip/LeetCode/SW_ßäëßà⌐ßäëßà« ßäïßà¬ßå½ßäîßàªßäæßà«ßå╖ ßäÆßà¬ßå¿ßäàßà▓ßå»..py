"""
 Reference: https://yabmoons.tistory.com/325
 1) 각 장인들이 18개 중에서 소수 갯수만 완제품을 만들 확률 =
 각 장인들이 18개 제품 중에서 소수 갯수만 완제품을 만들 경우의 수 * 완제품을 만들 확률
 2) 18 보다 작은 소수 [2,3,5,7,11,13,17]
 3) 각각의 소수 별로 조합 갯수를 구한다 -> 18Cr -> Use DP
 4) 18Cr * 완제품을 만들 확률 -> r개의 완제품을 만들 확률 such that r -> prime number

 1) 18개 중에서 2개를 완제품으로 만들 확률
 [1, 1, 0, 0, ...]

"""


def getPrimeNum(comb):
    for i in range(1, 19):
        comb[i][0] = 1
        comb[i][i] = 1

    for i in range(2, 19):
        for j in range(1, i + 1):
            comb[i][j] = comb[i - 1][j] + comb[i - 1][j - 1]

# 성공 확률이 80%일때 2개가 완제품일 확률
# [1, 1, 0, 0, ...]
# -> 0.8 * 0.8 * 0.2 * 0.2 ...
def calculate(r: int, prob: float):
    res = 1.0
    for i in range(r):
        res *= prob
    return res

TC = int(input())
comb = [[0] * 19 for _ in range(19)]
getPrimeNum(comb)
prime_num = [2, 3, 5, 7, 11, 13, 17]
for tc in range(1, TC + 1):
    a_prob, b_prob = map(int, input().split())
    a_prob /= 100.0
    b_prob /= 100.0

    A, B = 0, 0
    for pn in prime_num:
        comb_num = comb[18][pn]
        A += comb_num * calculate(pn, a_prob) * calculate(18-pn, 1-a_prob)
        B += comb_num * calculate(pn, b_prob) * calculate(18 - pn, 1 - b_prob)
    res = round(1 - ((1 - A) * (1 - B)), 6)
    if res == 0:
        res = '0.000000'
    elif res == 1:
        res = '1.000000'

    print(f'#{tc} {res}')
