import sys

n = int(input())
m = list(map(int, input().split()))

for i in range(n-1, 0, -1):
    if m[i] > m[i-1]:
        for j in range(n-1, 0, -1):
            if m[i-1] < m[j]:
                temp = m[i-1]
                m[i-1] = m[j]
                m[j] = temp

                temp_li = m[i:]
                temp_li.reverse()
                m = m[:i] + temp_li

                print(*m)
                sys.exit(0)

else:
    print(-1)






"""
My original solution
for i in range(n-1, 0, -1):
    if m[i] > m[i-1]:
        idx = i
        for j in range(n-1, 0, -1):
            if m[i-1] < m[j]:
                temp = m[i-1]
                m[i-1] = m[j]
                m[j] = temp
                break

        temp = m[i:].copy()
        temp.reverse()
        for k in range(0, i):
            print(m[k], end=" ")

        for t in temp:
            print(t, end=" ")

        break
else:
    print(-1)
"""


