class Solution(object):
    def romanToInt(self, s):
        """
        :type s: str
        :rtype: int
        """
        dat = [0] * 26
        num = 1
        for cdx, c in enumerate(['I', 'V', 'X', 'L', 'C', 'D', 'M']):
            c = ord(c) - ord('A')
            if cdx % 2 == 0:
                dat[c] = num
            else:
                num *= 5
                dat[c] = num
                num *= 2
            
        
        ret = 0
        prev_value = 0
        for char in reversed(s):
            value = dat[ord(char)-ord('A')]
            if value < prev_value:
                ret -= value
            else:
                ret += value
            prev_value = value

        return ret
