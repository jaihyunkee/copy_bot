from collections import Counter

def solution(weights):
    answer = 0
    counter = Counter(weights)
    for weight in counter:
        if counter[weight] > 1: #nC2
            n = counter[weight]
            answer += n*(n-1)//2
    
    weights = set(weights)
    for weight in weights:
        if weight * 2/3 in weights:
            answer += counter[weight * 2/3] * counter[weight]
        if weight * 2/4 in weights:
            answer += counter[weight * 2/4] * counter[weight]
        if weight * 3/4 in weights:
            answer += counter[weight * 3/4] * counter[weight]
        
    return answer