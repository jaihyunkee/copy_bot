import heapq


def dijkstra(node):
    pq = []
    heapq.heappush(pq, (dist[node], node))
    while pq:

        distance, new_node = heapq.heappop(pq)
        for i in range(1, len(edge[new_node])):
            # print(f'node: {new_node}, i: {i}, dist[i][i]: {dist[i]}, distance + edge[node][i]: {distance + edge[node][i]}, edge[node][i]: {edge[node][i]}, distance: {distance}')
            if edge[new_node][i] != 0 and distance + edge[new_node][i] < dist[i]:
                dist[i] = distance + edge[new_node][i]
                heapq.heappush(pq, (dist[i], i))


TC = int(input())
for tc in range(1, TC + 1):
    in_arr = list(map(int, input().split()))
    N = in_arr[0]
    edge = [[0] * (N + 1) for _ in range(N + 1)]
    dist = [float('inf')] * (N+1)
    pointer = 1
    for i in range(1, len(edge)):
        for j in range(1, len(edge[i])):
            edge[i][j] = in_arr[pointer]
            pointer += 1

    min_sum = float('inf')
    for node in range(1, N + 1):

        dist = [float('inf')] * (N + 1)
        dist[node] = 0
        dijkstra(node)
        dist_sum = sum(dist[1:])
        if dist_sum < min_sum:
            min_sum = dist_sum
        dist[node] = float('inf')
    print(f'#{tc} {min_sum}')



