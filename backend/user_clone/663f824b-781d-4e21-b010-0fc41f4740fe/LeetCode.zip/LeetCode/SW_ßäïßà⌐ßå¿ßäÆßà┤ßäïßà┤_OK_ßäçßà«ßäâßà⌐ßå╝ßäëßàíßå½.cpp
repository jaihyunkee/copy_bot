#include <iostream>
#include <vector>

using namespace std;

int main(){
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    int tc;
    cin >> tc;
    for (int t = 1; t <= tc; t++) {
        int N, money;
        cin >> N >> money;
        vector<int> v;
        for (int j = 0; j < N; j++)
        {
            int price;
            cin >> price;
            v.push_back(price);
        }

        
        int res = 0;
        for (int i = 0; i < N; i++)
        {
            int cost = 0;
            for (int j = i; j < N; j++)
            {
                cost += v[j];
                if (cost == money)
                {
                    res += 1;
                    break;
                }
            }
        }
        cout << '#' << t << ' ' << res << '\n';
    }
        return 0;
}