import sys

n = int(sys.stdin.readline())
signs = sys.stdin.readline()
sign_matrix = [[0] * n for _ in range(n)]
sequence = []

pointer = 0
for i in range(n):
    for j in range(i, n):
        sign_matrix[i][j] = signs[pointer]
        pointer += 1


def isPossible(cnt):
    sum = 0
    for i in range(cnt, -1, -1):
        sum += sequence[i]
        if sign_matrix[i][cnt] == '-' and sum >= 0:
            return False
        elif sign_matrix[i][cnt] == '+' and sum <= 0:
            return False
        elif sign_matrix[i][cnt] == '0' and sum != 0:
            return False
    return True



def solve(cnt):
    if cnt == n:
        print(*sequence)
        sys.exit(0)

    if sign_matrix[cnt][cnt] == '0':  # optimization: if the diagnal grid has 0, the following number is also 0.
        sequence.append(0)
        if isPossible(cnt):
            solve(cnt + 1)
        sequence.pop()

    for i in range(-10, 11):
        sequence.append(i)
        if isPossible(cnt):
            solve(cnt + 1)
        sequence.pop()


solve(0)
