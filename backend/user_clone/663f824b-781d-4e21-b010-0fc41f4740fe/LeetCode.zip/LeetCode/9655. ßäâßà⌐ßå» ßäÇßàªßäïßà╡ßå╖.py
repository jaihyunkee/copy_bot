import sys

N = int(sys.stdin.readline())
while ㄱㄹ