import sys


def Solution():
    cin = int(sys.stdin.readline())
    MAX = 123456 * 2 + 1
    dp = [1] * MAX
    for i in range(2, MAX):
        j = 1
        while i * j < MAX:
            dp[i * j] += i
            j += 1

    while cin != 0:
        res = 0
        for i in range(cin + 1, (2 * cin) + 1):
            if dp[i] - 1 == i:
                res += 1
        print(res)
        cin = int(sys.stdin.readline())

    return None
"""
소수인지 판별할때 제곱근을 쓰는 이유는
어떤 수 n이 있다고 할 때, n의 약수들의 리스트에서 미디안은 n의 제곱근이 된다.
ex) 1,2,4,8,16 || sqrt(16) = 4
1,2,3,4,6,12 || sqrt(12) = 3
왜냐하면, 제곱근을 기준으로 왼쪽에 있는 수들로 n이 나누어 떨어지는지 계산하면, 오른쪽의 있는 수들은 자동으로 나누어 떨어지는지 알
수 있기 때문이다.
"""
# def Solution():
#     while True:
#         cnt = 0
#         cin = int(sys.stdin.readline())
#         if cin == 0:
#             break
#         for i in range(cin + 1, cin*2 + 1):
#
#             for j in range(2, int(i**0.5) + 1):
#
#                 if i % j == 0:
#                     break
#             else:
#                 cnt += 1
#
#         print(cnt)
#
#     return None

if __name__ == "__main__":
    Solution()
