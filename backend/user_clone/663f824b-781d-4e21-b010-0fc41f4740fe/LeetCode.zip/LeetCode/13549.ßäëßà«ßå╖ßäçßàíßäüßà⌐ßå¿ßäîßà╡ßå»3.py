from collections import deque
import sys

N, K = map(int, sys.stdin.readline().split())
visited = set()

queue = deque()
queue.append((N, 0))
visited.add(N)

while queue:
    loc, time = queue.popleft()
    if loc == K:
        print(time)
        break

    for nloc in [loc * 2, loc-1, loc+1]:
        if nloc not in visited and 0 <= nloc <= 100000:
            if nloc == loc*2:
                queue.append((nloc, time))
                visited.add(nloc)
            else:
                queue.append((nloc, time+1))
                visited.add(nloc)
