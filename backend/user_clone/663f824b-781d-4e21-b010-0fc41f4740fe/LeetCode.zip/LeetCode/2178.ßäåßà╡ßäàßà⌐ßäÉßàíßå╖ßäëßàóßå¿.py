# from collections import deque
# import sys

# N, M = map(int, sys.stdin.readline().split())

# grid = [list(map(int, list(sys.stdin.readline().strip()))) for _ in range(N)]

# moves = [(0, 1), (0, -1), (1, 0), (-1, 0)]
# visited = set()

# def inRange(i, j):
#     return 0 <= i < N and 0 <= j < M and grid[i][j]

# queue = deque()
# queue.append((0, 0))
# visited.add((0, 0))
# while queue:
#     i, j = queue.popleft()
    
#     for mi, mj in moves:
#         ni, nj = i + mi, j + mj
#         if inRange(ni, nj) and (ni, nj) not in visited:
#             queue.append((ni, nj))
#             visited.add((ni, nj))
#             grid[ni][nj] = grid[i][j] + 1

# print(grid[N-1][M-1])

import sys
from collections import deque

def inRange(i, j):
    return 0 <= i < N and 0 <= j < M and (i, j) not in isVisited

N, M = map(int, list(sys.stdin.readline().split()))
grid = []
moves = [(0, 1), (0, -1), (1, 0), (-1, 0)]
for _ in range(N):
    grid.append(list(map(int, list(sys.stdin.readline().strip()))))
# isVisited = [[0] * M for _ in range(N)]
isVisited = set()

grid[0][0] = 1
queue = deque([])
queue.append((0, 0, 1))
isVisited.add((0, 0))

while queue:
    i, j, score = queue.popleft()
    if i == N-1 and j == M-1:
        print(score)
        break
    for m in moves:
        ni, nj = i + m[0], j + m[1]
        if inRange(ni, nj) and grid[ni][nj]:
            queue.append((ni, nj, score+1))
            isVisited.add((ni, nj))
    
            

    

