def solution(sequence, k):
    l, r, min_cnt, cur_sum = 0, 0, float('inf'), sequence[0]

    while r < len(sequence):
        if cur_sum < k:
            r += 1
            if r == len(sequence):
                break
            cur_sum += sequence[r]

        elif cur_sum > k:
            cur_sum -= sequence[l]
            l += 1
        else:
            if r-l+1 < min_cnt:
                min_cnt = r-l+1
                answer = [l, r]
            cur_sum -= sequence[l]
            l += 1
            
    
    return answer