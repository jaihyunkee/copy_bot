def permutations(index, options, current_permutation, used_indices):
    if index != len(current_permutation):
        for j in range(len(options)):
            if not used_indices[j]:
                used_indices[j] = True
                current_permutation[index] = options[j]
                yield from permutations(index + 1, options, current_permutation, used_indices)
                used_indices[j] = False
    else:
        yield list(current_permutation)


T = int(input())
for tc in range(1, T + 1):
    n, k = map(int, input().split())
    inflate = list(map(int, input().split()))
    deflate = list(map(int, input().split()))
    tested = n * [0]
    curr_test = n * [0]

    tests = [(inflate[i], deflate[i]) for i in range(n)]
    all_tests = permutations(0, tests, curr_test, tested)
    min_pressure = float('inf')
    for test_set in all_tests:
        flag = 0
        for i in range(0, k + 1):
            if flag != 2:
                init_pressure = i
                flag = 0

                for test in test_set:
                    i += test[0]
                    if not 0 <= i <= k:
                        flag = 2
                        break
                    else:
                        i -= test[1]
                        if not 0 <= i <= k:
                            flag = 1
                            break

                if flag != 0:
                    continue
                if init_pressure < min_pressure:
                    min_pressure = init_pressure
                break

            flag = 0

            break

    if min_pressure == float('inf'):
        min_pressure = -1

    print(f'#{tc} {min_pressure}')