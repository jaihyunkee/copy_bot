"""
1) Use Two Pointers
2) It is important to know where to put the two pointers
ex) in this problem, two pointers begin with at the beginning and the end
3) We need to know that we should move the pointer with lower line
"""

def calcVol(l, r, arr):
    mini = min(arr[l], arr[r])
    x = r - l
    return x * mini


class Solution(object):
    def maxArea(self, height):
        """
        :type height: List[int]
        :rtype: int
        """
        result = []
        l, r = 0, len(height)-1
        max = -1
        while l < r:
            temp = calcVol(l, r, height)
            if max < temp:
                max = temp
            if height[l] < height[r]:
                l += 1
            else:
                r -= 1
        return max


sol = Solution()
print(sol.maxArea([1, 8, 6, 2, 5, 4, 8, 3, 7]))
