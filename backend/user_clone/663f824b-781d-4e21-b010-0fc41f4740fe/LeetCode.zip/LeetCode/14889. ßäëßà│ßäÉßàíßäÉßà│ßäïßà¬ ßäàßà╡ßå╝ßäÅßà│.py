import sys


def combination(fixIdx: int, toChoose: int, comb_list: list, N):
    global min_val
    if toChoose == 0:  # one comb set
        sumA, sumB = 0, 0

        for i in range(1, N + 1):
            for j in range(1, N + 1):
                if comb_list[i] == comb_list[j]:
                    if comb_list[i]:
                        sumA += S[i - 1][j - 1]
                    else:
                        sumB += S[i - 1][j - 1]
        diff = abs(sumA - sumB)
        if min_val > diff:
            min_val = diff

        return

    for i in range(fixIdx, N + 1):
        comb_list[i] = True
        combination(i + 1, toChoose - 1, comb_list, N)
        comb_list[i] = False


N = int(sys.stdin.readline())
S = []
min_val = float('inf')

for _ in range(N):
    S.append(list(map(int, sys.stdin.readline().split())))

comb_list = [False] * (N + 1)

combination(1, N // 2, comb_list, N)

print(min_val)
