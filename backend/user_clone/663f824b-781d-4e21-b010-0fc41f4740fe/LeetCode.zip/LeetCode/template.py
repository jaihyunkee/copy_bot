import os

print(len(os.listdir()))