'''Given an integer array nums, return true if any value appears at least twice in the array, and return false if every element is distinct.'''



class Solution:
    def containsDuplicate(self, nums: List[int]) -> bool:
        hashset = set()

        for num in nums:
            if num in hashset:
                return True
            hashset.add(num)
        return False

#     return len(set(nums)) != len(nums)

'''
Used hashset because
1. it doenst have to iterate (fast)
2. it cannnot store more than one same value
'''