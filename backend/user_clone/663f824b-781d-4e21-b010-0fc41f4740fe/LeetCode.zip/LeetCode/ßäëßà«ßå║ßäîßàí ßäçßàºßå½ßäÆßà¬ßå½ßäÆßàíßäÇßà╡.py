from collections import deque

def inRange(x):
    return 1 <= x <= 1000000

def solution(x, y, n):
    visited = set()
    queue = deque([(x, 0)])
    if x == y:
        return 0
    while queue:
        tx, step = queue.popleft()
        for i in [tx+n, tx*2, tx*3]:
            if inRange(i):
                if i in visited:
                    continue
                elif i == y:
                    return step+1
                
                visited.add(i)
                queue.append((i, step+1))
    return -1
