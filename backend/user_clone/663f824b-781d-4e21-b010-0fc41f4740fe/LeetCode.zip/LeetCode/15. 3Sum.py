class Solution(object):
    def threeSum(self, nums):
        """
        :type nums: List[int]
        :rtype: List[List[int]]
        """
        nums.sort()
        print(nums)

        l = 0
        result = []

        while l <= len(nums) - 3:
            if l > 0 and nums[l] == nums[l-1]:
                l += 1
                continue
            target = nums[l] * -1
            m = l + 1
            r = len(nums) - 1

            while m < r:
                if nums[m] + nums[r] == target:
                    result.append([nums[l], nums[m], nums[r]])
                    m += 1
                    r -= 1
                    while m < len(nums) and nums[m] == nums[m-1]:
                        m += 1
                    while r > 0 and nums[r] == nums[r+1]:
                        r -= 1

                elif nums[m] + nums[r] < target:
                    m += 1
                else:
                    r -= 1

            l += 1
        return result


sol = Solution()
print(sol.threeSum([-1, 0, 1, 2, -1, -4]))
