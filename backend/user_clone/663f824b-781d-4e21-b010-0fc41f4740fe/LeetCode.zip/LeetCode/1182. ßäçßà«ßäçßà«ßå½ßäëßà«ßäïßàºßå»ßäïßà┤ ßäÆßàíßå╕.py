import sys

"""
Time Exceed
def solve():
    global ans, S
    if sum(ans_set) == S and len(ans_set) > 0:
        if sorted(ans_set) not in ans_sets:
            ans_sets.append(sorted(ans_set))
            ans += 1

    for i in range(N):
        if not isUsed[i]:
            isUsed[i] = True
            ans_set.append(num_list[i])
            solve()
            isUsed[i] = False
            ans_set.pop()


N, S = map(int, sys.stdin.readline().split())
num_list = list(map(int, sys.stdin.readline().split()))
"""


def dfs(sm, cnt, n):
    global ans
    if cnt == N:
        if n > 0 and sm == S:
            ans += 1
        return

    dfs(sm + num_list[cnt], cnt + 1, n + 1)
    dfs(sm, cnt + 1, n)


N, S = map(int, sys.stdin.readline().split())
num_list = list(map(int, sys.stdin.readline().split()))
ans = 0
dfs(0, 0, 0)
print(ans)
