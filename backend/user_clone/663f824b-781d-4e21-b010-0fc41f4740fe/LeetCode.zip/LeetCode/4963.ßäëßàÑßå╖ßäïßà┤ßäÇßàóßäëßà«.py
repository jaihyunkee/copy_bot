from collections import deque

moves = [(0, 1), (0, -1), (1, 0), (-1, 0), (-1, 1), (1, 1), (1, -1), (-1, -1)]

def inRange(i, j):
    return 0 <= i < h and 0 <= j < w and not visited[i][j]

while True:
    w, h = map(int, input().split())
    if w == 0 and h == 0:
        break
    grid = [list(map(int, input().split())) for _ in range(h)]
    visited = [[0] * w for _ in range(h)]

    res_cnt = 0
    for y in range(h):
        for x in range(w):
            if inRange(y, x) and grid[y][x] == 1:
                queue = deque()
                queue.append((y, x))
                visited[y][x] = 1
                while queue:
                    i, j = queue.popleft()
                    for mi, mj in moves:
                        ni, nj = i + mi, j + mj
                        if inRange(ni, nj) and grid[ni][nj] == 1:
                            queue.append((ni, nj))
                            visited[ni][nj] = 1
                res_cnt += 1

    print(res_cnt)