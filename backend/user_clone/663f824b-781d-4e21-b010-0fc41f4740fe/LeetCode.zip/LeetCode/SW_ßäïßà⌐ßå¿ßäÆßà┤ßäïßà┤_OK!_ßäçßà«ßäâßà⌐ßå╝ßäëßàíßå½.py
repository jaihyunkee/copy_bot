T = int(input())


for t in range(1, T+1):
    N, money = list(map(int, input().split()))
    land_list = list(map(int, input().split()))
    res = 0

    for i in range(len(land_list)-1):
        cost = land_list[i]
        res_list = [i]
        if cost == money:
            res += 1
            continue
        for j in range(i+1, len(land_list)):
            cost += land_list[j]
            res_list.append(j)
            if cost == money:
                res += 1
                break

    print(f'#{t} {res}')


