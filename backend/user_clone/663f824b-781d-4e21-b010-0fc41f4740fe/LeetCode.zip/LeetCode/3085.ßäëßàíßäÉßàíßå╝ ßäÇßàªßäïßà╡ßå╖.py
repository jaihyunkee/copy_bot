import sys


def Solution():
    n = int(sys.stdin.readline())
    board = []
    for i in range(n):
        line = []
        line.extend(sys.stdin.readline()[:-1])
        board.append(line)

    if n == 1:
        return 1
    max_num = 0
    for r in range(n):
        for c in range(len(board[r])):
            if r - 1 >= 0:
                swapped_board = swap(r, c, r - 1, c, board)
                num = check(swapped_board, r, c)
                if max_num < num:
                    max_num = num
            if c + 1 < n:
                swapped_board = swap(r, c, r, c + 1, board)
                num = check(swapped_board, r, c)
                if max_num < num:
                    max_num = num
            if r + 1 < n:
                swapped_board = swap(r, c, r + 1, c, board)
                num = check(swapped_board, r, c)
                if max_num < num:
                    max_num = num
            if c - 1 >= 0:
                swapped_board = swap(r, c, r, c - 1, board)
                num = check(swapped_board, r, c)
                if max_num < num:
                    max_num = num

    return max_num


def swap(r, c, r1, c1, board):
    color = board[r][c]
    new_board = []
    for i in board:
        t = []
        for j in i:
            t.append(j)
        new_board.append(t)

    new_board[r][c] = board[r1][c1]
    new_board[r1][c1] = color

    return new_board


def check(new_board, r, c):
    # check row
    color = new_board[r][c]
    row = 0
    max_row = 0

    # faster
    for i in range(len(new_board)):
        if new_board[r][i] == color:
            row += 1

        else:
            row = 0
        max_row = max(row, max_row)
    # slower
    # for i in range(len(new_board)-1):
    #     if new_board[r][i] == new_board[r][i+1]:
    #         row += 1
    #     else:
    #         row = 1
    #     max_row = max(row, max_row)

    # check col
    col = 0
    max_col = 0

    # faster
    for i in range(len(new_board)):
        if new_board[i][c] == color:
            col += 1

        else:
            col = 0
        max_col = max(max_col, col)
    # slower
    # for i in range(len(new_board)-1):
    #     if new_board[i][c] == new_board[i+1][c]:
    #         col += 1
    #     else:
    #         col = 1
    #     max_col = max(col, max_col)

    return max(max_col, max_row)

if __name__ == "__main__":
    print(Solution())
