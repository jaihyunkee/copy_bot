import numpy as np

def get_score(fi, qfi):
    term1 = (((1.2+1)*fi)/(1.2+fi))
    term2 = (((100+1)*qfi) / (100+qfi))
    return np.round(term1 * term2, 3)

prev_val1 = 3.555
prev_val2 = -1.099
term1 = get_score(2,1) * prev_val1
term2 = get_score(1,1) * prev_val2
print(np.round(term1, 3))
print(np.round(term2, 3))
print(np.round(term1+term2, 3))
