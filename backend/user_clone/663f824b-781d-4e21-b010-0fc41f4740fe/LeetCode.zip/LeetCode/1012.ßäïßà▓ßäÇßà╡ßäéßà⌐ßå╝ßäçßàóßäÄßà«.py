from collections import deque

moves = [(0, 1), (0, -1), (1, 0), (-1, 0)]

def inRange(i, j):
    return 0 <= i < N and 0 <= j < M and not visited[i][j]

T = int(input())
for _ in range(T):
    M, N, K = map(int, input().split())
    grid = [[0] * M for _ in range(N)]
    visited = [[0] * M for _ in range(N)]

    for _ in range(K):
        y, x = map(int, input().split())
        grid[x][y] = 1
    res_cnt = 0
    for i in range(N):
        for j in range(M):
            if grid[i][j] == 1 and not visited[i][j]:
                queue = deque([(i, j)])
                visited[i][j] = 1

                while queue:
                    y, x = queue.popleft()
                    for my, mx in moves:
                        ny, nx = y + my, x + mx
                        if inRange(ny, nx) and grid[ny][nx] == 1:
                            queue.append((ny, nx))
                            visited[ny][nx] = 1
                res_cnt += 1
    print(res_cnt)







