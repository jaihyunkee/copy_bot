TC = int(input())
for tc in range(1, TC+1):
    K = int(input())
    string = input()

    arr = [string[i:] for i in range(len(string))]
    print(f'#{tc} {sorted(arr)[K-1]}')