from collections import deque

class Solution(object):
    def dailyTemperatures(self, temperatures):
        """
        :type temperatures: List[int]
        :rtype: List[int]
        """
        stack = deque([])
        answer = [0] * len(temperatures)
        for idx, i in enumerate(temperatures):
            while stack and i > temperatures[stack[-1]]:
                curr = stack.pop()
                answer[curr] = idx - curr
            stack.append(idx)

        return answer
        