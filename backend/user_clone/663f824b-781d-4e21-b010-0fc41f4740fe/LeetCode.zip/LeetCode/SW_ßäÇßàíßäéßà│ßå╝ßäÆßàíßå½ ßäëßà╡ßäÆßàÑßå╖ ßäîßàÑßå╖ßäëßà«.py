T = int(input())

"""
Time Exceed
def dfs(cnt: int, sum_val: int):
    if sum_val not in res_arr:
        res_arr.append(sum_val)

    for i in range(cnt, len(arr)):
        sum_val += arr[i]
        dfs(i+1, sum_val)
        sum_val -= arr[i]


for t in range(1, T+1):
    res_arr = []
    N = int(input())
    arr = list(map(int, input().split()))
    sum_val = 0
    dfs(0, 0)
    print(f'#{t} {len(res_arr)}')
"""

for t in range(1, T + 1):
    N = int(input())
    scores = list(map(int, input().split()))
    visited = [0] * (sum(scores) + 1)
    visited[0] = 1

    for score in scores:

        for i in range(len(visited) - score, -1, -1):
            if visited[i]:
                visited[i + score] = 1
    print(f'#{t} {sum(visited)}')
