TC = int(input())  # 전체 테스트 케이스 수 입력

for tc in range(1, TC + 1):
    K = int(input())
    string = input()

    substrings = set()

    for i in range(len(string)):
        for j in range(i, len(string)):
            substrings.add(string[i:j+1])

    sorted_substrings = sorted(substrings)

    if K > len(sorted_substrings):
        res = 'none'
    else:
        res = sorted_substrings[K - 1]

    print(f"#{tc} {res}")
