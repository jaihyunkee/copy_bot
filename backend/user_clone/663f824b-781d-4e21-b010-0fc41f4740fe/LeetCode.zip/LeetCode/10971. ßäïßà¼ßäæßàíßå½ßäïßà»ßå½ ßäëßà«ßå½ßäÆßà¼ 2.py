# import sys


# def solve(cnt: int):
#     global min_cost
#     if cnt == N:
#         temp_cost = 0
#         for idx in range(N):

#             next_idx = idx + 1
#             if idx + 1 == N:
#                 next_idx = 0

#             cost = grid[permu_list[idx]][permu_list[next_idx]]
#             if cost == 0:
#                 return
#             else:
#                 temp_cost += grid[permu_list[idx]][permu_list[next_idx]]

#         if temp_cost < min_cost:
#             min_cost = temp_cost

#         return

#     for i in range(N):
#         if not isUsed[i]:
#             isUsed[i] = True
#             permu_list.append(i)
#             solve(cnt + 1)
#             permu_list.pop()
#             isUsed[i] = False


# N = int(sys.stdin.readline())
# grid = []

# isUsed = [False] * (N + 1)
# permu_list = []
# min_cost = float('inf')

# for _ in range(N):
#     grid.append(list(map(int, sys.stdin.readline().split())))

# solve(0)
# print(min_cost)


import sys
from collections import deque

N = int(sys.stdin.readline())
grid = [list(map(int, sys.stdin.readline().split())) for _ in range(N)]
min_cost = float('inf')
isVisited = set()


def dfs(i, cnt, cost, orig):
    global min_cost
    if cnt == N and grid[i][orig]:
        cost += grid[i][orig]
        min_cost = min(min_cost, cost)
        return

    for j in range(N):
        if grid[i][j] and j not in isVisited and cost+grid[i][j] < min_cost:
            isVisited.add(j)
            dfs(j, cnt+1, cost+grid[i][j], orig)
            isVisited.remove(j)

for i in range(N):
    isVisited.add(i)
    dfs(i, 1, 0, i)
    isVisited.remove(i)
    

print(min_cost)