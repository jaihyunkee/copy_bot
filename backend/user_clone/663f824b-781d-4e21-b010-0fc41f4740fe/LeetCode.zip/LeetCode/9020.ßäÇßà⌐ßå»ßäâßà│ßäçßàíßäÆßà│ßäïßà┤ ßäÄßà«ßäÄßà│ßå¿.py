import sys


def isPrime(n):
    for i in range(2, int(n ** 0.5) + 1):
        if n % i == 0:
            break
    else:
        return True


def Solution():
    T = int(sys.stdin.readline())
    for i in range(T):
        n = int(sys.stdin.readline())
        l, r = n // 2, n // 2
        if isPrime(l):
            print(f'{l} {r}')
        else:
            while True:
                if isPrime(l) and isPrime(r):
                    break
                else:
                    l -= 1
                    r += 1
            print(f'{l} {r}')
    return None


if __name__ == "__main__":
    Solution()
