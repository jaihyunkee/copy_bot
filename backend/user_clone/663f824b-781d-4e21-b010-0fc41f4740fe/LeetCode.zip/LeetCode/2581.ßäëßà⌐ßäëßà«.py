"""
프린트 순서 헷갈리지 말자...
"""

import sys


def Solution():
    M = int(sys.stdin.readline())
    N = int(sys.stdin.readline())

    dat = [1] * (N + 1)
    for i in range(2, N + 1):
        j = 1
        while i * j <= N:
            dat[i * j] += i
            j += 1

    first = 0
    res = []
    for n in range(M, N + 1):
        if n == 0 or n == 1:
            continue
        if dat[n] - 1 == n:
            if len(res) == 0:
                first = n
                res.append(n)
            else:
                res.append(n)

    return -1 if len(res) == 0 else '\n'.join(map(str, [sum(res), first]))


if __name__ == "__main__":
    print(Solution())
