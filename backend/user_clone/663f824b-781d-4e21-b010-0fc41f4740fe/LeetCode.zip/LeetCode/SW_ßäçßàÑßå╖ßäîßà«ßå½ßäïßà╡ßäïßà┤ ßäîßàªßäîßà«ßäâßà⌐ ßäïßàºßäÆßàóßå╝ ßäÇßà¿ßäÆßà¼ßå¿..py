def dfs(days, time, satis, path):
    global time_limit, days_limit, res_satis, res_path, max_satis
    flag = False
    for spots_idx, (play_time, play_satis) in tourist_spots.items():

        if not isVisited[spots_idx]:
            if time + distance[path[-1]][spots_idx] + play_time + 10 <= time_limit:
                flag = True
                isVisited[spots_idx] = True
                dfs(days, time + distance[path[-1]][spots_idx] + play_time,
                    satis + play_satis,
                    path + [spots_idx])
                isVisited[spots_idx] = False

    if not flag:
        if days < days_limit - 1:
            for h_idx in hotels:
                if time + distance[path[-1]][h_idx] <= time_limit:
                    dfs(days + 1, 0, satis, path + [h_idx])
        else:
            if time + distance[path[-1]][airport] <= time_limit and satis > max_satis:
                max_satis = satis
                res_satis = satis
                res_path = path[1:] + [airport]
            return


TC = int(input())
for tc in range(1, TC + 1):
    max_satis = float('-inf')
    time_limit = 540
    points_num, days_limit = map(int, input().split())

    distance = [[0] * (points_num + 1) for _ in range(points_num + 1)]

    for i in range(1, points_num):
        temp = list(map(int, input().split()))
        count = 0
        for j in range(i + 1, len(distance[i])):
            distance[i][j] = distance[j][i] = temp[count]
            count += 1

    tourist_spots = {}
    hotels = []
    airport = 0
    for p_idx in range(1, points_num + 1):
        temp = input().split()
        if temp[0] == 'P':
            tourist_spots[p_idx] = list(map(int, temp[1:]))
        elif temp[0] == 'H':
            hotels.append(p_idx)
        else:
            airport = p_idx
    res_satis, res_path = 0, []
    isVisited = [False] * (points_num + 1)
    dfs(0, 0, 0, [airport])

    print(f'#{tc} {res_satis}', end=" ")
    print(*res_path)
