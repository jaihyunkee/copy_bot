class Solution(object):
    def maxProfit(self, prices):
        """
        :type prices: List[int]
        :rtype: int
        """
        l, r = 0, 1
        max_profit = 0
        while r < len(prices):
            if prices[l] < prices[r]:
                max_profit = max(max_profit, prices[r] - prices[l])
            else:
                l = r
            r += 1
        return max_profit


sol = Solution()
a = [7, 1, 5, 3, 6, 4]
print(sol.maxProfit(a))

"""
Brute Force
result = 0
for i in range(len(prices)):
    j = i + 1

    while j < len(prices):
        if prices[i] < prices[j]:
            if result < prices[j] - prices[i]:
                result = prices[j] - prices[i]

        j += 1

return result
"""
