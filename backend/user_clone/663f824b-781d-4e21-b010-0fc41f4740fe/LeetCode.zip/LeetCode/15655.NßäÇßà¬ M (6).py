# import sys

# N, M = map(int, sys.stdin.readline().split())
# nums = sorted(list(map(int, sys.stdin.readline().split(" "))))

# out_arr = [0] * M
# isUsed = [0] * N


# def dfs(arr_idx, start):
#     if arr_idx == M:
#         print(*out_arr)
#         return None
#     else:
#         for i in range(start, len(nums)):
#             if isUsed[i] == 0:
#                 isUsed[0] = 1
#                 out_arr[arr_idx] = nums[i]

#                 dfs(arr_idx + 1, i + 1)
#                 isUsed[i] = 0

#     return None


# if __name__ == "__main__":
#     dfs(0, 0)

import sys

N, M = map(int, sys.stdin.readline().split())
temp = sorted(list(map(int, sys.stdin.readline().split())))

def dfs(cnt, arr):
    if len(arr) == M:
        print(*arr)
        return

    for i in range(cnt, N):
        dfs(i+1, arr+[temp[i]])

dfs(0, [])

