from collections import deque

def inRange(i, j):
    return 0 <= i < N and 0 <= j < N

T = int(input())
moves = [(-2, 1), (-1, 2), (1, 2), (2, 1), (2, -1), (1, -2), (-1, -2), (-2, -1)]


for t in range(T):
    N = int(input())
    move_cnt = [[0] * N for _ in range(N)]
    source = list(map(int, input().split()))
    dest = list(map(int, input().split()))

    queue = deque([])
    queue.append(source)

    while queue:
        i, j = queue.popleft()
        if [i, j] == dest:
            print(move_cnt[i][j])
            break
        for m in moves:
            pi, pj = i, j
            ni, nj = i + m[0], j + m[1]
            if inRange(ni, nj) and not move_cnt[ni][nj]:
                queue.append((ni, nj))
                move_cnt[ni][nj] = move_cnt[i][j] + 1

