from collections import deque

N, M, V = map(int, input().split())
adj = [[] for _ in range(N+1)]
visited = [False] * (N+1)

for idx in range(M):
    s, d = map(int, input().split())
    adj[s].append(d)
    adj[d].append(s)


route = []

stack = deque([])
stack.append(V)
visited[V] = True
route.append(V)
while stack:
    s = stack.pop()
    if not visited[s]:
        route.append(s)
        visited[s] = True
    for d in sorted(adj[s], reverse=True):
        if not visited[d]:
            stack.append(d)


print(*route)

visited = [False] * 1001
route = []
queue = deque([])
queue.append(V)
visited[V] = True
while queue:
    s = queue.popleft()
    route.append(s)
    for d in sorted(adj[s]):
        if not visited[d]:
            queue.append(d)
            visited[d] = True

print(*route)
