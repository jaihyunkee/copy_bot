import sys

N, M = map(int, sys.stdin.readline().split())
grid = [list(map(int, sys.stdin.readline().split())) for _ in range(N)]


def inRange(i, j, type):
    if type == 1:
        if i < N and j + 3 < M:
            return True
        elif i + 3 < N and j < M:
            return True
    elif type == 2:
        if i + 1 < N and j + 1 < M:
            return True
    elif type == 3:
        if i + 2 < N and j + 1 < M: # 대칭
            return True
        elif

    return


for i in range(N):
    for j in range(M):
        for type in range(5):



