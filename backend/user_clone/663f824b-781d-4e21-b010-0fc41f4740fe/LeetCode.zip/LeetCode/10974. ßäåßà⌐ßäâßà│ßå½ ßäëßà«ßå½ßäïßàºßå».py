import sys

N = int(sys.stdin.readline())
ans = []
isUsed = [False] * (N + 1)


def permutation(cnt):
    if cnt == N:
        print(*ans)
        return

    for i in range(1, N + 1):
        if not isUsed[i]:
            ans.append(i)
            isUsed[i] = True
            permutation(cnt + 1)
            isUsed[i] = False
            ans.pop()


if __name__ == "__main__":
    permutation(0)
