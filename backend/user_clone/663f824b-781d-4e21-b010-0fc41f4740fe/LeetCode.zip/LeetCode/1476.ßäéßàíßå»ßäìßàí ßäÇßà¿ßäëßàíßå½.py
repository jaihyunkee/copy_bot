

e, s, m = map(int, input().split(' '))

while e != s or s != m:
    if min(e, s, m) == e:
        e += 15
    elif min(e, s, m) == s:
        s += 28
    else:
        m += 19

print(e)
