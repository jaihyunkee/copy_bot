"""
훨씬 더 효율적이 있는것 같아서, 확인 요망
"""

import sys
def Solution():
    m, n = map(int, sys.stdin.readline().split(" "))
    div_arr = [1] * (n+1)

    for i in range(2, n + 1):
        for j in range(i, n + 1, i):
            div_arr[j] += i
    res = []
    for i in range(m, len(div_arr)):
        if div_arr[i] == 1 + i:
            res.append(i)

    return "\n".join(map(str, res))


if __name__ == "__main__":
    print(Solution())