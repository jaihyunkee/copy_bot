from gensim import corpora, models, similarities
from nltk.stem import PorterStemmer
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
import os
import sys
import csv

books = []
books_name = []
with open(sys.argv[1]) as f:
    for book_loc in f:
        book = []
        book_name = []
        for chpt in os.listdir(book_loc.strip()):
            book_name.append(chpt)
            with open(os.path.join(book_loc.strip(), chpt)) as chapter:
                temp = chapter.read().lower()

                book.append(temp)
        books.append(book)
        books_name.append(book_name)

# tokenize word and stem words and remove stop words
ps = PorterStemmer()
stop_words = set(stopwords.words('english'))
processed_book = []
words = []
for bdx, book in enumerate(books):
    processed_chp = []
    for cdx, chp in enumerate(book):
        books[bdx][cdx] = word_tokenize(chp)
        processed_word = []

        for wdx, word in enumerate(books[bdx][cdx]):
            if books[bdx][cdx][wdx] not in stop_words:
                word = ps.stem(books[bdx][cdx][wdx])
                processed_word.append(word)
                words.append(word)

        processed_chp.append(processed_word)
    processed_book.append(processed_chp)

# make dictionary of unique words in the book
dictionary = corpora.Dictionary([words])

# Term Frequency
bows = [[dictionary.doc2bow(doc, allow_update=True) for doc in processed_book[i]] for i in range(len(processed_book))]
# print(len(bows))
# print(len(bows[1]))
#
# for book in bows:
#     for doc in book:
#         print([[dictionary[id], freq] for id, freq in doc])

# TF-IDF
tfidf = models.TfidfModel(bows[0] + bows[1], smartirs='ltc')
# for book in bows:
#     for doc in tfidf[bows[1]]:
#         print([[dictionary[id], freq] for id, freq in doc])

tfidf_list = []
for i in range(len(bows)):
    tfidf_list.append(tfidf[bows[i]])

index = similarities.MatrixSimilarity(tfidf_list[1], num_features=len(dictionary))
sim = index[tfidf_list[0]]


with open('output.csv', 'w') as file:
    writer = csv.writer(file)
    for idx, corpus in enumerate(sim):
        max_val, max_i, max_j = float('-inf'), None, None

        for jdx in range(len(corpus)):
            if sim[idx][jdx] > max_val:
                max_val, max_i, max_j = sim[idx][jdx], idx, jdx
        writer.writerow((books_name[0][max_i], books_name[1][max_j], max_val))
        print(books_name[0][max_i], books_name[1][max_j], max_val)
