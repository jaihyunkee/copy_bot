import sys

N = int(sys.stdin.readline())
for idx in range(N):
    arr = list(map(int, sys.stdin.readline().split()))
    cnt = 0
    for i in range(1, 21):
        for j in range(1, i):
            if arr[i] < arr[j]:
                cnt += 1

    print(f'{idx+1} {cnt}')
