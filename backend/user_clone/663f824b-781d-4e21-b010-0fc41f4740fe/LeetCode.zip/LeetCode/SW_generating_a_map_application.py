# 기본 제공코드는 임의 수정해도 관계 없습니다. 단, 입출력 포맷 주의
# 아래 표준 입출력 예제 필요시 참고하세요.

# 표준 입력 예제
'''
a = int(input())                        정수형 변수 1개 입력 받는 예제
b, c = map(int, input().split())        정수형 변수 2개 입력 받는 예제
d = float(input())                      실수형 변수 1개 입력 받는 예제
e, f, g = map(float, input().split())   실수형 변수 3개 입력 받는 예제
h = input()                             문자열 변수 1개 입력 받는 예제
'''

# 표준 출력 예제
'''
a, b = 6, 3
c, d, e = 1.0, 2.5, 3.4
f = "ABC"
print(a)                                정수형 변수 1개 출력하는 예제
print(b, end = " ")                     줄바꿈 하지 않고 정수형 변수와 공백을 출력하는 예제
print(c, d, e)                          실수형 변수 3개 출력하는 예제
print(f)                                문자열 1개 출력하는 예제
'''

'''
      아래의 구문은 input.txt 를 read only 형식으로 연 후,
      앞으로 표준 입력(키보드) 대신 input.txt 파일로부터 읽어오겠다는 의미의 코드입니다.
      여러분이 작성한 코드를 테스트 할 때, 편의를 위해서 input.txt에 입력을 저장한 후,
      아래 구문을 이용하면 이후 입력을 수행할 때 표준 입력 대신 파일로부터 입력을 받아올 수 있습니다.

      따라서 테스트를 수행할 때에는 아래 주석을 지우고 이 구문을 사용하셔도 좋습니다.
      아래 구문을 사용하기 위해서는 import sys가 필요합니다.

      단, 채점을 위해 코드를 제출하실 때에는 반드시 아래 구문을 지우거나 주석 처리 하셔야 합니다.
'''

# import sys
# sys.stdin = open("input.txt", "r")
queue = []
moves = [(-1, 0), (1, 0), (0, -1), (0, 1)]


def inRange(x: int, y: int, grid) -> bool:
    if len(grid) > x >= 0 and len(grid) > y >= 0:
        return True
    else:
        return False


def canGo(x: int, y: int, visited, grid) -> bool:
    if not inRange(x, y, grid):
        return False  # the grid is out of range
    elif (x, y) not in visited and not grid[x][y] == 9:
        return True  # the grid is not visited, and also not destination and accident place


def find_start(grid, m) -> tuple:
    for x in range(len(grid)):
        for y in range(len(grid[x])):
            if grid[x][y] == m:
                return x, y


T = int(input())
# 여러개의 테스트 케이스가 주어지므로, 각각을 처리합니다.
for test_case in range(1, T + 1):
    N, M = map(int, input().split())
    grid = []
    visited = set()
    distance = [[0] * N for _ in range(N)]
    orig_distance = [[0] * N for _ in range(N)]
    step_grid = [[0] * N for _ in range(N)]

    # generate grid
    for n in range(N):
        row = list(map(int, input().split()))
        grid.append(row)

    # find destination
    destination_list = []
    for m in range(1, M + 1):
        for des_x in range(len(grid)):

            for des_y in range(len(grid[des_x])):
                if grid[des_x][des_y] == m:
                    destination_list.append((des_x, des_y))

    possible_path_num = []
    # start bfs
    step = 1
    x, y = find_start(grid, 1)
    if grid[x][y] == 0 or grid[x][y] == 1:
        queue.append((x, y))
        visited.add((x, y))
    distance[x][y] = 1
    step_grid[x][y] = 1

    for m in range(2, M + 1):
        while len(queue) != 0:
            pop_x, pop_y = queue.pop(0)

            if (pop_x, pop_y) == destination_list[m - 1]:
                possible_path_num.append(distance[pop_x][pop_y])

                break
            visited.add((pop_x, pop_y))

            # go to the adjacent cells
            step += 1
            for idx in range(len(moves)):
                adjx = pop_x + moves[idx][0]
                adjy = pop_y + moves[idx][1]

                for i in range(len(grid)):
                    print(distance[i])
                print()
                if 0 <= adjx < len(grid) and 0 <= adjy < len(grid) and (adjx, adjy) not in visited:
                    print(f'(adjx, adjy): {adjx, adjy}')
                    print(f'(pop_x, pop_y): {pop_x, pop_y}')
                    distance[adjx][adjy] += distance[pop_x][pop_y]

                if canGo(adjx, adjy, visited, grid):

                    step_grid[adjx][adjy] = step
                    if (adjx, adjy) not in visited and not grid[adjx][adjy] == 9:

                        if (adjx, adjy) not in queue:
                            queue.append((adjx, adjy))

        x, y = find_start(grid, m)

        distance = [[0] * N for _ in range(N)]
        distance[x][y] = 1
        visited = set()
        queue = []
        queue.append((x, y))
        if grid[x][y] == 0 or grid[x][y] == 1:
            queue.append((x, y))
            visited.add((x, y))

    result = 1
    for i in range(len(possible_path_num)):
        result *= possible_path_num[i]
    print(possible_path_num)
    print(f'#{test_case} {result}')
