# https://www.acmicpc.net/problem/1748
#250
#250 + (250 - 9) + (250 - 99)

import sys

n = int(input())
i = 1
res = 0
while i <= n:
    res += n - i + 1
    i *= 10


print(res)

"""
def getDigit(n):
    res = 0
    while n / 10 != 0:
        res += 1
        n  = n // 10
    return res

n = input()
length = len(n)
n = int(n)
mod = (10 ** (length - 1)) - 1

result = 0
while n != 0:
    result += (n - mod) * length
    n = mod
    length = getDigit(n)
    mod = (10 ** (length - 1)) - 1

print(result)
"""


