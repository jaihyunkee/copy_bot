#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

bool cmp(pair<int, int> v1, pair<int, int> v2) {
    return v1.second > v2.second;
}
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    int T;
    int test_case;
    cin >> T;
    for (test_case = 1; test_case <= T; test_case++)
    {
        int i, N;
        cin >> N;
        vector<pair<int, int>> v;
        for (i = 0; i < N; i++)
        {
            int t, d;
            cin >> t >> d;
            v.push_back({t, d});
        }
        sort(v.begin(), v.end(), cmp);

        int start_date = v.front().second - v.front().first;
        for (int i = 0; i < v.size()-1; i++) {

            int new_sd = v[i + 1].second - v[i + 1].first;
            int new_ed = v[i + 1].second;

            if (new_ed >= start_date)
            {
                // start_date = new_sd - (new_ed - (v[i].second - v[i].first)); �̰� Ʋ��
                start_date = new_sd - (new_ed - (start_date));
            }
            else {
                start_date = new_sd;
            }
        }
        cout << "#" << test_case << " " << start_date << '\n';
    }

    return 0;
}