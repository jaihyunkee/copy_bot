import sys


def Solution():
    target = int(sys.stdin.readline())
    M = int(sys.stdin.readline())
    min_cnt = abs(target - 100)
    if M == 0:
        return min(len(str(target)), min_cnt)
    broken_keys = list(map(int, sys.stdin.readline().split()))


    # if the goal channel is 100
    if target == 100:
        return 0

    for possible_channel in range(1000000):
        str_pc = str(possible_channel)
        for i in range(len(str_pc)):
            if int(str_pc[i]) in broken_keys:
                break
            elif i == len(str_pc) - 1:
                min_cnt = min(min_cnt, abs(len(str_pc)) + abs(target - possible_channel))

    return min_cnt


if __name__ == "__main__":
    print(Solution())
