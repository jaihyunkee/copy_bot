def dfs(cnt: int, start, temp):
    global N
    for n in not_allowed:
        diff = len(temp) - len(n)
        if len(set(temp) - set(n)) == diff:
            return
    comb.append(temp)

    if cnt == N:
        return

    for i in range(start, N):
        if not isUsed[i]:
            isUsed[i] = True
            dfs(cnt + 1, i + 1, temp + [i + 1])
            isUsed[i] = False


TC = int(input())
for t in range(1, TC + 1):
    N, M = map(int, input().split())
    not_allowed = []
    for _ in range(M):
        a, b = map(int, input().split())
        not_allowed.append([a, b])
    comb = []
    isUsed = [False] * N
    dfs(0, 0, [])
    print(f'#{t} {len(comb)}')

