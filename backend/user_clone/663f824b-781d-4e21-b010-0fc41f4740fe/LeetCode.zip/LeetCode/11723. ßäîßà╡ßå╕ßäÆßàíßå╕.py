import sys

#
# def add(x, S):
#     if x not in S:
#         S.append(x)
#     return
#
#
# def remove(x, S):
#     if x in S:
#         S.remove(x)
#     return
#
#
# def check(x, S):
#     if x in S:
#         print(1)
#         return
#     else:
#         print(0)
#         return
#
#
# def toggle(x, S):
#     if x in S:
#         S.remove(x)
#     else:
#         S.append(x)
#
#
# def all(S):
#     S = [i for i in range(1, 21)]
#     return S
#
#
# def empty(S):
#     S = []
#     return S
#
#
# if __name__ == '__main__':
#
#     M = int(sys.stdin.readline())
#     S = []
#     for m in range(M):
#
#         cin = sys.stdin.readline().split()
#         if len(cin) == 2:
#             operation, x = cin[0], int(cin[1])
#         else:
#             operation = cin[0]
#
#         if operation == 'add':
#             add(x, S)
#         elif operation == 'remove':
#             remove(x, S)
#         elif operation == 'check':
#             check(x, S)
#         elif operation == 'toggle':
#             toggle(x, S)
#         elif operation == 'all':
#             S = all(S)
#         elif operation == 'empty':
#             S = empty(S)

# using bit masking

M = int(sys.stdin.readline())
S = 0

for _ in range(M):
    cin = sys.stdin.readline().split()
    if len(cin) == 2:
        oper, x = cin[0], int(cin[1]) - 1
    else:
        oper = cin[0]

    if oper == 'add':
        S |= (1 << x)
    elif oper == 'remove':
        S &= ~(1 << x)
    elif oper == 'check':
        print(1 if S & (1 << x) else 0)
    elif oper == 'toggle':
        S ^= (1 << x)
    elif oper == 'all':
        S = (1 << 20) - 1
    elif oper == 'empty':
        S ^= S
