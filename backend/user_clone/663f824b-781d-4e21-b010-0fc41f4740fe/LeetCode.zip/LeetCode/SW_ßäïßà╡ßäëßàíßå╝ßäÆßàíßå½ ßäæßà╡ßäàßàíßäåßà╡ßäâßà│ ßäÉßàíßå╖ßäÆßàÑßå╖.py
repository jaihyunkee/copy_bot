"""
#  To check hoe many levels are needed to build the pyramid
num = 1
t_num = 1
level = 1
while True:
    if num >= 29:
        print(level)
        break
    t_num += 1
    num += t_num
    level += 1
"""


def isInPyramid(t_level_fst_num, t_level_end_num):
    global a_lvl, b_lvl, b

    if t_level_fst_num[b_lvl] <= b <= t_level_end_num[b_lvl]:
        return True
    return False


def getSubPyramid(a):
    global a_lvl, b_lvl
    t_level_fst_num = [0] * 141
    t_level_end_num = [0] * 141
    t_level_fst_num[a_lvl] = a
    t_level_end_num[a_lvl] = a

    i = 1
    while a_lvl + i <= b_lvl:
        t_level_fst_num[a_lvl + i] = t_level_fst_num[a_lvl + i - 1] + room_num_per_level[a_lvl + i - 1]
        t_level_end_num[a_lvl + i] = t_level_end_num[a_lvl + i - 1] + room_num_per_level[a_lvl + i]
        i += 1

    return t_level_fst_num, t_level_end_num


def getLvl(a, b):
    flag, a_lvl, b_lvl, lvl = 0, 0, 0, 0
    while True:
        if level_fst_num[lvl] <= a <= level_fst_num[lvl] + room_num_per_level[lvl] - 1 and flag == 0:
            a_lvl = lvl
            flag += 1

        if level_fst_num[lvl] <= b < level_fst_num[lvl] + room_num_per_level[lvl] and flag == 1:
            b_lvl = lvl
            flag += 1

        if flag == 2:
            break

        lvl += 1
    return a_lvl, b_lvl


level_fst_num = [0] * 141
room_num_per_level = [i for i in range(1, 142)]
i, num, t_num = 0, 1, 0

while i != 141:
    level_fst_num[i] = num
    t_num += 1
    num += t_num
    i += 1

TC = int(input())
for tc in range(1, TC + 1):
    a, b = map(int, input().split())
    if a > b:  # b is always greater than a
        temp = b
        b = a
        a = temp

    a_lvl, b_lvl = getLvl(a, b)
    lvl_diff = b_lvl - a_lvl

    t_level_fst_num, t_level_end_num = getSubPyramid(a)
    if isInPyramid(t_level_fst_num, t_level_end_num):
        print(f'#{tc} {lvl_diff}')
    else:
        if b > t_level_end_num[b_lvl]:
            res = lvl_diff + (b-t_level_end_num[b_lvl])
        else:
            res = lvl_diff + (t_level_fst_num[b_lvl]-b)

        print(f'#{tc} {res}')
