class Solution(object):
    def lengthOfLongestSubstring(self, s):
        """
        :type s: str
        :rtype: int
        """
        l, r = 0, 0
        dat = [False] * 127
        result = 0

        while r < len(s):
            dat[ord(s[r])] = True

            if r + 1 < len(s) and not dat[ord(s[r + 1])]:
                r += 1
            else:
                if result < r - l + 1:
                    result = r - l + 1
                dat = [False] * 127
                l += 1
                r = l
        return result



sol = Solution()
print(sol.lengthOfLongestSubstring("abcabcbb"))

"""
l, r = 0, 0
result = ""
result_num = 0

while r < len(s):
    result += s[r]

    if result_num < len(result):
        result_num = len(result)

    if r + 1 < len(s) and s[r + 1] in result:
        result = ""
        l += 1
        r = l
    else:
        r += 1
return result_num
"""