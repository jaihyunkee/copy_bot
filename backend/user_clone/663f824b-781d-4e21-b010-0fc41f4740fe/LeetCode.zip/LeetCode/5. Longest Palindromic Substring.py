class Solution(object):
    def longestPalindrome(self, s):
        """
        :type s: str
        :rtype: str
        """
        max_len, res = 0, ''
        for i in range(len(s)):

            # even case
            l, r = i, i
            while l >= 0 and r < len(s) and s[l] == s[r]:
                if max_len < len(s[l:r+1]):
                    max_len = len(s[l:r+1])
                    res = s[l:r+1]
                l -= 1
                r += 1

            # odd case
            l, r = i, i+1
            while l >= 0 and r < len(s) and s[l] == s[r]:
                if max_len < len(s[l:r+1]):
                    max_len = len(s[l:r+1])
                    res = s[l:r+1]
                l -= 1
                r += 1

        return res
