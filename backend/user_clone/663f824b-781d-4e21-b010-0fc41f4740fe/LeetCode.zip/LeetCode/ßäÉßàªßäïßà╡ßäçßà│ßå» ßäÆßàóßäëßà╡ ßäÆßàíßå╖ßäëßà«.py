def solution(data, col, row_begin, row_end):
    answer = -1
    data.sort(key=lambda x: [x[col-1], -x[0]])
    
    for i in range(row_begin, row_end+1):
        data[i-1] = map(lambda x:x%i, data[i-1])
        if answer == -1:
            answer = sum(data[i-1])
        else:
            answer ^= sum(data[i-1])
    return answer