# you can write to stdout for debugging purposes, e.g.
# print("this is a debug message")

def fibo(N):
    if N <= 1:
        return N
    else:
        return str2int(fibo(N-1)) + str2int(fibo(N-2))

def str2int(N):
    return sum(map(int, list(str(N))))
    
def solution(N):
    # Implement your solution here
    return fibo(N)
    
    

    
