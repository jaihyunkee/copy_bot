import sys


def combination(fixIdx: int, toChoose: int, comb_list: list):
    global min_val
    if toChoose == 0:
        if comb_list.count(True) == N:  # there should be at least one team
            return

        teamA, teamB = 0, 0
        for i in range(1, N + 1):
            for j in range(1, N + 1):
                if comb_list[i] == comb_list[j]:
                    if comb_list[i]:
                        teamA += S[i - 1][j - 1]
                    else:
                        teamB += S[i - 1][j - 1]
        new_score = abs(teamA - teamB)
        if min_val > new_score:
            min_val = new_score
        return

    for k in range(fixIdx, N + 1):
        comb_list[k] = True
        combination(k + 1, toChoose - 1, comb_list)
        comb_list[k] = False


min_val = float("inf")
N = int(sys.stdin.readline())
S = []
for _ in range(N):
    S.append(list(map(int, sys.stdin.readline().split())))

comb_list = [False] * (N + 1)

for headcnt in range(1, N + 1):
    combination(1, headcnt, comb_list)

print(min_val)
