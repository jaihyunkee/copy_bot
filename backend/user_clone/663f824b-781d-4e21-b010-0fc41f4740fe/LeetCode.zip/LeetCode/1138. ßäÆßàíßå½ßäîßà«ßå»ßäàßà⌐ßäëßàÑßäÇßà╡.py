import sys

n = int(sys.stdin.readline())
arr = list(map(int, sys.stdin.readline().split()))
ret = [0] * n

"""
5
2 1 2 0 0

5
arr -> 2 1 2 0 0
out -> 4 2 1 5 3
ret -> 0 0 0 0 0

i == 2: ret -> 0 2 1 0 0
"""

# method 1

for i in range(n):
    
    cnt = 0
    for j in range(n):
        if ret[j] == 0 and cnt != arr[i]: # i = 2, j = 4
            cnt += 1
        elif ret[j] == 0:
            ret[j] = i+1
            break

# method 2

# for i in range(n):
#     # if ret[arr[i]] == 0:
#     #     ret[arr[i]] = i+1
#     #     continue

#     cnt = arr[i]
#     for j in range(n):
#         if ret[j] == 0 and cnt == 0:
#             ret[j] = i+1
#             break
#         elif ret[j] == 0:
#             cnt -= 1
            

# method 3

# for i in range(n):
#     # if ret[arr[i]] == 0:
#     #     ret[arr[i]] = i+1
#     #     continue
    
#     cnt = arr[i]
#     for j in range(n):
#         if ret[j] == 0 and cnt != 0:
#             cnt -= 1
#         elif ret[j] == 0:
#             ret[j] = i+1
#             break

print(' '.join(map(str, ret)))