def dfs(cnt: int, start_coord, dist):
    global min_dist
    if min_dist < dist:
        return
    if cnt == cust_num:
        dist += abs(start_coord[0] - home_coord[0]) + abs(start_coord[1] - home_coord[1])
        if dist < min_dist:
            min_dist = dist
        return

    for j in range(cust_num):
        if not isUsed[j]:
            isUsed[j] = True
            dfs(cnt+1, cust_coords[j], dist+abs(start_coord[0] - cust_coords[j][0]) + abs(start_coord[1] - cust_coords[j][1]))
            isUsed[j] = False


TC = int(input())
for tc in range(1, TC + 1):
    cust_num = int(input())
    coords = list(map(int, input().split()))

    arr = []
    for i in range(0, len(coords), 2):
        x, y = coords[i], coords[i + 1]
        arr.append((x, y))

    # move home coordinate to the end
    company_coord = arr[0]
    home_coord = arr[1]
    cust_coords = arr[2:]

    isUsed = [False] * cust_num
    min_dist = float('inf')

    dfs(0, company_coord, 0)

    print(f'#{tc} {min_dist}')


