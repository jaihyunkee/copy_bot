# import sys

# N, M = map(int, sys.stdin.readline().split())
# nums = sorted(list(map(int, sys.stdin.readline().split())))
# out_arr = [0] * M
# isUsed = [0] * len(nums)


# def dfs(arr_idx):
#     if arr_idx == M:
#         print(*out_arr)
#         return None
#     else:
#         for i in range(len(nums)):
#             if isUsed[i] == 0:
#                 out_arr[arr_idx] = nums[i]
#                 isUsed[i] = 1
#                 dfs(arr_idx + 1)
#                 isUsed[i] = 0


# if __name__ == "__main__":
#     dfs(0)


# import sys

# N, M = map(int, sys.stdin.readline().split())
# temp = sorted(list(map(int, sys.stdin.readline().split())))
# isUsed = [False] * N

# def dfs(cnt, arr):
#     if cnt == M:
#         print(*arr)
#         return
#     for i in range(N):

#         dfs(cnt+1, arr+[temp[i]])


# dfs(0, [])

import sys

N, M = map(int, sys.stdin.readline().split())
isUsed = [False] * N
temp = sorted(list(map(int, sys.stdin.readline().split())))

def dfs(start, arr):
    if len(arr) == M:
        print(*arr)
        return
    for i in range(N):
        if not isUsed[i]:
            isUsed[i] = True
            dfs(start+1, arr+[temp[i]])
            isUsed[i] = False

dfs(0, [])