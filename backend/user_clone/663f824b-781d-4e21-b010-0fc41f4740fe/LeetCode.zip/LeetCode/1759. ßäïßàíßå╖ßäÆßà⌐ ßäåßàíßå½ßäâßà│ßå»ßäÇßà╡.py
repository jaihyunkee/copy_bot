import sys

res = []
vowels = ['a', 'e', 'i', 'o', 'u']


def isContainVowels(target: str):
    for c in target:
        if c in vowels:
            return True
    else:
        return False

def isContainConso(target: str):
    checkTwo = 0
    for c in target:
        if c not in vowels:
            checkTwo += 1
    if checkTwo >= 2:
        return True
    return False


def isIncreasing(target: str, toAdd: str):
    if target[-1] < toAdd:
        return True
    return False


def solve(cnt, pw):
    if cnt == L:
        count_vowels = 0
        for i in pw:
            if i in vowels:
                count_vowels += 1
        if count_vowels >= 1 and L - count_vowels >= 2:
            print(pw)
            return

    for idx in range(len(chars)):
        if cnt == 0 or isIncreasing(pw, chars[idx]):
            solve(cnt + 1, pw + chars[idx])


L, C = map(int, sys.stdin.readline().split())
chars = sorted(sys.stdin.readline().split())
solve(0, "")

