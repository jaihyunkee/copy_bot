def calcPost(postfix: str):
    pstack = []
    for p in postfix:
        if p == '+':
            fst = int(pstack.pop())
            snd = int(pstack.pop())
            pstack.append(fst + snd)
        elif p == '*':
            fst = int(pstack.pop())
            snd = int(pstack.pop())
            pstack.append(fst * snd)
        else:
            pstack.append(p)

    return pstack[0]


for t in range(1, 11):
    N = int(input())
    exp = input()

    stack = []
    res = ""
    for e in exp:
        if e == '*':
            if len(stack) and stack[-1] == '*':
                res += stack.pop()
            stack.append(e)
            continue
        elif e == '+':
            if len(stack) and stack[-1] == '*':
                res += stack.pop()
            if len(stack) and stack[-1] == "+":
                res += stack.pop()
            stack.append(e)
            continue
        res += e
    while stack:
        res += stack.pop()

    print(f'#{t} {calcPost(res)}')


