import sys
def Solution():
    # s = list(map(lambda x: ord(x) - 96, list(input(''))))

    cin = sys.stdin.readline()[:-1]
    res = [0] * 26
    for i in cin:
        res[ord(i) - 97] += 1

    return " ".join(map(str, res))


if __name__ == "__main__":
    print(Solution())