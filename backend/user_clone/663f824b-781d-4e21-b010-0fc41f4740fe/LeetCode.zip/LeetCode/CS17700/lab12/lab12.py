def WeightClass(weightList):
    weight_avg = 0
    res = {}
    for boxer in weightList:
        offSeason_avg = sum(boxer[0]) / len(boxer[0])
        inSeason_avg = sum(boxer[1]) / len(boxer[1])
        weight_avg = (0.7 * offSeason_avg) + (0.3 * inSeason_avg)
        category = ""
        if weight_avg >= 200:
            category = "H"
        elif 150 <= weight_avg < 200:
            category = "M"
        else:
            category = "L"
        res[boxer["Name"]] = category

    return res


if __name__ == "__main__":
    weightList = \
        [{"Name": "Sugar Ray", 0: [158, 167, 173, 170], 1: [159, 157, 145, 149]},
         {"Name": "Ali", 0: [220, 231, 218, 204], 1: [198, 194, 209, 216]},
         {"Name": "Pacquiao", 0: [153, 151, 148, 140], 1: [147, 145, 144, 145]}]
    print(WeightClass(weightList))
