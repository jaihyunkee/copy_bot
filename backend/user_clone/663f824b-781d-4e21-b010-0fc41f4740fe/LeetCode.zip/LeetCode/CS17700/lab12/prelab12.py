def gradeBook(studentsDictList):
    res = {}
    for student in studentsDictList:
        avg = sum(student["scores"]) / len(student["scores"])
        res[student["ID"]] = round(avg, 2)

    return res

if __name__ == "__main__":
    sList = [{"ID": "001834", "scores": [54, 76, 42, 93, 76]},
             {"ID": "001342", "scores": [45, 74, 33, 65, 81, 73]},
             {"ID": "002536", "scores": [91, 53, 23, 87]}]

    print(gradeBook(sList))