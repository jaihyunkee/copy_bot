def main():
    print("A")


# readCustomer
def readCustomer(filepath):
    with open(filepath, "r") as f:
        customer_raw = f.readlines()
    customers = []
    for customer in customer_raw:
        customers.append(customer.rstrip())
    return customers


# readItemName
def readItemName(filename):
    with open(filename, "r") as f:
        item_raw = f.readlines()
    items = []
    prices = []
    for idx, data in enumerate(item_raw):
        trim_data = data.rstrip()
        split_data = trim_data.split(",")
        items.append(split_data[0])
        prices.append(split_data[1])
    return items


# readItemCost
def readItemCost(filename):
    with open(filename, "r") as f:
        item_raw = f.readlines()
    items = []
    prices = []
    for idx, data in enumerate(item_raw):
        trim_data = data.rstrip()
        split_data = trim_data.split(",")
        items.append(split_data[0])
        prices.append(int(split_data[1]))
    return prices


# readTransactions
def readTransactions(filename):
    with open(filename, "r") as f:
        item_raw = f.readlines()
    customers = []
    items = []
    numbers = []
    for idx, data in enumerate(item_raw):
        trim_data = data.rstrip()
        split_data = trim_data.split(",")
        customers.append(split_data[0])
        items.append(split_data[1])
        numbers.append(int(split_data[2]))

    return [customers, items, numbers]


# getRegisteredCustomer
def getRegisteredCustomer(registeredCustomer, transactionCustomer):
    answer = []
    for rg in registeredCustomer:
        if rg in transactionCustomer:
            answer.append(rg)
    return answer


def getGuest(registeredCustomer, transactionCustomer):
    answer = []
    for tc in transactionCustomer:
        if tc not in registeredCustomer:
            answer.append(tc)
    return list(set(answer))


def profitByRegisteredCustomer(registeredCustomer, transactionFilename, itemFilename):
    with open(transactionFilename, "r") as f:
        item_raw = f.readlines()
    customers = []
    items = []
    numbers = []
    transaction_data = {}
    for idx, data in enumerate(item_raw):
        trim_data = data.rstrip()
        split_data = trim_data.split(",")
        customer_name = split_data[0]
        item_name = split_data[1]
        quantity = int(split_data[2])
        if customer_name not in transaction_data:
            transaction_data[customer_name] = {}
        transaction_data[customer_name][item_name] = quantity

    with open(itemFilename, "r") as f:
        item_raw = f.readlines()
    items = []
    prices = []
    item_data = {}
    for idx, data in enumerate(item_raw):
        trim_data = data.rstrip()
        split_data = trim_data.split(",")
        item_name = split_data[0]
        price = int(split_data[1])
        item_data[item_name] = price

    profit_total = 0
    for rc in registeredCustomer:
        if rc in transaction_data.keys():
            transaction_by_rc = transaction_data[rc]
            item_name = list(transaction_by_rc.keys())[0]
            quantity = transaction_data[rc][item_name]
            profit = quantity * item_data[item_name]
            profit_total += profit
    return profit_total


def profitByGuest(nonregisteredCustomer, transactionFilename, itemFilename):
    with open(transactionFilename, "r") as f:
        item_raw = f.readlines()
    customers = []
    items = []
    numbers = []
    transaction_data = {}
    for idx, data in enumerate(item_raw):
        trim_data = data.rstrip()
        split_data = trim_data.split(",")
        customer_name = split_data[0]
        item_name = split_data[1]
        quantity = int(split_data[2])
        if customer_name not in transaction_data:
            transaction_data[customer_name] = {}
        transaction_data[customer_name][item_name] = quantity

    with open(itemFilename, "r") as f:
        item_raw = f.readlines()
    items = []
    prices = []
    item_data = {}
    for idx, data in enumerate(item_raw):
        trim_data = data.rstrip()
        split_data = trim_data.split(",")
        item_name = split_data[0]
        price = int(split_data[1])
        item_data[item_name] = price

    profit_total = 0
    for rc in nonregisteredCustomer:
        if rc in transaction_data.keys():
            transaction_by_rc = transaction_data[rc]
            item_name = list(transaction_by_rc.keys())[0]
            quantity = transaction_data[rc][item_name]
            profit = quantity * item_data[item_name]
            profit_total += profit
    return profit_total


def top5ItemByRegisteredCustomer(registeredCustomer, transactionFilename):
    with open(transactionFilename, "r") as f:
        item_raw = f.readlines()
    customers = []
    items = []
    numbers = []
    transactions = []
    for idx, data in enumerate(item_raw):
        trim_data = data.rstrip()
        split_data = trim_data.split(",")
        customer_name = split_data[0]
        item_name = split_data[1]
        quantity = int(split_data[2])
        customers.append(customer_name)
        items.append(item_name)
        numbers.append(quantity)
        transactions.append([customer_name, item_name, quantity])

    transactions.sort(key=lambda x: -x[2])
    answer = []
    for transaction in transactions[:5]:
        # print(transaction)
        name = transaction[0]
        item = transaction[1]
        if name in registeredCustomer:
            answer.append(item)
    return list(set(answer))


def top5ItemByGuest(guests, transactionFilename):
    with open(transactionFilename, "r") as f:
        item_raw = f.readlines()
    customers = []
    items = []
    numbers = []
    transactions = []
    for idx, data in enumerate(item_raw):
        trim_data = data.rstrip()
        split_data = trim_data.split(",")
        customer_name = split_data[0]
        item_name = split_data[1]
        quantity = int(split_data[2])
        customers.append(customer_name)
        items.append(item_name)
        numbers.append(quantity)
        transactions.append([customer_name, item_name, quantity])

    transactions.sort(key=lambda x: -x[2])
    answer = []
    for transaction in transactions[:5]:
        name = transaction[0]
        item = transaction[1]
        if name in guests:
            answer.append(item)
    return list(set(answer))


def plotTop5Items(transactionFilename):
    with open(transactionFilename, "r") as f:
        item_raw = f.readlines()
    customers = []
    items = []
    numbers = []
    transactions = []
    for idx, data in enumerate(item_raw):
        trim_data = data.rstrip()
        split_data = trim_data.split(",")
        customer_name = split_data[0]
        item_name = split_data[1]
        quantity = int(split_data[2])
        customers.append(customer_name)
        items.append(item_name)
        numbers.append(quantity)
        transactions.append([customer_name, item_name, quantity])

    transactions.sort(key=lambda x: -x[2])
    plot_data = [[], []]
    for transaction in transactions[:5]:
        plot_data[0].append(transaction[1])
        plot_data[1].append(transaction[2])
    import matplotlib.pyplot as plt

    y_pos = [i for i in range(len(plot_data[0]))]
    plt.bar(y_pos, plot_data[1])
    plt.xticks(y_pos, plot_data[0])
    plt.title("Top5 Items")
    plt.ylabel("Amount")
    plt.savefig("top5Item.pdf")
    plt.show()
    return plot_data


if __name__ == "__main__":
    main()
