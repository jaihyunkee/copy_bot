# project4.py
from graphics import *

import random
import math
import time

def main():
    windowWidth = 500
    windowHeight = 500

    window = GraphWin("Project4", windowWidth, windowHeight)

    arr  = random.sample(range(0,100), 10)
    arr.sort()

    list_of_text = []

    notice = Text(Point(250, 20), "Click to start")
    notice.draw(window)

    while window.checkMouse() == None:
        continue    

    start = time.time()

    notice.setText("Click numbers in increasing order")
    notice.setTextColor("blue")
    
    for num in arr:
        x = random.randint(20, windowWidth-20)
        y = random.randint(20, windowHeight-20)

        t = Text(Point(x,y), str(num))
        t.draw(window)

        list_of_text.append((t, x, y))

    idx = 0 
    while idx < len(list_of_text):
        m = window.checkMouse()
        if m != None:
            t, x, y = list_of_text[idx]
            d = math.sqrt((x - m.getX())**2 + (y - m.getY())**2)

            if d < 5.0:
                t.undraw()
                idx += 1
                notice.setText("Good (remaining:{})".format(len(list_of_text)-idx))
                notice.setTextColor("green")
            else :
                notice.setText("Opps (remaining:{})".format(len(list_of_text)-idx))
                notice.setTextColor("red")

    notice.setText("Clear ({}s)".format(int(time.time()-start)))
    notice.setTextColor("blue")

    while window.checkMouse() == None:
        continue

if __name__ == "__main__":
    main()  