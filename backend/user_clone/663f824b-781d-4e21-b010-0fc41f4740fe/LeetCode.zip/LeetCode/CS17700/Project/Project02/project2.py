# CS 177 - project2.py
# {insert your name here}
# project summary: ...

def check_if_value_in_range(value, minimum, maximum, error_message):
    if value < minimum or value > maximum:
        print(error_message, value)
        exit(1)


def check_if_value_is_binary(value, error_message):
    if not (value == 0 or value == 1):
        print(error_message, value)
        exit(1)


def decide_pass_fail(value, threshold):
    if value >= threshold:
        return "PASS"
    else:
        return "FAIL"


def get_attendance_score():
    # Part 1: Attendance
    att = eval(input("Did the student attend all classes? (0/1): "))
    check_if_value_is_binary(att, "Incorrect input for attendance")

    att = 5 * att
    return att


def get_lab_score():
    # Part 2: Labs
    lab1 = eval(input("Enter marks in Lab 1 (out of 70): "))
    check_if_value_in_range(lab1, 0, 70, "Incorrect input for lab1")
    lab1 = 10 * lab1 / 70

    lab2 = eval(input("Enter marks in Lab 2 (out of 50): "))
    check_if_value_in_range(lab2, 0, 50, "Incorrect input for lab2")
    lab2 = 10 * lab2 / 50

    lab3 = eval(input("Enter marks in Lab 3 (out of 44): "))
    check_if_value_in_range(lab3, 0, 44, "Incorrect input for lab3")
    lab3 = 10 * lab3 / 44

    labs = 10 * (lab1 + lab2 + lab3) / 30
    return labs


def get_project_score():
    # Part 3: Projects
    proj1 = eval(input("Enter marks in Project 1 (out of 100): "))
    check_if_value_in_range(proj1, 0, 100, "Incorrect input for proj1")
    proj1 = 10 * proj1 / 100

    proj2 = eval(input("Enter marks in Project 2 (out of 120): "))
    check_if_value_in_range(proj2, 0, 120, "Incorrect input for proj2")
    proj2 = 10 * proj2 / 120

    projs = 30 * (proj1 + proj2) / 20
    return projs


def get_exam_scores():
    # Part 4: Exams
    exam1 = eval(input("Enter marks in Mid-Semester Exam (out of 90): "))
    check_if_value_in_range(exam1, 0, 90, "Incorrect input for exam1")
    exam1 = 25 * exam1 / 90

    exam2 = eval(input("Enter marks in End-Semester Exam (out of 120): "))
    check_if_value_in_range(exam2, 0, 120, "Incorrect input for exam2")
    exam2 = 30 * exam2 / 120

    return exam1, exam2


def main():
    """
    Distribution:
        labs: 10
        projects: 30
        mid: 25
        final: 30
        attendance: 5
    """
    att = get_attendance_score()
    labs = get_lab_score()
    projs = get_project_score()
    exam1, exam2 = get_exam_scores()

    print("Student's Score Distribution:")
    print("Attendance (5%):", att)
    print("Labs (10%):", labs)
    print("Projects (30%):", projs)
    print("Mid-Sem Exam (25%):", exam1)
    print("End-Sem Exam (30%):", exam2)

    # compute overall score and grade
    perf = labs + projs + exam1 + exam2 + att
    if perf < 0 or perf > 100:
        print("Incorrect value for overall performance score:", perf)
        exit(1)

    perf = round(perf)
    pass_fail = decide_pass_fail(perf, 50)
    print("Overall performance score:", perf)
    print("Status:", pass_fail)


if __name__ == "__main__":
    main()
