from graphics import *


def main():
    # win = GraphWin("Sales Graph", 500, 400)
    records = open('records.txt').read().split("\n")[1:]

    win = GraphWin("Sales Graph", 500, 400)
    win.setBackground('lightgray')

    y = 350
    x_start = 30
    for value in records:
        month, amount = value.split(",")
        scale = 2
        y_adjust = y - int(amount) * 2
        print(y_adjust)
        rect = Rectangle(Point(x_start, y), Point(x_start + 60, y_adjust))
        rect.setFill('blue')

        textCenter = Point(((x_start + x_start + 60) / 2), y + 20)
        message = Text(textCenter, month)
        message.draw(win)
        rect.draw(win)
        x_start += 90

    check = win.checkMouse()
    while not check:
        check = win.checkMouse()

    win.close()


main()