# by: Jd
# this program uses the python Graphics library to simulate traffic signals
from graphics import *
import string


def main():
    win = GraphWin('Traffic Light', 400, 400)
    win.setBackground('light gray')

    circ = Circle(Point(200, 200), 50)
    circ.draw(win)
    circ.setFill('green')

    click = False

    click = win.getMouse()
    circ.setFill('yellow')
    click = win.getMouse()
    circ.setFill('red')
    click = win.checkMouse()

    while not isCircleClicked(click, circ):
        click = win.checkMouse()

    win.close()


def isCircleClicked(click, circ):
    if not click: return False
    x, y = click.getX(), click.getY()
    xc, yc = circ.getCenter().getX(), circ.getCenter().getY()

    return (x - xc) ** 2 + (y - yc) ** 2 <= circ.getRadius() ** 2


main()
