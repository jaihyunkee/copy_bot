def compareUsernames(name1: str, name2: str) -> set:
    # There are many other more involved ways of doing this
    dat = [0] * 122
    temp = name1 + name2
    for i in temp:
        dat[ord(i)] += 1
    res = set()
    for i, c in enumerate(dat):
        if c == 1:
            res.add(chr(i))

    return res
    # return set(name1).symmetric_difference(set(name2))

# def main():
#     print(compareUsernames("Gamer82", "Frogger98"))

def findMidpoint(P: tuple, Q: tuple) -> tuple:
    # there are other more involved ways of solving this problem
    return tuple(((P[i] + Q[i])/2 for i in range(len(P))))

# def main():
#     print(findMidpoint((98, 24), (98, -75)))

if __name__ == "__main__":
    main()