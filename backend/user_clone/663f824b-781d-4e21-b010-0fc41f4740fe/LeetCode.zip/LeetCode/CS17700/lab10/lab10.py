def findElements(A: set, B: set, C: set) -> set:
    return A.intersection(B).difference(C)

def main():
    print(findElements({1,2,3},{2,3,4},{3,4,5}))
    print(findElements({"h", "e", "l", "l", "o"}, {"s", "h", "e", "l", "l"}, {"p", "e", "a", "k"}))

if __name__ == "__main__":
    main()

def compareTuples(X: tuple, Y: tuple) -> tuple:
    # There are other more involved ways of solving this
    return(tuple(X[i] for i in range(min(len(X), len(Y))) if X[i] == Y[i]))

def main():
    print(compareTuples(("p", "y", "t", "h", "o", "n"), ("b", "a", "t", "h", "e")))

if __name__ == "__main__":
    main()