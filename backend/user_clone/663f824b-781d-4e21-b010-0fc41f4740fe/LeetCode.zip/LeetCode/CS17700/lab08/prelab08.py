import matplotlib.pyplot as plt

def readTeamInfo(filename):
    result = []
    with open(filename, 'r') as file:
        result = [i.strip("\n").split(',') for i in file.readlines()]

    for i in range(len(result)):
        result[i][1] = int(result[i][1])

    return result


def findWinner(teamList):
    max = -1
    maxTeam = ""
    for i in range(len(teamList)):
        if teamList[i][1] > max:
            max = teamList[i][1]
            maxTeam = teamList[i][0]
    return maxTeam


def plotScores(teamLists, outFile):
    teams = [i[0] for i in teamLists]
    scores = [i[1] for i in teamLists]
    fig = plt.figure()
    plt.bar(teams, scores)
    # plt.xlabel("Team Name")
    # plt.ylabel("Score")
    # plt.title("Scores")
    # plt.savefig(outFile, format='pdf')
    # plt.show()
    fig, ax = plt.subplots()
    ax.set_title('Scores')
    ax.set_xlabel('Team Name')
    ax.set_ylabel('Score')
    fig.savefig(outFile)


def main():
    teamList = readTeamInfo("competition.txt")
    maxTeam = findWinner(teamList)
    plotScores(teamList, 'scores.pdf')


main()
