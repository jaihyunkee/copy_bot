#
#
#

import matplotlib.pyplot as plt


def readTeamInfo(filename):
    teamList = []
    f = open(filename, 'r')
    for line in f:
        team = line.split(',')
        team[1] = eval(team[1])
        team[2] = eval(team[2])
        team[3] = eval(team[3])
        team[4] = team[4].strip('\n')
        teamList.append(team)
    f.close()
    return teamList


def isCheater(team):
    if team[4] == 'No':
        return False
    else:
        return True


def findWinner(teamList):
    winner = ''
    maxScore = -1
    for team in teamList:
        if not isCheater(team):
            if team[2] > maxScore:
                winner = team[0]
                maxScore = team[2]
    return winner


def getPercentInjured(team):
    return 100 * (team[3] / team[1])


def plotCheaters(teamList, outFile):
    data = []
    labels = ['Cheaters', 'Non-cheaters']
    nonCheaters = 0
    cheaters = 0
    for team in teamList:
        if isCheater(team):
            cheaters = cheaters + 1
        else:
            nonCheaters = nonCheaters + 1
    data.append(cheaters)
    data.append(nonCheaters)
    fig, ax = plt.subplots()
    ax.pie(data, labels=labels)
    ax.set_title('Cheating Ratio')
    ax.set_label(labels)
    fig.savefig(outFile)


def main():
    filename = input('Please enter a file name: ')
    teamList = readTeamInfo(filename)
    print(teamList)
    team1 = teamList[0]
    print(isCheater(team1))
    print(getPercentInjured(team1))
    winner = findWinner(teamList)
    print(winner)
    plotCheaters(teamList, 'cheaters.pdf')


if __name__ == '__main__':
    main()
