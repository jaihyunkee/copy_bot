#
#
#

import matplotlib.pyplot as plt

def readTeamInfo(filename):
    teamList = []
    with open(filename, 'r') as f:
        for line in f:
            team = line.split(',')
            team[1] = eval(team[1])
            teamList.append(team)
    return teamList

def findWinner(teamList):
    winner = ''
    maxScore = -1
    for team in teamList:
        if team[1] > maxScore:
            winner = team[0]
            maxScore = team[1]
    return winner

def plotScores(teamList, outFile):
    x = []
    y = []
    for team in teamList:
        x.append(team[0])
        y.append(team[1])
    fig, ax = plt.subplots()
    ax.bar(x, y)
    ax.set_title('Scores')
    ax.set_xlabel('Team Name')
    ax.set_ylabel('Score')
    fig.savefig(outFile)

def main():
    filename = input('Please enter a file name: ')
    teamList = readTeamInfo(filename)
    print(teamList)
    winner = findWinner(teamList)
    print(winner)
    plotScores(teamList, 'scores.pdf')

if __name__ == '__main__':
    main()