def generateKey(plain_text, key_text):
    n = len(plain_text)
    key = ""
    k_list = list(key_text)
    for i in range(n):
        key += k_list[i % len(key_text)]
    return key


def encrypt(plain_text, generated_key):
    key_ascii = [ord(i) for i in generated_key]
    result = ""
    for i, c in enumerate(plain_text):
        result += chr(ord(c) + key_ascii[i])
    return result


def decrypt(cipher_text, generated_key):
    result = ""
    for i, c in enumerate(cipher_text):
        result += chr(ord(c) - ord(generated_key[i]))
    return result


if __name__ == "__main__":
    plain_text = "Hello World I am in CS 177"
    key_text = "cs177"
    gen_key = generateKey(plain_text, key_text)
    cipher_text = encrypt(plain_text, gen_key)
    print(decrypt(cipher_text, gen_key))
    print(plain_text)
