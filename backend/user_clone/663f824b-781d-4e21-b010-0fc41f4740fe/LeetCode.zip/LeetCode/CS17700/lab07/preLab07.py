"""
Write a program called swapUpperLower that will take in a string, sentence, as a parameter and convert all
lowercase characters to uppercase and convert all uppercase characters to lowercase.
"""


def swapUpperLower(sentence):
    result = ""
    for i in range(len(sentence)):
        c = sentence[i]
        if 90 >= ord(c) >= 65:
            result += chr(ord(c) + 32)
        elif 97 <= ord(c) <= 122:
            result += chr(ord(c) - 32)
        else:
            result += c
    return result


"""
Write a program that will prompt the user for text and an integer value. The program will then utilize two 
functions called encrypt and decrypt that will encrypt then decrypt the text using a simple shift cipher with the 
ASCII table as the alphabet and the integer value as the shift. A shift cipher is a type of substitution cipher in 
which each letter in the text is replaced by a letter some fixed number of positions down the alphabet. The functions 
will both take in a string, text, that will either be encrypted or decrypted by the substitution cipher depending on 
the function, and an integer, shift,to indicate the number of positions down the alphabet each character should be 
shifted, as parameters 
"""


def encrypt(text, shift):
    result = ""
    for c in text:
        result += chr(ord(c) + shift)

    return result


def decrypt(cipher, shift):
    result = ""
    for c in cipher:
        result += chr(ord(c) - shift)
    return result


if __name__ == "__main__":
    # sentence = input("Please input the sentence: ")
    # print(swapUpperLower(sentence))

    text = input("Please inpuyt the plaintext: ")
    print(f'Plaintext: {text}')
    shift = eval(input("Please input the amount to shift by: "))
    encoded = encrypt(text, shift)
    print(f'Ciphertext: {encoded}')
    decrypted = decrypt(encoded, shift)
    print(f'Decrypted: {decrypted}')
