def sum_dictionaries(dict1, dict2):
	for key, val in dict1.items():
		if key in dict2:
			dict1[key] += dict2[key]
	for key in dict2.keys() - dict1.keys():
		dict1[key] = dict2[key]
	return dict1

if __name__ == '__main__':
	dict1 = {1: 2, 3: 4, 2: 1, 4: 2, 7: 8}
	dict2 = {1: 1, 2: 2, 3: 3, 5: 2, 6: 2}
	print(sum_dictionaries(dict1, dict2))