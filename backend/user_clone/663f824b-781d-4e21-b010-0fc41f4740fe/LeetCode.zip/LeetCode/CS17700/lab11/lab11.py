import random


def read_salaries(file_path):
    salaries = {}

    with open(file_path) as f:
        lines = f.readlines()
    random.shuffle(lines)
    for line in lines:
        key, val = line.strip().split(',')
        salaries[key] = int(val)
    return salaries


def read_bonus(file_path):
    bonus = {}
    with open(file_path) as f:
        lines = f.readlines()
    random.shuffle(lines)
    for line in lines:
        key, val = line.strip().split(',')
        if key in bonus:
            bonus[key] += int(val)
        else:
            bonus[key] = int(val)
    return bonus


def total_income(salaries, bonus):
    for key, val in bonus.items():
        salaries[key] += val
    return salaries


if __name__ == '__main__':
    salaries = read_salaries('salary.txt')
    bonus = read_bonus('bonus.txt')
    print(salaries)
    print(bonus)
    total_salary = total_salary(salaries, bonus)
    print(total_salary)
