class Solution(object):
    def longestConsecutive(self, nums):
        """
        :type nums: List[int]
        :rtype: int
        """
        nums = sorted(list(set(nums)))
        result = 1

        # check if nums is empty
        maxi = min(1, len(nums))

        for i in range(1, len(nums)):
            # check out of index
            if nums[i] - 1 == nums[i - 1]:
                result += 1
            else:
                result = 1

            # get max number of sequences
            if maxi < result:
                maxi = result

        return maxi


sol = Solution()
nums = [0, -1]

print(sol.longestConsecutive(nums))
