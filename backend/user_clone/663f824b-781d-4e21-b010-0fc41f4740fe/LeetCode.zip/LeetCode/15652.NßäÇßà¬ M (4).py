# import sys

# N, M = map(int, sys.stdin.readline().split())
# out_arr = [0] * M


def dfs(arr_idx):
    if arr_idx == M:
        print(*out_arr)
        return None
    else:
        for i in range(1, N + 1):
            if arr_idx != 0:
                if out_arr[arr_idx - 1] <= i:
                    out_arr[arr_idx] = i
                    dfs(arr_idx + 1)
            else:
                out_arr[arr_idx] = i
                dfs(arr_idx + 1)


if __name__ == "__main__":
    dfs(0)

import sys

M, N = map(int, sys.stdin.readline().split())
isUsed = [False] * N

def dfs(cnt, arr):
    if cnt == N:
        print(*arr)
        return
    for i in range(M):
        if len(arr):
            if i+1 >= arr[cnt-1]:
                dfs(cnt+1, arr+[i+1])
        else:
            dfs(cnt+1, arr+[i+1])

dfs(0, [])
