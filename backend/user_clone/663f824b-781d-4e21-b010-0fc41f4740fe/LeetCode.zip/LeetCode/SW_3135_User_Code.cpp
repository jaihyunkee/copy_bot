#include <iostream>

using namespace std;
const int ALPHABET = 26;

struct TrieNode {
    int cnt;
    bool finish;
    TrieNode* children[ALPHABET];
    TrieNode() {
        cnt = 0;
        finish = false;
        for (int i = 0; i < ALPHABET; i++) {
            children[i] = NULL;
        }
    }

    ~TrieNode() { // destructor
        for (int i = 0; i < ALPHABET; i++) {
            delete children[i];
        }
    }
};
TrieNode *root;
void init(void)
{
    if (root != NULL) {
        delete root;
    }
    root = new TrieNode();
}

void insert(int buffer_size, char *buf) {
    TrieNode *ptr = root;
    for (int i = 0; i < buffer_size; i++)
    {
        int ascii = buf[i] - 'a';
        if (ptr->children[ascii] == NULL)
        {
            ptr->children[ascii] = new TrieNode();
        }
        ptr = ptr->children[ascii];
        ptr->cnt += 1;
        if (i == buffer_size - 1)
        {
            ptr->finish = true;
        }
    }
}

int query(int buffer_size, char *buf) {
    TrieNode *ptr = root;
    for (int m = 0; m < buffer_size; m++)
    {
        int ascii = buf[m] - 'a';
        if (ptr->children[ascii] != NULL) {
            ptr = ptr->children[ascii];
        }
        else {
            return 0;
        }

        if (m==buffer_size-1) {
            return ptr->cnt;
        }
    }
    return 0;
}