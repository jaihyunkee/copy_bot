import sys

def one(n):
    temp = 1
    digit = 1
    while True:
        if temp % n == 0:
            break
        digit += 1
        temp = 10 * temp + 1
    return digit

if __name__ == "__main__":
    while True:
        try:
            n = int(input())
            print(one(n))
        except EOFError:
            break



