"""
If leaf node has an operator, the tree is not valid
If internal node has a number, the tree is not valid

Maybe try to implement a binary tree and traverse in post-order?
"""

for t in range(1, 11):
    res = 1
    N = int(input())

    for _ in range(N):
        line = list(input().split())
        if len(line) == 4:
            if line[1] not in ["+", "-", "/", "*"]:
                res = 0
        else:
            if line[1] in ["+", "-", "/", "*"]:
                res = 0

    print(f'#{t} {res}')