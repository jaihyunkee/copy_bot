from collections import deque

TC = 10
for tc in range(1, TC+1):
    V, E = map(int, input().split())
    inDegree = [0] * (V+1)
    edges_arr = list(map(int, input().split()))
    edges = []
    for idx in range(0, len(edges_arr), 2):
        edges.append((edges_arr[idx], edges_arr[idx+1]))
    for e in edges:
        inDegree[e[1]] += 1

    res_arr = []
    isVisited = [False] * (V+1)
    queue = deque()
    for i in range(1, len(inDegree)):
        if inDegree[i] == 0:
            queue.append(i)
            isVisited[i] = True

    while queue:
        popped_node = queue.popleft()
        res_arr.append(popped_node)
        for e in edges:
            if e[0] == popped_node:
                inDegree[e[1]] -= 1
            if inDegree[e[1]] == 0 and not isVisited[e[1]]:
                queue.append(e[1])
                isVisited[e[1]] = True

        # for i in range(1, len(inDegree)):
        #     if inDegree[i] == 0 and not isVisited[i]:
        #         queue.append(i)
        #         isVisited[i] = True

    print(f'#{tc}', end=' ')
    print(*res_arr)
    # result = ' '.join(list(map(str, res_arr)))




