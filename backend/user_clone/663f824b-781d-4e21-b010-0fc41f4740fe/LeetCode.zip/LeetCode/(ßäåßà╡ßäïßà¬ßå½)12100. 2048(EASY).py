def inRange(i, j):
    return 0 <= i < N and 0 <= j < N
def moveUpward():
    for i in range(N):
        for j in range(N):
            if grid[i][j] == 0:
                continue
            if grid[i][j] == grid[i+1][j] and inRange(i+1, j):
                grid[i][j] += grid[i+1][j]
                grid[i+1][j] = 0
            if grid[i-1][j] == 0 and inRange(i-1, j):
                grid[i-1][j] = grid[i][j]
                grid[i][j] = 0

def moveRight():

def moveLeft():

def moveDownward():
    for i in range(N-1, -1, -1):
        for j in range(N-1, -1, -1):
            if grid[i][j] == 0:
                continue
            if grid[i][j] == grid[i-1][j]:
                grid[i][j] += grid[i-1][j]
                grid[i-1][j] = 0
            if grid[i+1][j] == 0:
                grid[i+1][j] = grid[i][j]
                grid[i][j] = 0

N = int(input())
grid = []
for _ in range(N):
    grid.append(list(map(int, input().split())))


