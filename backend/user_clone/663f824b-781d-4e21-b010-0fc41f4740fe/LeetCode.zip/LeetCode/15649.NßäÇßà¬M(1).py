"""
Recursive(Back-Tracking)
- should use global variable for the boolean list and a array to print
- don't forget to set the base case correctly(in this case, when the arr_idx is equal to M, print)
"""

# import sys

# N, M = map(int, sys.stdin.readline().split())
# isUsed = [0] * (N + 1)
# out_arr = [0] * M


# def dfs(arr_idx):
#     if arr_idx == M:
#         print(*out_arr)
#         return
#     else:
#         for i in range(1, N + 1):
#             if not isUsed[i]:
#                 isUsed[i] = 1
#                 out_arr[arr_idx] = i
#                 dfs(arr_idx + 1)
#                 isUsed[i] = 0


# if __name__ == "__main__":
#     dfs(0)


import sys

N, M = map(int, sys.stdin.readline().split())

ret = []
isUsed = [M] * N
def dfs(loc, ret): 
    if loc == M:
            print(*ret)
            return
    for i in range(N):
        if i+1 not in ret:
            isUsed[i] = True
            dfs(loc+1, ret+[i+1])
            isUsed[i] = False

dfs(0, ret)

