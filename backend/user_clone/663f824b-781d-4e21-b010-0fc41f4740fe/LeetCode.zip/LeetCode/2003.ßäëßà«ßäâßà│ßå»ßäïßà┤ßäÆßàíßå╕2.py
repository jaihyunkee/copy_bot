import sys

N, M = map(int, sys.stdin.readline().split())
nums = list(map(int, sys.stdin.readline().split()))

res = 0

for ndx in range(len(nums)):
    sum = 0
    for nndx in range(ndx, len(nums)):
        sum += nums[nndx]
        if sum == M:
            res += 1

print(res)
