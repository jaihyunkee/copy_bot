import sys


def fib(n: int):
    if n == 0:
        return 0
    elif n == 1:
        return 1
    else:
        return fib(n - 1) + fib(n - 2)


def Solution():
    n = int(sys.stdin.readline())
    return fib(n)


if __name__ == "__main__":
    print(Solution())
