import sys
def Solution():
    N = sys.stdin.readline()[:-1]
    n = list(map(int, list(N)))
    n.sort(reverse=True)
    n = list(map(str, list(n)))
    return "".join(n)


if __name__ == "__main__":
    print(Solution())