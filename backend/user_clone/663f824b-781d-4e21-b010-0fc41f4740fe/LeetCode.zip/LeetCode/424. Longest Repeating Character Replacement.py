class Solution:
    def characterReplacement(self, s: str, k: int) -> int:

        # counting frequency
        l, r = 0, 0
        dat = [0] * 26
        res = 0


        for i in range(len(s)):
            dat[ord(s[r]) - 65] += 1
            to_change = r - l + 1 - max(dat)
            if to_change <= k:
                res = max(res, to_change + max(dat))
            else:
                dat[ord(s[l]) - 65] -= 1
                if not dat[ord(s[l]) - 65]:
                    dat.pop(s[l])
                l += 1
            r += 1
        return res

sol = Solution()
print(sol.characterReplacement("AABABBA", 1))