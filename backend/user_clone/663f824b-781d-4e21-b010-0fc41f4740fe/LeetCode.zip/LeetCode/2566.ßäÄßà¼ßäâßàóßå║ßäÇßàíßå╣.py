"""
0 0 0 0 0 0 0 0 0
0 0 0 0 0 0 0 0 0
0 0 0 0 0 0 0 0 0
0 0 0 0 0 0 0 0 0
0 0 0 0 0 0 0 0 0
0 0 0 0 0 0 0 0 0
0 0 0 0 0 0 0 0 0
0 0 0 0 0 0 0 0 0
0 0 0 0 0 0 0 0 0

input이 위와 같을때의 경우를 고려 하지 않아서 처음에 에러가 발생 함.

"""

import sys


def Solution():
    max_res = 0
    row = 1
    col = 1
    board = []
    for i in range(9):
        line = list(map(int, sys.stdin.readline().split(" ")))
        if max(line) > max_res:
            max_res = max(line)
            row = i + 1
            col = line.index(max(line)) + 1

    print(max_res)
    print(row, col)

    return None



if __name__ == "__main__":
    Solution()

