import sys
test_case = int(input())
for tc in range(test_case):
    N = int(input())
    arr = []
    for n in range(N):
        T, D = map(int, sys.stdin.readline().split())
        arr.append((T, D))
    arr.sort(key=lambda x:-x[1])
    print(arr)
    end_date = max(tuple, key=lambda x: x[1])
    for e in range(end_date-1, 0, -1):
        
        



