# import sys

# N, M = map(int, sys.stdin.readline().split())
# nums = sorted(list(map(int, sys.stdin.readline().split())))

# out_arr = [0] * M

# def dfs(arr_idx, start):
#     if M == arr_idx:
#         print(*out_arr)
#         return None
#     else:
#         for i in range(start, len(nums)):
#             out_arr[arr_idx] = nums[i]
#             dfs(arr_idx + 1, i)


# if __name__ == "__main__":
#     dfs(0, 0)

import sys

N, M = map(int, sys.stdin.readline().split())
arr = sorted(list(map(int, sys.stdin.readline().split())))

def dfs(cnt, res):
    if len(res) == M:
        print(*res)
        return
    for i in range(cnt, N):
        dfs(i, res+[arr[i]])

dfs(0, [])