import sys


def Solution():
    N = int(sys.stdin.readline())
    p_list = []
    for i in range(N):
        x, y = map(int, sys.stdin.readline().split(" "))
        p_list.append((x, y))

    result = []

    for i in p_list:
        count = 0
        for j in p_list:
            if i[0] < j[0] and i[1] < j[1]:
                count += 1

        result.append(count + 1)

    return " ".join(list(map(str, result)))


if __name__ == "__main__":
    print(Solution())
