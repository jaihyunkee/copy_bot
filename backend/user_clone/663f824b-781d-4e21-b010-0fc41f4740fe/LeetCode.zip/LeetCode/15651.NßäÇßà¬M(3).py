# import sys

# N, M = map(int, sys.stdin.readline().split())
# out_arr = [0] * M
# isUsed = [0] * (N + 1)


# def dfs(arr_idx):
#     if arr_idx == M:
#         print(*out_arr)
#         return None
#     else:
#         isUsed = [0] * (N + 1)
#         for i in range(1, N + 1):
#             if isUsed[i] == 0:
#                 out_arr[arr_idx] = i
#                 isUsed[i] = 1
#             dfs(arr_idx + 1)


# if __name__ == "__main__":
#     dfs(0)


import sys

N, M = map(int, sys.stdin.readline().split())
isUsed = [False] * N
def dfs(cnt, arr):
    if cnt == M:
        print(*arr)
        return
    for i in range(N):
        dfs(cnt+1, arr+[i+1])

dfs(0, [])
