import sys


def listToInt(l: list):
    s = [str(num) for num in l]
    ret = int("".join(s))
    return ret


def listToStr(l: list):
    ret = ""
    for _ in l:
        ret = f'{ret}{_}'

    return ret


def assign(num: int, k: int):
    global isUsed, result, results, isOneSet, min_num, max_num, min_ans, max_ans
    if k == 0:
        res_num = listToInt(result)
        if min_num > res_num:
            min_num = res_num
            min_ans = listToStr(result)

        if max_num < res_num:
            max_num = res_num
            max_ans = listToStr(result)

        results.append(result)
        result.pop()
        isOneSet = True
        return

    for i in range(10):
        if not isUsed[i]:
            isUsed[i] = True
            result.append(i)
            if ineq_list[len(ineq_list) - k] == ">" and num > i:
                assign(i, k - 1)
                isUsed[i] = False
                if isOneSet:
                    isOneSet = False
                    continue
                result.pop()
            elif ineq_list[len(ineq_list) - k] == "<" and num < i:
                assign(i, k - 1)
                isUsed[i] = False
                if isOneSet:
                    isOneSet = False
                    continue
                result.pop()
            else:
                if result:
                    isUsed[i] = False
                    result.pop()
                continue


k = int(sys.stdin.readline())
ineq_list = list(sys.stdin.readline().split())

isUsed = [False] * 10
result = []
results = []
isOneSet = False
min_num = float('inf')
max_num = float('-inf')
min_ans, max_ans = 0, 0

for i in range(10):
    isUsed[i] = True
    result.append(i)
    assign(i, k)
    isUsed[i] = False
    result.pop()

print(max_ans)
print(min_ans)
