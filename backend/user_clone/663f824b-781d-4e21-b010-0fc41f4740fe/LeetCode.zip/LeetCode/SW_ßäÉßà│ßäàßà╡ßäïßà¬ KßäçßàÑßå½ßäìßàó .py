TC = int(input())
for tc in range(1, TC+1):
    N, M = map(int, input().split())
    weights = list(map(int, input().split()))
    edges = []
    for _ in range(N-1):
        x, y = map(int, input().split())
        edges.append((x, y))
    queries = []
    for m in range(M):
        queries.append(list(map(int, input().split())))
