import sys


def Solution():
    N = int(sys.stdin.readline())
    r = int(N ** 0.5)
    res = []
    for i in range(2, r + 1):
        while N % i == 0:
            res.append(i)
            N = N // i
    if N > 1:
        res.append(N)

    return '\n'.join(map(str, res))


if __name__ == "__main__":
    print(Solution())
