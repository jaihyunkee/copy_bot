import sys
sys.stdin = open("input.txt", "r")

def inRange(x: int, y: int, n: int) -> bool:
    return 0 <= x < n and 0 <= y < n

def Solution():
    test_n = int(sys.stdin.readline())

    for _ in range(1, test_n + 1):
        mmax_virus = 0
        mmax_virus_list = []
        mmax_index_virus_list = []
        n, p = list(map(int, sys.stdin.readline().split()))
        grid = []
        for i in range(n):
            grid.append(list(map(int, sys.stdin.readline().split())))

        s_virus_list = []
        d_virus_list = []
        max_virus_list = []

        for x in range(len(grid)):
            for y in range(len(grid[x])):

                s_virus_list.append(grid[x][y])
                s_index_virus_list = [(x, y)]

                d_virus_list.append(grid[x][y])
                d_index_virus_list = [(x, y)]

                max_virus_list.append(grid[x][y])
                max_index_virus_list = [(x, y)]

                for j in range(1, p + 1):
                    # diagonal
                    if inRange(x + j, y + j, n):  # 동남
                        s_virus_list.append(grid[x + j][y + j])
                        s_index_virus_list.append((x + j, y + j, 0))
                    if inRange(x + j, y - j, n):  # 동서
                        s_virus_list.append(grid[x + j][y - j])
                        s_index_virus_list.append((x + j, y - j, 1))
                    if inRange(x - j, y - j, n):  # 북서
                        s_virus_list.append(grid[x - j][y - j])
                        s_index_virus_list.append((x - j, y - j, 2))
                    if inRange(x - j, y + j, n):  # 북동
                        s_virus_list.append(grid[x - j][y + j])
                        s_index_virus_list.append((x - j, y + j, 3))

                    # straight
                    if inRange(x + j, y, n):  # 상
                        d_virus_list.append(grid[x + j][y])
                        d_index_virus_list.append((x + j, y, 4))
                    if inRange(x, y + j, n):  # 하
                        d_virus_list.append(grid[x][y + j])
                        d_index_virus_list.append((x, y + j, 5))
                    if inRange(x - j, y, n):  # 좌
                        d_virus_list.append(grid[x - j][y])
                        d_index_virus_list.append((x - j, y, 6))
                    if inRange(x, y - j, n):  # 우
                        d_virus_list.append(grid[x][y - j])
                        d_index_virus_list.append((x, y - j, 7))

                    if sum(d_virus_list) > sum(s_virus_list):
                        max_virus_list = d_virus_list
                        max_index_virus_list = d_index_virus_list
                    else:
                        max_virus_list = s_virus_list
                        max_index_virus_list = s_index_virus_list

                if sum(max_virus_list) > mmax_virus:
                    mmax_virus = sum(max_virus_list)
                    mmax_virus_list = d_virus_list
                    mmax_index_virus_list = max_index_virus_list

                d_virus_list = []
                s_virus_list = []
                max_virus_list = []
        # mmax_virus, mmax_virus_list, mmax_index_virus_list
        print(f'#{_} {mmax_virus}')
    return None


if __name__ == "__main__":
    Solution()
