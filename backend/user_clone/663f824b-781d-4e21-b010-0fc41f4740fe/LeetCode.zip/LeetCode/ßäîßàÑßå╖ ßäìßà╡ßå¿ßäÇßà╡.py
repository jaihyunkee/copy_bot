import math

def solution(k, d):
    answer = 0
    for x in range(0, d+1, k):
        y_num = math.floor(math.sqrt(d**2-x**2))
        answer += y_num//k+1 # +1은 y=0인 점도 포함
    
    return answer