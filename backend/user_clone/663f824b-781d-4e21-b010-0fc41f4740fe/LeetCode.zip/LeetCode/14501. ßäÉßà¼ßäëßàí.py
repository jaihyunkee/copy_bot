import sys


def Solution():
    N = int(sys.stdin.readline())
    schedule = [list(map(int, sys.stdin.readline().split())) for _ in range(N)]
    T, P = [], []
    for _ in range(N):
        T.append(schedule[_][0])
        P.append(schedule[_][1])
    dp = [0] * (N + 1)
    for i in range(N):
        for j in range(i + T[i], N + 1):
            dp[j] = max(dp[j], dp[i] + P[i])
        # print(i, dp)

    return dp[N]


if __name__ == "__main__":
    print(Solution())
