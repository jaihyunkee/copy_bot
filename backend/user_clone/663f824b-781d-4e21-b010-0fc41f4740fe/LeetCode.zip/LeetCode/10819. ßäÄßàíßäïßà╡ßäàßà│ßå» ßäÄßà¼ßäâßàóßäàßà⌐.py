import sys

N = int(sys.stdin.readline())
A = list(map(int, sys.stdin.readline().split()))
isUsed = [False] * (N + 1)
max_val = float('-inf')
permu_list = []


def solve(cnt: int):
    global max_val
    if cnt == N:
        target = 0
        for i in range(len(permu_list) - 1):
            target += abs(permu_list[i] - permu_list[i + 1])
        if target > max_val:
            max_val = target
        return

    for i in range(N):
        if not isUsed[i + 1]:
            isUsed[i + 1] = True
            permu_list.append(A[i])
            solve(cnt + 1)
            permu_list.pop()
            isUsed[i + 1] = False


if __name__ == "__main__":
    solve(0)
    print(max_val)
