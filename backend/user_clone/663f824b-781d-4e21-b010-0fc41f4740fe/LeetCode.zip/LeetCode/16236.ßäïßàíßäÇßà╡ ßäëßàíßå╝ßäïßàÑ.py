N = int(input())
grid = [list(map(int, input().split())) for _ in range(N)]


def inRange(i, j):
    return 0 <= i < N and 0 <= j < N



