class Solution(object):
    def convert(self, s, numRows):
        """
        :type s: str
        :type numRows: int
        :rtype: str
        """
        result = ""
        c = numRows * 2 - 2
        if c == 0:
            return s
        for i in range(numRows):
            j = i
            diag = c - i
            while j < len(s):
                result += s[j]

                if i != 0 and i != numRows-1 and diag < len(s):
                    result += s[diag]
                    diag += c
                j += c

        return result


sol = Solution()
print(sol.convert("P", 1))
