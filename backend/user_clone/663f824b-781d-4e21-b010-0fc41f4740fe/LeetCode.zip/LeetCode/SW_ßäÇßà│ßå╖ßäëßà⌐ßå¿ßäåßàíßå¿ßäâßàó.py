def dfs(cnt: int, stick_arr):
    global max_len, res_stick

    if len(stick_arr) > max_len:
        res_stick = []
        max_len = len(stick_arr)
        for i in stick_arr:
            for j in i:
                res_stick.append(j)

    if cnt == len(sticks):
        return

    for stick_idx in range(0, len(sticks)):
        if cnt == 0:
            isUsed[stick_idx] = True
            dfs(cnt + 1, stick_arr + [sticks[stick_idx]])
            isUsed[stick_idx] = False
        elif not isUsed[stick_idx]:
            isUsed[stick_idx] = True
            prev = stick_arr[-1][1]
            post = sticks[stick_idx][0]
            if prev == post:
                dfs(cnt + 1, stick_arr + [sticks[stick_idx]])
            isUsed[stick_idx] = False

    return


TC = int(input())
for tc in range(1, TC + 1):
    stick_num = int(input())
    arr = list(map(int, input().split()))

    sticks = [(arr[i], arr[i + 1]) for i in range(0, len(arr), 2)]
    isUsed = [False] * stick_num
    max_len = float('-inf')
    stick_arr = []
    res_stick = []

    dfs(0, stick_arr)

    print(f'#{tc}', end=" ")
    print(*res_stick)
