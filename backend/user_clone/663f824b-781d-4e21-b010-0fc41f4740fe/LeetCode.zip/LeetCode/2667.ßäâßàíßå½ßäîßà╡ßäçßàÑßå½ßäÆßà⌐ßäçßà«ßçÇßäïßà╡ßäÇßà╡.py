from collections import deque


def inRange(i, j):

    return 0 <= i < N and 0 <= j < N


N = int(input())
grid = [list(map(int, list(input()))) for _ in range(N)]

visited = set()
res = []
queue = deque([])
for i in range(N):
    for j in range(N):
        temp = []
        if grid[i][j] == 1 and (i, j) not in visited:

            queue.append((i, j))
            visited.add((i, j))
            while queue:
                ci, cj = queue.popleft()
                temp.append((ci, cj))
                for m in [(0, 1), (0, -1), (1, 0), (-1, 0)]:
                    ni, nj = ci + m[0], cj + m[1]

                    if inRange(ni, nj):
                        if grid[ni][nj] == 1 and (ni, nj) not in visited:
                            queue.append((ni, nj))
                            visited.add((ni, nj))
        if len(temp):
            res.append(temp)

print(len(res))
res = sorted(res, key=len)
for r in res:
    print(len(r))
