"""
문제가 최소한의 버튼 누르는 횟수를 구하는 거여서 BFS를 사용할 줄 알았는데, 층의 범위가 100000000로 너무 컸다.
그래서 규칙을 사용해야하고, 단순한 계산으로 한자리 수씩 줄여가며 계산 할 수 있다.
"""

def solution(storey):
    answer = 0
    while storey:
        remainder = storey % 10
        storey //= 10
        
        if remainder > 5:
            answer += (10-remainder)
            storey += 1
        elif remainder < 5:
            answer += remainder
        elif remainder == 5:
            t = storey % 10
            if t >= 5:
                answer += (10-remainder)
                storey += 1
            else:
                answer += remainder
    return answer