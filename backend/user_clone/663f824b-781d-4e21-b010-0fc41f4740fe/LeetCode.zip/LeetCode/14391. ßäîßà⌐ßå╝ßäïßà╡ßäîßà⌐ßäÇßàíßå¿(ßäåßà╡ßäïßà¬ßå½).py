import sys

vert, horiz = map(int, sys.stdin.readline().split())
grid = []
isUsed = []
for _ in range(vert):
    nums = list(map(int, sys.stdin.readline().split()))
    grid.append(nums)
    isUsed.append([False] * len(nums))

def listToNum(lst):
    res = ""
    for c in lst:
        res += str(c)
    return int(res)

def dfs(cnt):


