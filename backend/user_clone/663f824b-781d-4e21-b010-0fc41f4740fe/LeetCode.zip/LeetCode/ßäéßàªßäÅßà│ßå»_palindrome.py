def solution(S):
    freq = [0] * 26
    for char in S:
        freq[ord(ch) - ord('a')] += 1
    
    total_pairs = sum(count // 2 for count in freq)
    
    return min(total_pairs, len(S) // 3)

from collections import Counter

def solution(S):
    freq = Counter(S)
    
    total_pairs = 0
    for count in freq.values():
        total_pairs += count // 2
    
    return min(total_pairs, len(S) // 3)