from copy import deepcopy
from collections import deque

N, M = map(int, input().split())
grid = []
virus_coord = []
for i in range(N):
    line = list(map(int, input().split()))
    for idx in range(len(line)):
        if line[idx] == 2:
            virus_coord.append((i, idx))
    grid.append(line)


def inRange(i, j):
    return 0 <= i < N and 0 <= j < M
def check_safe_num():
    visited = [[False] * M for _ in range(N)]
    queue = deque(virus_coord)
    copy_grid = deepcopy(grid)  # Create a copy of the original grid
    for i, j in queue:
        visited[i][j] = True
    while queue:
        virus = queue.popleft()
        i, j = virus[0], virus[1]
        for m in [(0, 1), (0, -1), (1, 0), (-1, 0)]:
            ni, nj = i + m[0], j + m[1]
            if inRange(ni, nj) and copy_grid[ni][nj] == 0 and not visited[ni][nj]:
                copy_grid[ni][nj] = 2
                queue.append((ni, nj))
                visited[ni][nj] = True

    safe_cnt = 0
    for i in range(N):
        for j in range(M):
            if copy_grid[i][j] == 0:
                safe_cnt += 1
    return safe_cnt


def dfs(wall_cnt):
    global max_val, grid
    if wall_cnt == 0:
        safe_num = check_safe_num()
        if safe_num > max_val:
            # for g in grid:
            #     print(g)
            # print()
            max_val = safe_num
        return
    for i in range(N):
        for j in range(M):
            if grid[i][j] == 0:
                grid[i][j] = 1
                dfs(wall_cnt-1)
                grid[i][j] = 0

max_val = float('-inf')
dfs(3)
print(max_val)
