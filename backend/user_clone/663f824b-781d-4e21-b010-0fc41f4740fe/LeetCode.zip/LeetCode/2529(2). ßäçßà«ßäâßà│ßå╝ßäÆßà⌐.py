import sys

k = int(sys.stdin.readline())
sign_list = list(sys.stdin.readline().split())
isUsed = [False] * 10
mx, mn = "", ""


def isPossible(i, j, sign):
    if sign == '<':
        return i < j
    else:
        return i > j


def solve(cnt: int, res: str):
    global mn, mx
    if cnt == k + 1:
        if not len(mn):
            mn = res
        else:
            mx = res
        return

    for i in range(10):
        if not isUsed[i]:
            if not cnt or isPossible(int(res[-1]), i, sign_list[cnt-1]):
                isUsed[i] = True
                solve(cnt + 1, res + str(i))
                isUsed[i] = False


solve(0, "")
print(mx)
print(mn)

