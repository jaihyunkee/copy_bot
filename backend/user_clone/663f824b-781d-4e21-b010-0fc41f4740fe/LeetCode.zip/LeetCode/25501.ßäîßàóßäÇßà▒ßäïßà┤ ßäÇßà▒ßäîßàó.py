import sys

# recursion
def recursion(S, l: int, r: int):
    if l >= r:
        return 1, l+1
    elif S[l] != S[r]:

        return 0, l+1
    else:
        return recursion(S, l + 1, r - 1)


def isPalindrome(S):
    result = recursion(S, 0, len(S) - 1)
    return result


def Solution():
    T = int(sys.stdin.readline())
    for i in range(T):
        S = input()
        result = isPalindrome(S)
        print(result[0], result[1])

    return None

if __name__ == "__main__":
    Solution()
