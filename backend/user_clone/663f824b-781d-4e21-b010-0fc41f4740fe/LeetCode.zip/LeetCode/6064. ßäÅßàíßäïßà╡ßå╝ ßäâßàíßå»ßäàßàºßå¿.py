import sys
import math


def gcd(a: int, b: int):
    while b != 0:
        r = a % b
        a = b
        b = r
    return a


def lcm(a: int, b: int):
    return int((a * b) / gcd(a, b))


def Solution():
    T = int(sys.stdin.readline())
    for i in range(T):
        M, N, x, y = map(int, sys.stdin.readline().split())

        possible_year = x
        possible_year_found = False
        quotient = 0
        while possible_year <= math.lcm(M, N):
            if possible_year % N == y or (possible_year % N == 0 and N == y):
                print(possible_year)
                possible_year_found = True
                break
            quotient += 1
            possible_year = quotient * M + x
        if not possible_year_found:
            print(-1)


    """
    time limit exceed error
    for i in range(T):
        sx, sy, year = 1, 1, 1
        M, N, x, y = map(int, sys.stdin.readline().split())
        while sx <= M and sy <= N:
            if sx == x and sy == y:
                print(year)
                break
            elif sx == M:
                sx = 1
                sy += 1
            elif sy == N:
                sy = 1
                sx += 1
            else:
                sx += 1
                sy += 1
            year += 1
        else:
            print(-1)
    """


if __name__ == "__main__":
    Solution()
